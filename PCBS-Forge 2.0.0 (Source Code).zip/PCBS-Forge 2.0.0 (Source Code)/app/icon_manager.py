import os
import sys
import urllib.request
from app.config import ICON_URL, ICON_DIR
from app.logger import get_logger

log = get_logger("Icon")


def get_icon_path():
    if sys.platform == "win32":
        return os.path.join(ICON_DIR, "icon.ico")
    elif sys.platform == "darwin":
        return os.path.join(ICON_DIR, "icon.icns")
    else:
        return os.path.join(ICON_DIR, "icon.png")


def download_and_convert_icon():
    icon_path = get_icon_path()

    if os.path.exists(icon_path):
        log.info(f"Icon already exists: {icon_path}")
        return icon_path

    png_path = os.path.join(ICON_DIR, "icon_source.png")

    try:
        if not os.path.exists(png_path):
            log.info(f"Downloading icon from {ICON_URL}")
            urllib.request.urlretrieve(ICON_URL, png_path)
            log.info("Icon downloaded successfully")
    except Exception as e:
        log.error(f"Failed to download icon: {e}")
        return None

    try:
        from PIL import Image

        img = Image.open(png_path)

        if sys.platform == "win32":
            sizes = [(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
            icon_images = []
            for size in sizes:
                resized = img.resize(size, Image.LANCZOS)
                icon_images.append(resized)
            icon_images[0].save(icon_path, format="ICO", sizes=[(s, s) for _, s in enumerate([16, 32, 48, 64, 128, 256])], append_images=icon_images[1:])
            log.info(f"Created .ico: {icon_path}")

        elif sys.platform == "darwin":
            img.save(icon_path, format="ICNS")
            log.info(f"Created .icns: {icon_path}")

        else:
            img_128 = img.resize((128, 128), Image.LANCZOS)
            img_128.save(icon_path, format="PNG")
            log.info(f"Created .png: {icon_path}")

        return icon_path

    except ImportError:
        log.warning("Pillow not installed, using PNG as fallback")
        if sys.platform == "win32":
            try:
                import shutil
                fallback = os.path.join(ICON_DIR, "icon.png")
                if not os.path.exists(fallback):
                    shutil.copy2(png_path, fallback)
                return fallback
            except Exception:
                pass
        return png_path

    except Exception as e:
        log.error(f"Failed to convert icon: {e}")
        return None
