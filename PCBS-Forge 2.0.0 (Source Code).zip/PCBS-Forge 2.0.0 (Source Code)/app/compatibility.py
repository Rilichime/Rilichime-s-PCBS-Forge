from app.logger import get_logger

log = get_logger("Compatibility")


def _safe_float(value, default=0.0):
    try:
        return float(value)
    except (ValueError, TypeError):
        return default


def _safe_int(value, default=0):
    try:
        return int(float(value))
    except (ValueError, TypeError):
        return default


def check_compatibility(build_slots):
    warnings = []

    case_part = _get_single(build_slots, "Case")
    psu_part = _get_single(build_slots, "PSU")
    mobo_part = _get_single(build_slots, "Motherboard")
    cpu_part = _get_single(build_slots, "CPU")
    cooler_part = _get_single(build_slots, "CPU Cooler")
    gpu_parts = _get_list(build_slots, "GPU")
    ram_parts = _get_list(build_slots, "RAM")
    storage_parts = _get_list(build_slots, "Storage")

    if cpu_part and mobo_part:
        cpu_socket = cpu_part.get("Socket", "").strip()
        mobo_socket = mobo_part.get("CPU Socket", "").strip()
        if cpu_socket and mobo_socket and cpu_socket != mobo_socket:
            msg = f"CPU socket ({cpu_socket}) does not match Motherboard socket ({mobo_socket})"
            warnings.append(msg)
            log.warning(f"Compatibility: {msg} | CPU={cpu_part.get('Full Part Name','')} Mobo={mobo_part.get('Full Part Name','')}")

    if psu_part and (cpu_part or gpu_parts):
        psu_wattage = _safe_float(psu_part.get("Wattage", 0))
        total_wattage = 0.0
        if cpu_part:
            total_wattage += _safe_float(cpu_part.get("Wattage", 0))
        for gpu in gpu_parts:
            total_wattage += _safe_float(gpu.get("Wattage", 0))
        if psu_wattage < total_wattage:
            msg = f"PSU wattage ({int(psu_wattage)}W) is less than CPU + GPU wattage ({int(total_wattage)}W)"
            warnings.append(msg)
            log.warning(f"Compatibility: {msg}")

    if psu_part and case_part:
        psu_length = _safe_float(psu_part.get("Length", 0))
        max_psu_length = _safe_float(case_part.get("Max PSU length", 9999))
        if psu_length > 0 and max_psu_length > 0 and psu_length > max_psu_length:
            msg = f"PSU length ({int(psu_length)}mm) exceeds case max ({int(max_psu_length)}mm)"
            warnings.append(msg)
            log.warning(f"Compatibility: {msg}")

        psu_size = psu_part.get("Size", "").strip().upper()
        if psu_size:
            case_atx = case_part.get("PSU ATX", "").strip().upper()
            case_sfx = case_part.get("PSU SFX", "").strip().upper()
            if psu_size == "ATX" and case_atx != "Y":
                msg = f"Case does not support ATX PSU"
                warnings.append(msg)
                log.warning(f"Compatibility: {msg}")
            elif psu_size == "SFX" and case_sfx != "Y":
                msg = f"Case does not support SFX PSU"
                warnings.append(msg)
                log.warning(f"Compatibility: {msg}")

    for gpu in gpu_parts:
        if case_part:
            gpu_length = _safe_float(gpu.get("Length", 0))
            max_gpu_length = _safe_float(case_part.get("Max GPU length", 9999))
            if gpu_length > 0 and max_gpu_length > 0 and gpu_length > max_gpu_length:
                msg = f"GPU '{gpu.get('Full Part Name','')}' length ({int(gpu_length)}mm) exceeds case max ({int(max_gpu_length)}mm)"
                warnings.append(msg)
                log.warning(f"Compatibility: {msg}")

    if cooler_part and case_part:
        cooler_height = _safe_float(cooler_part.get("Height", 0))
        max_height = _safe_float(case_part.get("Max CPU Fan Height", 9999))
        if cooler_height > 0 and max_height > 0 and cooler_height > max_height:
            msg = f"CPU Cooler height ({int(cooler_height)}mm) exceeds case max ({int(max_height)}mm)"
            warnings.append(msg)
            log.warning(f"Compatibility: {msg}")

    if cooler_part and cpu_part:
        cpu_socket = cpu_part.get("Socket", "").strip()
        socket_list_str = cooler_part.get("CPU Socket List", "")
        if cpu_socket and socket_list_str:
            supported_sockets = [s.strip() for s in socket_list_str.split(",") if s.strip()]
            if supported_sockets and cpu_socket not in supported_sockets:
                msg = f"CPU Cooler does not support CPU socket ({cpu_socket})"
                warnings.append(msg)
                log.warning(f"Compatibility: {msg} | Cooler={cooler_part.get('Full Part Name','')} CPU={cpu_part.get('Full Part Name','')}")

    if mobo_part and case_part:
        mobo_size = mobo_part.get("Size", "").strip()
        size_map = {
            "Mini-ITX": "Mini-ITX",
            "Micro-ATX": "Micro-ATX",
            "S-ATX": "S-ATX",
            "E-ATX": "E-ATX",
            "XL-ATX": "XL-ATX",
            "SSI-EEB": "SSI-EEB",
        }
        case_col = size_map.get(mobo_size, "")
        if case_col:
            supported = case_part.get(case_col, "").strip().upper()
            if supported != "Y":
                msg = f"Case does not support {mobo_size} motherboard"
                warnings.append(msg)
                log.warning(f"Compatibility: {msg}")

    if ram_parts and mobo_part:
        mobo_ram_type = mobo_part.get("RAM Type", "").strip()
        for ram in ram_parts:
            ram_type = ram.get("RAM Type", "").strip()
            if ram_type and mobo_ram_type and ram_type != mobo_ram_type:
                msg = f"RAM '{ram.get('Full Part Name','')}' type ({ram_type}) does not match Motherboard ({mobo_ram_type})"
                warnings.append(msg)
                log.warning(f"Compatibility: {msg}")
                break

    if ram_parts and mobo_part:
        mobo_ram_slots = _safe_int(mobo_part.get("RAM Slots", 99))
        if len(ram_parts) > mobo_ram_slots:
            msg = f"Too many RAM sticks ({len(ram_parts)}) for Motherboard ({mobo_ram_slots} slots)"
            warnings.append(msg)
            log.warning(f"Compatibility: {msg}")

    if storage_parts and mobo_part:
        sata_count = 0
        m2_count = 0
        for s in storage_parts:
            stype = s.get("Type", "").strip().upper()
            if stype == "M.2":
                m2_count += 1
            else:
                sata_count += 1

        mobo_sata = _safe_int(mobo_part.get("SATA Slots Usable", 99))
        mobo_m2 = _safe_int(mobo_part.get("M.2 Slots", 99))

        if sata_count > mobo_sata:
            msg = f"Too many SATA drives ({sata_count}) for Motherboard ({mobo_sata} SATA slots)"
            warnings.append(msg)
            log.warning(f"Compatibility: {msg}")

        if m2_count > mobo_m2:
            msg = f"Too many M.2 drives ({m2_count}) for Motherboard ({mobo_m2} M.2 slots)"
            warnings.append(msg)
            log.warning(f"Compatibility: {msg}")

    # Check that all RAM sticks have same size and frequency
    if len(ram_parts) >= 2:
        first_ram = ram_parts[0]
        first_size = _safe_int(first_ram.get("Size (GB)", 0))
        first_freq = _safe_int(first_ram.get("Frequency", 0))
        for i, ram in enumerate(ram_parts[1:], start=2):
            ram_size = _safe_int(ram.get("Size (GB)", 0))
            ram_freq = _safe_int(ram.get("Frequency", 0))
            if ram_size != first_size:
                msg = f"RAM stick {i} size ({ram_size}GB) does not match first stick ({first_size}GB)"
                warnings.append(msg)
                log.warning(f"Compatibility: {msg}")
            if ram_freq != first_freq:
                msg = f"RAM stick {i} frequency ({ram_freq}MHz) does not match first stick ({first_freq}MHz)"
                warnings.append(msg)
                log.warning(f"Compatibility: {msg}")

    if len(gpu_parts) == 2:
        gpu1_name = gpu_parts[0].get("Full Part Name", "")
        gpu2_name = gpu_parts[1].get("Full Part Name", "")
        if gpu1_name != gpu2_name:
            msg = f"Dual GPU requires matching GPUs: '{gpu1_name}' vs '{gpu2_name}'"
            warnings.append(msg)
            log.warning(f"Compatibility: {msg}")

        gpu_multi_type = gpu_parts[0].get("Multi-GPU", "").strip()
        if not gpu_multi_type:
            msg = f"GPU '{gpu1_name}' does not support Multi-GPU"
            warnings.append(msg)
            log.warning(f"Compatibility: {msg}")
        elif mobo_part:
            if gpu_multi_type == "SLI":
                mobo_sli = mobo_part.get("Support SLI", "").strip().upper()
                if mobo_sli != "Y":
                    msg = f"Motherboard does not support SLI"
                    warnings.append(msg)
                    log.warning(f"Compatibility: {msg}")
            elif gpu_multi_type == "CrossFire":
                mobo_cf = mobo_part.get("Support CrossFire", "").strip().upper()
                if mobo_cf != "Y":
                    msg = f"Motherboard does not support CrossFire"
                    warnings.append(msg)
                    log.warning(f"Compatibility: {msg}")

    return warnings


def _get_single(build_slots, category):
    parts = build_slots.get(category, [])
    for p in parts:
        if p is not None:
            return p
    return None


def _get_list(build_slots, category):
    parts = build_slots.get(category, [])
    return [p for p in parts if p is not None]
