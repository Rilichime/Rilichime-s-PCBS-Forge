import os
import sys

# Detect if running from PyInstaller bundle
def get_bundle_dir():
    if getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS'):
        # Running from PyInstaller bundle
        return sys._MEIPASS
    else:
        # Running from source
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

BASE_DIR = get_bundle_dir()

VANILLA_DIR = os.path.join(BASE_DIR, "Vanilla")
HEM_DIR = os.path.join(BASE_DIR, "HEM")
JSON_DIR = os.path.join(BASE_DIR, "JSON")
LOGS_DIR = os.path.join(BASE_DIR, "Logs")

os.makedirs(JSON_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)

ICON_URL = "https://www.flaticon.com/free-icon/pc-tower_4617777"
ICON_DIR = os.path.join(BASE_DIR, "assets")
os.makedirs(ICON_DIR, exist_ok=True)

APP_NAME = "PCBS-Forge"
APP_VERSION = "2.0.0"

PART_CATEGORIES = [
    "Cables",
    "Case Fan",
    "Case",
    "CPU Cooler",
    "CPU",
    "GPU",
    "Motherboard",
    "PSU",
    "RAM",
    "Storage",
]

VANILLA_CSV_MAP = {
    "Cables": "Cables.csv",
    "Case Fan": "Case Fan.csv",
    "Case": "Case.csv",
    "CPU Cooler": "CPU Cooler.csv",
    "CPU": "CPU.csv",
    "GPU": "GPU.csv",
    "Motherboard": "Motherboard.csv",
    "PSU": "PSU.csv",
    "RAM": "RAM.csv",
    "Storage": "Storage.csv",
}

HEM_CSV_MAP = {
    "Cables": "Cables.csv",
    "Case Fan": "Case Fans.csv",
    "Case": "Cases.csv",
    "CPU Cooler": "CPU Coolers.csv",
    "CPU": "CPUs.csv",
    "GPU": "GPUs.csv",
    "Motherboard": "Motherboards.csv",
    "PSU": "Power Supplies.csv",
    "RAM": "Memory.csv",
    "Storage": "Storage.csv",
}

BUILD_SLOTS = {
    "Case": 1,
    "PSU": 1,
    "Motherboard": 1,
    "CPU": 1,
    "GPU": 2,
    "RAM": 4,
    "CPU Cooler": 1,
    "Case Fan": 4,
    "Storage": 8,
}

BUILD_SLOT_ORDER = [
    "Case",
    "PSU",
    "Motherboard",
    "CPU",
    "GPU",
    "RAM",
    "CPU Cooler",
    "Case Fan",
    "Storage",
]

JOB_SLOT_ORDER = [
    "Case",
    "PSU",
    "Motherboard",
    "CPU",
    "GPU",
    "RAM",
    "CPU Cooler",
    "Case Fan",
    "Storage",
]

JOB_SLOTS = {
    "Case": 1,
    "PSU": 1,
    "Motherboard": 1,
    "CPU": 1,
    "GPU": 2,
    "RAM": 4,
    "CPU Cooler": 1,
    "Case Fan": 4,
    "Storage": 8,
}

JOB_PART_CATEGORIES = [
    "CPU Cooler",
    "CPU",
    "GPU",
    "Motherboard",
    "PSU",
    "RAM",
    "Storage",
]

DEFAULT_PART_PRIORITY = [
    "CPU",
    "GPU",
    "Motherboard",
    "RAM",
    "PSU",
    "Storage",
    "CPU Cooler",
    "Case Fan",
]

COLORS = {
    "bg_dark": "#252525",
    "bg_medium": "#1d1d1d",
    "bg_card": "#1d1d1d",
    "bg_input": "#1a1a1a",
    "bg_header": "#1d1d1d",
    "bg_row_even": "#252525",
    "bg_row_odd": "#2a2a2a",
    "bg_hover": "#3a3a3a",
    "bg_selected": "#f9AA33",
    "bg_button": "#f9AA33",
    "bg_button_hover": "#ffbb55",
    "bg_button_danger": "#8b2252",
    "bg_button_danger_hover": "#a52a6a",
    "bg_button_success": "#2e7d32",
    "bg_button_success_hover": "#388e3c",
    "bg_tab_active": "#f9AA33",
    "bg_tab_inactive": "#1d1d1d",
    "bg_tab_hover": "#3a3a3a",
    "bg_filter": "#1d1d1d",
    "bg_accordion": "#1a1a1a",
    "bg_warning": "#3e2723",
    "bg_info": "#1a237e",
    "bg_popup": "#1d1d1d",
    "bg_scrollbar": "#3a3a3a",
    "bg_scrollbar_thumb": "#f9AA33",
    "fg_primary": "#e0e0e0",
    "fg_secondary": "#a0a0a0",
    "fg_accent": "#f9AA33",
    "fg_button": "#1a1a1a",
    "fg_warning": "#ffb74d",
    "fg_error": "#ef5350",
    "fg_success": "#66bb6a",
    "fg_muted": "#808080",
    "fg_header": "#ffffff",
    "border": "#3a3a3a",
    "border_light": "#4a4a4a",
    "border_accent": "#f9AA33",
}

FONT_FAMILY = "Segoe UI"
FONT_SIZE_BASE = 10
FONT_SIZE_SMALL = 9
FONT_SIZE_LARGE = 12
FONT_SIZE_TITLE = 14
FONT_SIZE_HEADER = 16

SPACING = {
    "xs": 5,
    "sm": 10,
    "md": 15,
    "lg": 20,
    "xl": 25,
    "xxl": 30,
}

FILTER_PANEL_WIDTH = 400
ROW_HEIGHT = 30
HEADER_HEIGHT = 35
MAX_FILTER_VALUES = 50
DEBOUNCE_SAVE_MS = 1500
SEARCH_DEBOUNCE_MS = 200

JSON_FILES = {
    "used_parts": os.path.join(JSON_DIR, "used_parts.json"),
    "new_parts": os.path.join(JSON_DIR, "new_parts.json"),
    "builds": os.path.join(JSON_DIR, "builds.json"),
    "jobs": os.path.join(JSON_DIR, "jobs.json"),
    "settings": os.path.join(JSON_DIR, "settings.json"),
}

DEFAULT_SETTINGS = {
    "hem_enabled": False,
    "text_scale": 1.0,
    "closed_tips": [],
    "column_display": {},
    "part_priority": [
        "CPU",
        "GPU",
        "Motherboard",
        "RAM",
        "PSU",
        "Storage",
        "CPU Cooler",
        "Case Fan",
    ],
}
