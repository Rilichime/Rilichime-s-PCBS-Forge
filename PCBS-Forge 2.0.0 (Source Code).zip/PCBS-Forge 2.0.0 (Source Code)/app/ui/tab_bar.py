import tkinter as tk
from app.config import COLORS, FONT_FAMILY, FONT_SIZE_BASE, SPACING


class TabBar(tk.Frame):
    def __init__(self, parent, tabs, command=None, **kwargs):
        super().__init__(parent, bg=COLORS["bg_header"], **kwargs)
        self._tabs = tabs
        self._command = command
        self._active = None
        self._buttons = {}

        for tab_name in tabs:
            btn = tk.Label(
                self, text=tab_name.upper(),
                bg=COLORS["bg_tab_inactive"],
                fg=COLORS["fg_secondary"],
                font=(FONT_FAMILY, FONT_SIZE_BASE, "bold"),
                padx=SPACING["md"], pady=SPACING["xs"] + 2,
                cursor="hand2",
            )
            btn.pack(side="left", padx=(0, 1))
            btn.bind("<Button-1>", lambda e, n=tab_name: self._on_click(n))
            btn.bind("<Enter>", lambda e, n=tab_name: self._on_enter(n))
            btn.bind("<Leave>", lambda e, n=tab_name: self._on_leave(n))
            self._buttons[tab_name] = btn

        if tabs:
            self.set_active(tabs[0])

    def _on_click(self, name):
        self.set_active(name)
        if self._command:
            self._command(name)

    def _on_enter(self, name):
        if name != self._active:
            self._buttons[name].configure(bg=COLORS["bg_tab_hover"])

    def _on_leave(self, name):
        if name != self._active:
            self._buttons[name].configure(bg=COLORS["bg_tab_inactive"])

    def set_active(self, name):
        if name not in self._buttons:
            return
        self._active = name
        for tab_name, btn in self._buttons.items():
            if tab_name == name:
                btn.configure(
                    bg=COLORS["bg_tab_active"],
                    fg=COLORS["fg_button"],
                )
            else:
                btn.configure(
                    bg=COLORS["bg_tab_inactive"],
                    fg=COLORS["fg_secondary"],
                )

    def get_active(self):
        return self._active

    def update_font_size(self, size):
        for btn in self._buttons.values():
            btn.configure(font=(FONT_FAMILY, size, "bold"))


class SubTabBar(tk.Frame):
    def __init__(self, parent, tabs, command=None, **kwargs):
        super().__init__(parent, bg=COLORS["bg_dark"], **kwargs)
        self._tabs = tabs
        self._command = command
        self._active = None
        self._buttons = {}

        container = tk.Frame(self, bg=COLORS["bg_dark"])
        container.pack(fill="x", padx=SPACING["xs"], pady=(SPACING["xs"], 0))

        for tab_name in tabs:
            btn = tk.Label(
                container, text=tab_name,
                bg=COLORS["bg_dark"],
                fg=COLORS["fg_secondary"],
                font=(FONT_FAMILY, FONT_SIZE_BASE - 1),
                padx=SPACING["sm"], pady=SPACING["xs"],
                cursor="hand2",
            )
            btn.pack(side="left", padx=(0, 2))
            btn.bind("<Button-1>", lambda e, n=tab_name: self._on_click(n))
            btn.bind("<Enter>", lambda e, n=tab_name: self._on_enter(n))
            btn.bind("<Leave>", lambda e, n=tab_name: self._on_leave(n))
            self._buttons[tab_name] = btn

        if tabs:
            self.set_active(tabs[0])

    def _on_click(self, name):
        self.set_active(name)
        if self._command:
            self._command(name)

    def _on_enter(self, name):
        if name != self._active:
            self._buttons[name].configure(fg=COLORS["fg_secondary"])

    def _on_leave(self, name):
        if name != self._active:
            self._buttons[name].configure(fg=COLORS["fg_secondary"])

    def set_active(self, name):
        if name not in self._buttons:
            return
        self._active = name
        for tab_name, btn in self._buttons.items():
            if tab_name == name:
                btn.configure(
                    bg=COLORS["bg_tab_active"],
                    fg=COLORS["fg_button"],
                )
            else:
                btn.configure(
                    bg=COLORS["bg_dark"],
                    fg=COLORS["fg_muted"],
                )

    def get_active(self):
        return self._active

    def update_font_size(self, size):
        s = max(size - 1, 8)
        scale = s / max(FONT_SIZE_BASE - 1, 8)
        for btn in self._buttons.values():
            btn.configure(font=(FONT_FAMILY, s))
            # Scale padding to accommodate larger text
            new_pady = max(2, int(SPACING["xs"] * scale))
            btn.configure(pady=new_pady, padx=max(4, int(SPACING["sm"] * scale)))
