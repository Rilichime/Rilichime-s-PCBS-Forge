import tkinter as tk
import time
import queue
from app.config import (
    COLORS, FONT_FAMILY, FONT_SIZE_BASE, APP_NAME, APP_VERSION,
)
from app.ui.tab_bar import TabBar
from app.ui.parts_tab import PartsTab
from app.ui.builds_tab import BuildsTab
from app.ui.jobs_tab import JobsTab
from app.ui.settings_tab import SettingsTab
from app.state_manager import StateManager
from app.csv_loader import load_csvs_background
from app.icon_manager import download_and_convert_icon
from app.logger import setup_logger, get_logger


class MainWindow:
    def __init__(self):
        self._log = get_logger("App")
        self._log.info(f"Starting {APP_NAME} v{APP_VERSION}")

        self._root = tk.Tk()
        self._root.title(f"{APP_NAME} v{APP_VERSION}")
        self._root.geometry("1400x850")
        self._root.minsize(1000, 600)
        self._root.configure(bg=COLORS["bg_dark"])

        self._set_icon()

        # Show loading overlay immediately
        self._loading_start_time = time.time()
        self._catalog_ready = False
        self._loading_overlay = self._create_loading_overlay()

        self._state = StateManager()
        self._state.initialize()
        self._log.info("State manager initialized")

        self._result_queue = queue.Queue()

        self._main_tabs = ["Used Parts", "New Parts", "Builds", "Jobs", "Settings"]

        self._tab_bar = TabBar(
            self._root, self._main_tabs,
            command=self._on_main_tab_change,
        )
        self._tab_bar.pack(fill="x")

        self._content = tk.Frame(self._root, bg=COLORS["bg_dark"])
        self._content.pack(fill="both", expand=True)

        self._tab_frames = {}

        self._used_parts_tab = PartsTab(
            self._content, self._state, inventory_type="used",
        )
        self._tab_frames["Used Parts"] = self._used_parts_tab

        self._new_parts_tab = PartsTab(
            self._content, self._state, inventory_type="new",
        )
        self._tab_frames["New Parts"] = self._new_parts_tab

        self._builds_tab = BuildsTab(
            self._content, self._state,
        )
        self._tab_frames["Builds"] = self._builds_tab

        self._jobs_tab = JobsTab(
            self._content, self._state,
        )
        self._tab_frames["Jobs"] = self._jobs_tab

        self._settings_tab = SettingsTab(
            self._content, self._state,
            on_scale_change=self._on_text_scale_change,
        )
        self._tab_frames["Settings"] = self._settings_tab

        self._show_tab("Used Parts")

        hem_enabled = self._state.get_setting("hem_enabled", False)
        load_csvs_background(hem_enabled=hem_enabled, result_queue=self._result_queue)

        self._poll_queue()

        self._root.protocol("WM_DELETE_WINDOW", self._on_close)

        scale = self._state.get_setting("text_scale", 1.0)
        if scale != 1.0:
            self._on_text_scale_change(scale)

    def _create_loading_overlay(self):
        """Create a full-window loading overlay on top of all UI."""
        overlay = tk.Frame(self._root, bg=COLORS["bg_medium"])
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        overlay.lift()

        # Center container
        center = tk.Frame(overlay, bg=COLORS["bg_medium"])
        center.place(relx=0.5, rely=0.45, anchor="center")

        # App name
        tk.Label(
            center, text=APP_NAME,
            bg=COLORS["bg_medium"], fg=COLORS["fg_accent"],
            font=(FONT_FAMILY, 28, "bold"),
        ).pack(pady=(0, 4))

        # Version
        tk.Label(
            center, text=f"v{APP_VERSION}",
            bg=COLORS["bg_medium"], fg=COLORS["fg_muted"],
            font=(FONT_FAMILY, 11),
        ).pack(pady=(0, 32))

        # Separator line
        tk.Frame(
            center, bg=COLORS["border"], height=1,
        ).pack(fill="x", padx=40, pady=(0, 24))

        # Loading text
        self._loading_label = tk.Label(
            center, text="Loading parts catalog...",
            bg=COLORS["bg_medium"], fg=COLORS["fg_secondary"],
            font=(FONT_FAMILY, FONT_SIZE_BASE),
        )
        self._loading_label.pack(pady=(0, 16))

        # Progress bar track
        bar_width = 300
        bar_height = 3
        progress = tk.Canvas(
            center, bg=COLORS["bg_dark"], highlightthickness=0, bd=0,
            height=bar_height, width=bar_width,
        )
        progress.pack()

        # Animated indicator — smooth sweeping bar
        ind_width = 90
        indicator = progress.create_rectangle(
            0, 0, ind_width, bar_height,
            fill=COLORS["fg_accent"], outline="",
        )

        self._loading_anim_dir = 1

        def animate():
            try:
                if not overlay.winfo_exists():
                    return
            except tk.TclError:
                return
            x1, _, x2, _ = progress.coords(indicator)
            if x2 >= bar_width:
                self._loading_anim_dir = -1
            elif x1 <= 0:
                self._loading_anim_dir = 1
            progress.move(indicator, 4 * self._loading_anim_dir, 0)
            overlay.after(30, animate)

        animate()
        return overlay

    def _set_icon(self):
        try:
            icon_path = download_and_convert_icon()
            if icon_path:
                import sys
                if sys.platform == "win32" and icon_path.endswith(".ico"):
                    self._root.iconbitmap(icon_path)
                else:
                    from PIL import Image, ImageTk
                    img = Image.open(icon_path)
                    photo = ImageTk.PhotoImage(img)
                    self._root.iconphoto(True, photo)
                    self._icon_ref = photo
                self._log.info(f"Icon set: {icon_path}")
        except Exception as e:
            self._log.warning(f"Could not set icon: {e}")

    def _show_tab(self, name):
        for tab_name, frame in self._tab_frames.items():
            if tab_name == name:
                frame.pack(fill="both", expand=True)
            else:
                frame.pack_forget()

    def _on_main_tab_change(self, name):
        self._show_tab(name)

    def _dismiss_loading_overlay(self):
        """Remove the loading overlay from the window."""
        if self._loading_overlay is not None:
            try:
                if self._loading_overlay.winfo_exists():
                    self._loading_overlay.destroy()
            except tk.TclError:
                pass
            self._loading_overlay = None

    def _try_dismiss_loading(self):
        """Dismiss loading overlay only after catalog is ready AND minimum time has passed."""
        if not self._catalog_ready:
            return
        elapsed = time.time() - self._loading_start_time
        remaining = 10.0 - elapsed
        if remaining > 0:
            self._root.after(int(remaining * 1000), self._dismiss_loading_overlay)
        else:
            self._dismiss_loading_overlay()

    def _poll_queue(self):
        try:
            while True:
                msg = self._result_queue.get_nowait()
                if msg[0] == "catalog_loaded":
                    catalog = msg[1]
                    column_map = msg[2]
                    self._state.set_catalog(catalog, column_map)
                    self._log.info(f"Catalog loaded")
                    self._catalog_ready = True
                    # Update label text
                    try:
                        if self._loading_label.winfo_exists():
                            self._loading_label.configure(text="Preparing workspace...")
                    except (tk.TclError, AttributeError):
                        pass
                    self._try_dismiss_loading()
        except queue.Empty:
            pass
        self._root.after(100, self._poll_queue)

    def _on_text_scale_change(self, scale):
        scale = float(scale)
        new_size = max(8, int(FONT_SIZE_BASE * scale))

        self._tab_bar.update_font_size(new_size)
        self._used_parts_tab.update_font_size(new_size)
        self._new_parts_tab.update_font_size(new_size)
        self._builds_tab.update_font_size(new_size)
        self._jobs_tab.update_font_size(new_size)
        self._settings_tab.update_font_size(new_size)

    def _on_close(self):
        self._log.info("Application closing, flushing saves...")
        self._state.flush_saves()
        self._root.destroy()

    def run(self):
        self._log.info("Main loop started")
        self._root.mainloop()
