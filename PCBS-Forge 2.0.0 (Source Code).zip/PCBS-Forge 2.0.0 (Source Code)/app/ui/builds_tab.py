import tkinter as tk
from app.config import COLORS, FONT_FAMILY, FONT_SIZE_BASE, FONT_SIZE_SMALL, FONT_SIZE_LARGE, SPACING, BUILD_SLOT_ORDER, BUILD_SLOTS
from app.ui.widgets import FlatButton, InfoBox
from app.ui.dialogs import show_confirmation, show_input_dialog
from app.scoring import calculate_3dmark, calculate_build_value
from app.compatibility import check_compatibility
from app.logger import get_logger

log = get_logger("Builds")


class BuildsTab(tk.Frame):
    def __init__(self, parent, state_manager, **kwargs):
        super().__init__(parent, bg=COLORS["bg_dark"], **kwargs)
        self._state = state_manager

        self._info_box = InfoBox(
            self,
            text="This section is designed to help you build PCs to sell on PCBay. It will only take parts from the Used Parts inventory.",
            tip_id="builds_info",
            state_manager=state_manager,
        )
        self._info_box.pack(fill="x", padx=SPACING["sm"], pady=(SPACING["sm"], 0))

        top_buttons = tk.Frame(self, bg=COLORS["bg_dark"])
        top_buttons.pack(fill="x", padx=SPACING["sm"], pady=SPACING["sm"])

        self._create_btn = FlatButton(
            top_buttons, text="Create", command=self._on_create,
            bg="#33f95d", hover_bg="#2ad94f",
            width=90, height=30,
        )
        self._create_btn.pack(side="left", padx=(0, SPACING["xs"]))

        self._rename_btn = FlatButton(
            top_buttons, text="Rename", command=self._on_rename,
            width=90, height=30,
        )
        self._rename_btn.pack(side="left", padx=(0, SPACING["xs"]))

        self._delete_btn = FlatButton(
            top_buttons, text="Delete", command=self._on_delete,
            bg="#f93333", hover_bg="#d62a2a",
            width=90, height=30,
        )
        self._delete_btn.pack(side="left", padx=(0, SPACING["xs"]))

        self._complete_btn = FlatButton(
            top_buttons, text="Complete", command=self._on_complete,
            bg="#33d1f9", hover_bg="#2ab8d6",
            width=100, height=30,
        )
        self._complete_btn.pack(side="left")

        main_area = tk.Frame(self, bg=COLORS["bg_dark"])
        main_area.pack(fill="both", expand=True, padx=SPACING["sm"], pady=(0, SPACING["sm"]))

        self._build_list_frame = tk.Frame(main_area, bg=COLORS["bg_card"], width=220)
        self._build_list_frame.pack(side="left", fill="y", padx=(0, SPACING["sm"]))
        self._build_list_frame.pack_propagate(False)
        self._base_list_width = 220  # Store base width for scaling

        self._list_label = tk.Label(
            self._build_list_frame, text="Builds", bg=COLORS["bg_card"],
            fg=COLORS["fg_header"], font=(FONT_FAMILY, FONT_SIZE_BASE, "bold"),
            anchor="w", padx=SPACING["sm"], pady=SPACING["xs"],
        )
        self._list_label.pack(fill="x")

        self._build_listbox_frame = tk.Frame(self._build_list_frame, bg=COLORS["bg_card"])
        self._build_listbox_frame.pack(fill="both", expand=True)

        self._build_listbox = tk.Listbox(
            self._build_listbox_frame, bg=COLORS["bg_card"], fg=COLORS["fg_primary"],
            font=(FONT_FAMILY, FONT_SIZE_BASE),
            selectbackground=COLORS["bg_selected"],
            selectforeground=COLORS["fg_button"],
            highlightthickness=0, bd=0, relief="flat",
            activestyle="none",
        )
        lb_scroll = tk.Scrollbar(self._build_listbox_frame, orient="vertical", command=self._build_listbox.yview)
        self._build_listbox.configure(yscrollcommand=lb_scroll.set)
        lb_scroll.pack(side="right", fill="y")
        self._build_listbox.pack(side="left", fill="both", expand=True)
        self._build_listbox.bind("<<ListboxSelect>>", self._on_build_select)

        self._detail_frame = tk.Frame(main_area, bg=COLORS["bg_dark"])
        self._detail_frame.pack(side="left", fill="both", expand=True)

        self._detail_canvas = tk.Canvas(
            self._detail_frame, bg=COLORS["bg_dark"], highlightthickness=0, bd=0,
        )
        self._detail_scroll = tk.Scrollbar(
            self._detail_frame, orient="vertical", command=self._detail_canvas.yview,
        )
        self._detail_canvas.configure(yscrollcommand=self._detail_scroll.set)
        self._detail_scroll.pack(side="right", fill="y")
        self._detail_canvas.pack(side="left", fill="both", expand=True)

        self._detail_inner = tk.Frame(self._detail_canvas, bg=COLORS["bg_dark"])
        self._detail_window = self._detail_canvas.create_window((0, 0), window=self._detail_inner, anchor="nw")

        self._detail_inner.bind("<Configure>", lambda e: self._detail_canvas.configure(scrollregion=self._detail_canvas.bbox("all")))
        self._detail_canvas.bind("<Configure>", lambda e: self._detail_canvas.itemconfig(self._detail_window, width=e.width))
        self._detail_canvas.bind("<MouseWheel>", lambda e: self._detail_canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))

        self._stats_frame = tk.Frame(self._detail_inner, bg=COLORS["bg_card"])
        self._stats_frame.pack(fill="x", pady=(0, SPACING["sm"]))

        self._value_label = tk.Label(
            self._stats_frame, text="Value: $0", bg=COLORS["bg_card"],
            fg=COLORS["fg_success"], font=(FONT_FAMILY, FONT_SIZE_LARGE, "bold"),
            padx=SPACING["sm"], pady=SPACING["xs"],
        )
        self._value_label.pack(side="left")

        self._3dmark_label = tk.Label(
            self._stats_frame, text="3DMark Score: 0", bg=COLORS["bg_card"],
            fg=COLORS["fg_accent"], font=(FONT_FAMILY, FONT_SIZE_LARGE, "bold"),
            padx=SPACING["sm"], pady=SPACING["xs"],
        )
        self._3dmark_label.pack(side="left", padx=(SPACING["lg"], 0))

        self._compat_frame = tk.Frame(self._detail_inner, bg=COLORS["bg_dark"])
        self._compat_frame.pack(fill="x", pady=(0, SPACING["sm"]))

        self._slots_frame = tk.Frame(self._detail_inner, bg=COLORS["bg_dark"])
        self._slots_frame.pack(fill="x")

        self._slot_widgets = {}
        self._current_font_size = FONT_SIZE_BASE

        self._state.subscribe("builds", self._refresh)
        self._state.subscribe("active_build", self._refresh)
        self._state.subscribe("used_parts", self._refresh)
        self._state.subscribe("settings", self._on_settings_change)

        self.after(100, self._refresh)

    def _refresh(self):
        self._refresh_build_list()
        self._refresh_detail()

    def _refresh_build_list(self):
        self._build_listbox.delete(0, "end")
        active_id = self._state.active_build_id
        select_idx = None

        for i, build in enumerate(self._state.builds):
            self._build_listbox.insert("end", build["name"])
            if build["id"] == active_id:
                select_idx = i

        if select_idx is not None:
            self._build_listbox.selection_set(select_idx)
            self._build_listbox.see(select_idx)

    def _refresh_detail(self):
        build = self._state.get_active_build()

        if build is None:
            self._value_label.configure(text="Value: $0")
            self._3dmark_label.configure(text="3DMark Score: 0")
            for widget in self._compat_frame.winfo_children():
                widget.destroy()
            for widget in self._slots_frame.winfo_children():
                widget.destroy()

            no_build = tk.Label(
                self._slots_frame, text="No build selected. Create a build to get started.",
                bg=COLORS["bg_dark"], fg=COLORS["fg_muted"],
                font=(FONT_FAMILY, self._current_font_size),
            )
            no_build.pack(pady=SPACING["xl"])
            return

        build_parts = self._state.get_build_parts(build["id"])

        all_parts_flat = []
        cpu_data = None
        gpu_parts = []
        ram_parts = []

        for cat in BUILD_SLOT_ORDER:
            slots = build_parts.get(cat, [])
            for slot_part in slots:
                if slot_part is not None:
                    part_data_obj = slot_part.get("data", {}) if isinstance(slot_part, dict) else {}
                    all_parts_flat.append(part_data_obj)
                    if cat == "CPU":
                        cpu_data = part_data_obj
                    elif cat == "GPU":
                        gpu_parts.append(part_data_obj)
                    elif cat == "RAM":
                        ram_parts.append(part_data_obj)

        three_d = calculate_3dmark(cpu_data, gpu_parts, ram_parts)
        value = calculate_build_value(all_parts_flat, three_d)

        self._value_label.configure(text=f"Value: ${value:,}")
        self._3dmark_label.configure(text=f"3DMark Score: {three_d:,}")

        compat_slots = {}
        for cat in BUILD_SLOT_ORDER:
            slots = build_parts.get(cat, [])
            resolved = []
            for sp in slots:
                if sp is not None:
                    resolved.append(sp.get("data", {}) if isinstance(sp, dict) else {})
                else:
                    resolved.append(None)
            compat_slots[cat] = resolved

        warnings = check_compatibility(compat_slots)

        for widget in self._compat_frame.winfo_children():
            widget.destroy()

        if warnings:
            warn_header = tk.Label(
                self._compat_frame,
                text="⚠ WARNING! Selected parts are not compatible!",
                bg=COLORS["bg_warning"], fg=COLORS["fg_warning"],
                font=(FONT_FAMILY, self._current_font_size, "bold"),
                anchor="w", padx=SPACING["sm"], pady=SPACING["xs"],
            )
            warn_header.pack(fill="x")

            for w in warnings:
                warn_line = tk.Label(
                    self._compat_frame, text=f"  • {w}",
                    bg=COLORS["bg_warning"], fg=COLORS["fg_warning"],
                    font=(FONT_FAMILY, max(self._current_font_size - 1, 8)),
                    anchor="w", padx=SPACING["sm"], wraplength=1400, justify="left",
                )
                warn_line.pack(fill="x")

        for widget in self._slots_frame.winfo_children():
            widget.destroy()

        for cat in BUILD_SLOT_ORDER:
            max_slots = BUILD_SLOTS.get(cat, 1)
            slots = build_parts.get(cat, [None] * max_slots)

            cat_frame = tk.Frame(self._slots_frame, bg=COLORS["bg_card"])
            cat_frame.pack(fill="x", pady=(0, SPACING["xs"]))

            cat_label = tk.Label(
                cat_frame, text=f"{cat}  ({max_slots} slot{'s' if max_slots > 1 else ''})",
                bg=COLORS["bg_card"], fg=COLORS["fg_header"],
                font=(FONT_FAMILY, self._current_font_size, "bold"),
                anchor="w", padx=SPACING["sm"], pady=SPACING["xs"],
            )
            cat_label.pack(fill="x")

            for i in range(max_slots):
                slot_part = slots[i] if i < len(slots) else None
                slot_frame = tk.Frame(cat_frame, bg=COLORS["bg_card"])
                slot_frame.pack(fill="x", padx=SPACING["sm"], pady=(0, 2))

                if slot_part is not None:
                    part_data = slot_part.get("data", {}) if isinstance(slot_part, dict) else {}
                    part_name = part_data.get("Full Part Name", "Unknown")
                    instance_id = slot_part.get("instance_id", "") if isinstance(slot_part, dict) else ""

                    name_label = tk.Label(
                        slot_frame,
                        text=f"Slot {i + 1}: {part_name}",
                        bg=COLORS["bg_card"], fg=COLORS["fg_primary"],
                        font=(FONT_FAMILY, self._current_font_size),
                        anchor="w", cursor="hand2",
                    )
                    name_label.pack(side="left", fill="x", expand=True)
                    name_label.bind("<Double-Button-1>", lambda e, n=part_name: self._copy_name(n))

                    remove_btn = tk.Label(
                        slot_frame, text="✕",
                        bg="#f93333", fg=COLORS["fg_primary"],
                        font=(FONT_FAMILY, max(self._current_font_size - 1, 8), "bold"),
                        padx=6, pady=1, cursor="hand2",
                    )
                    remove_btn.pack(side="right", padx=(SPACING["xs"], 0))
                    remove_btn.bind(
                        "<Button-1>",
                        lambda e, bid=build["id"], iid=instance_id: self._on_remove_part(bid, iid),
                    )
                else:
                    empty_label = tk.Label(
                        slot_frame,
                        text=f"Slot {i + 1}: [EMPTY]",
                        bg=COLORS["bg_card"], fg=COLORS["fg_muted"],
                        font=(FONT_FAMILY, self._current_font_size),
                        anchor="w",
                    )
                    empty_label.pack(side="left", fill="x", expand=True)

        self._bind_mousewheel_recursive(self._detail_inner)

    def _bind_mousewheel_recursive(self, widget):
        widget.bind("<MouseWheel>", lambda e: self._detail_canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))
        for child in widget.winfo_children():
            self._bind_mousewheel_recursive(child)

    def _copy_name(self, name):
        try:
            self.clipboard_clear()
            self.clipboard_append(name)
            log.debug(f"Copied to clipboard: {name}")
        except Exception:
            pass

    def _on_build_select(self, event):
        selection = self._build_listbox.curselection()
        if not selection:
            return
        idx = selection[0]
        if idx < len(self._state.builds):
            build = self._state.builds[idx]
            self._state.set_active_build(build["id"])

    def _on_create(self):
        show_input_dialog(
            self.winfo_toplevel(),
            "Create Build",
            "Enter a name for the new build:",
            self._do_create,
            font_size=self._current_font_size,
        )

    def _do_create(self, name):
        self._state.create_build(name)
        log.info(f"Created build: {name}")

    def _on_rename(self):
        build = self._state.get_active_build()
        if build is None:
            return
        show_input_dialog(
            self.winfo_toplevel(),
            "Rename Build",
            "Enter a new name:",
            lambda name: self._state.rename_build(build["id"], name),
            default_text=build["name"],
            font_size=self._current_font_size,
        )

    def _on_delete(self):
        build = self._state.get_active_build()
        if build is None:
            return
        show_confirmation(
            self.winfo_toplevel(),
            "Delete Build",
            f"Are you sure you want to delete '{build['name']}'? Parts will be returned to inventory.",
            lambda: self._state.delete_build(build["id"]),
            font_size=self._current_font_size,
        )

    def _on_complete(self):
        build = self._state.get_active_build()
        if build is None:
            return
        show_confirmation(
            self.winfo_toplevel(),
            "Complete Build",
            f"Complete '{build['name']}'? This will remove the build and all used parts from inventory.",
            lambda: self._state.complete_build(build["id"]),
            font_size=self._current_font_size,
        )

    def _on_remove_part(self, build_id, instance_id):
        self._state.remove_part_from_build(build_id, instance_id)

    def _on_settings_change(self):
        closed = self._state.get_setting("closed_tips", [])
        if "builds_info" not in closed:
            try:
                exists = self._info_box.winfo_exists()
            except Exception:
                exists = False
            if not exists:
                self._info_box = InfoBox(
                    self,
                    text="This section is designed to help you build PCs to sell on PCBay. It will only take parts from the Used Parts inventory.",
                    tip_id="builds_info",
                    state_manager=self._state,
                )
                children = self.winfo_children()
                if len(children) > 1:
                    self._info_box.pack(fill="x", padx=SPACING["sm"], pady=(SPACING["sm"], 0),
                                        before=children[0])
                else:
                    self._info_box.pack(fill="x", padx=SPACING["sm"], pady=(SPACING["sm"], 0))

    def update_font_size(self, size):
        self._current_font_size = size
        self._value_label.configure(font=(FONT_FAMILY, max(size + 2, 12), "bold"))
        self._3dmark_label.configure(font=(FONT_FAMILY, max(size + 2, 12), "bold"))
        self._build_listbox.configure(font=(FONT_FAMILY, size))
        self._list_label.configure(font=(FONT_FAMILY, size, "bold"))
        # Scale the list width proportionally with font size
        scale = size / FONT_SIZE_BASE
        new_width = int(self._base_list_width * scale)
        self._build_list_frame.configure(width=new_width)
        # Update buttons
        self._create_btn.update_font_size(size)
        self._rename_btn.update_font_size(size)
        self._delete_btn.update_font_size(size)
        self._complete_btn.update_font_size(size)
        # Update info box if it exists
        if hasattr(self, "_info_box") and self._info_box.winfo_exists():
            self._info_box.update_font_size(size)
        self._refresh_detail()
