import tkinter as tk
from app.config import COLORS, FONT_FAMILY, FONT_SIZE_BASE, FONT_SIZE_SMALL, SPACING, SEARCH_DEBOUNCE_MS
from app.logger import get_logger

log = get_logger("Search")


class SearchPanel(tk.Frame):
    def __init__(self, parent, state_manager=None, inventory_type="used", on_add=None, **kwargs):
        super().__init__(parent, bg=COLORS["bg_card"], **kwargs)
        self._state = state_manager
        self._inventory_type = inventory_type
        self._on_add = on_add
        self._debounce_id = None
        self._results = []

        container = tk.Frame(self, bg=COLORS["bg_card"], padx=SPACING["sm"], pady=SPACING["sm"])
        container.pack(fill="x")

        left = tk.Frame(container, bg=COLORS["bg_card"])
        left.pack(side="left", fill="x", expand=True)

        self._label = tk.Label(
            left, text="Search Parts:", bg=COLORS["bg_card"],
            fg=COLORS["fg_secondary"], font=(FONT_FAMILY, FONT_SIZE_SMALL),
            anchor="w",
        )
        self._label.pack(fill="x")

        self._entry = tk.Entry(
            left, bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
            insertbackground=COLORS["fg_primary"], relief="flat",
            font=(FONT_FAMILY, FONT_SIZE_BASE),
            highlightthickness=1, highlightbackground=COLORS["border"],
            highlightcolor=COLORS["border_accent"],
        )
        self._entry.pack(fill="x", pady=(2, 0))
        self._entry.bind("<KeyRelease>", self._on_key)

        right = tk.Frame(container, bg=COLORS["bg_card"], width=1050, height=250)
        right.pack(side="right", fill="both", padx=(SPACING["sm"], 0))
        right.pack_propagate(False)

        self._rec_label = tk.Label(
            right, text="Recommendations (double-click to add):",
            bg=COLORS["bg_card"], fg=COLORS["fg_secondary"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL), anchor="w",
        )
        self._rec_label.pack(fill="x")

        list_frame = tk.Frame(right, bg=COLORS["bg_input"], highlightthickness=1,
                              highlightbackground=COLORS["border"])
        list_frame.pack(fill="both", expand=True, pady=(2, 0))

        self._listbox = tk.Listbox(
            list_frame, bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL),
            selectbackground=COLORS["bg_selected"],
            selectforeground=COLORS["fg_primary"],
            highlightthickness=0, bd=0, relief="flat",
            activestyle="none",
        )
        scrollbar = tk.Scrollbar(list_frame, orient="vertical", command=self._listbox.yview)
        self._listbox.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self._listbox.pack(side="left", fill="both", expand=True)
        self._listbox.bind("<Double-Button-1>", self._on_double_click)

    def _on_key(self, event):
        if self._debounce_id:
            self.after_cancel(self._debounce_id)
        self._debounce_id = self.after(SEARCH_DEBOUNCE_MS, self._do_search)

    def _do_search(self):
        query = self._entry.get().strip()
        self._listbox.delete(0, "end")
        self._results = []

        if not query or not self._state:
            log.debug(f"Search cleared or no state")
            return

        keywords = query.lower().split()
        catalog = self._state.catalog

        matches = []
        for category, parts in catalog.items():
            for part in parts:
                name = part.get("Full Part Name", "").lower()
                if all(kw in name for kw in keywords):
                    matches.append((category, part))

        matches.sort(key=lambda x: x[1].get("Full Part Name", "").lower())
        matches = matches[:200]

        self._results = matches
        for category, part in matches:
            display = f"[{category}] {part.get('Full Part Name', '?')}"
            self._listbox.insert("end", display)

        log.debug(f"Search '{query}': {len(matches)} results")

    def _on_double_click(self, event):
        selection = self._listbox.curselection()
        if not selection:
            return
        idx = selection[0]
        if idx < len(self._results):
            category, part = self._results[idx]
            if self._on_add:
                self._on_add(category, part)
                log.info(f"Search add: {part.get('Full Part Name', '?')} [{category}]")

    def update_font_size(self, size):
        self._entry.configure(font=(FONT_FAMILY, size))
        self._listbox.configure(font=(FONT_FAMILY, max(size - 1, 8)))
        self._label.configure(font=(FONT_FAMILY, max(size - 1, 8)))
        self._rec_label.configure(font=(FONT_FAMILY, max(size - 1, 8)))
