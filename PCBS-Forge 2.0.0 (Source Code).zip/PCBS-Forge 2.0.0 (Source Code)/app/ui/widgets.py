import tkinter as tk
from app.config import COLORS, FONT_FAMILY, FONT_SIZE_BASE, SPACING


class FlatButton(tk.Canvas):
    def __init__(self, parent, text="", command=None, bg=None, fg=None,
                 hover_bg=None, width=None, height=30, font_size=None,
                 padx=15, **kwargs):
        self._bg = bg or COLORS["bg_button"]
        self._fg = fg or COLORS["fg_button"]
        self._hover_bg = hover_bg or COLORS["bg_button_hover"]
        self._command = command
        self._text = text
        self._font_size = font_size or FONT_SIZE_BASE
        self._padx = padx

        canvas_width = width if width else 1
        super().__init__(parent, width=canvas_width, height=height,
                         bg=parent.cget("bg") if hasattr(parent, "cget") else COLORS["bg_dark"],
                         highlightthickness=0, bd=0, **kwargs)

        self._rect = self.create_rectangle(0, 0, canvas_width, height, fill=self._bg, outline="")
        self._label = self.create_text(
            canvas_width // 2, height // 2, text=text,
            fill=self._fg, font=(FONT_FAMILY, self._font_size),
            anchor="center"
        )

        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<Button-1>", self._on_click)
        self.bind("<Configure>", self._on_resize)

        if width is None:
            self.after(10, self._auto_size)

    def _auto_size(self):
        bbox = self.bbox(self._label)
        if bbox:
            text_width = bbox[2] - bbox[0]
            new_width = text_width + self._padx * 2
            self.configure(width=new_width)
            h = int(self.cget("height"))
            self.coords(self._rect, 0, 0, new_width, h)
            self.coords(self._label, new_width // 2, h // 2)

    def _on_resize(self, event):
        w = event.width
        h = event.height
        self.coords(self._rect, 0, 0, w, h)
        self.coords(self._label, w // 2, h // 2)

    def _on_enter(self, event):
        self.itemconfig(self._rect, fill=self._hover_bg)
        self.configure(cursor="hand2")

    def _on_leave(self, event):
        self.itemconfig(self._rect, fill=self._bg)
        self.configure(cursor="")

    def _on_click(self, event):
        if self._command:
            self._command()

    def set_text(self, text):
        self._text = text
        self.itemconfig(self._label, text=text)
        self._auto_size()

    def set_state(self, enabled):
        if enabled:
            self.bind("<Button-1>", self._on_click)
            self.itemconfig(self._label, fill=self._fg)
            self.itemconfig(self._rect, fill=self._bg)
        else:
            self.unbind("<Button-1>")
            self.itemconfig(self._label, fill=COLORS["fg_muted"])
            self.itemconfig(self._rect, fill=COLORS["bg_header"])

    def update_font_size(self, size):
        self._font_size = size
        self.itemconfig(self._label, font=(FONT_FAMILY, size))
        new_height = max(30, int(size * 2.5))
        self.configure(height=new_height)
        self._auto_size()


class DarkEntry(tk.Entry):
    def __init__(self, parent, **kwargs):
        defaults = {
            "bg": COLORS["bg_input"],
            "fg": COLORS["fg_primary"],
            "insertbackground": COLORS["fg_primary"],
            "relief": "flat",
            "font": (FONT_FAMILY, FONT_SIZE_BASE),
            "highlightthickness": 1,
            "highlightbackground": COLORS["border"],
            "highlightcolor": COLORS["border_accent"],
        }
        defaults.update(kwargs)
        super().__init__(parent, **defaults)


class DarkCheckbutton(tk.Frame):
    def __init__(self, parent, text="", variable=None, command=None, font_size=None, **kwargs):
        super().__init__(parent, bg=COLORS["bg_card"], **kwargs)

        self._var = variable or tk.BooleanVar(value=False)
        self._command = command
        self._font_size = font_size or FONT_SIZE_BASE
        self._box_size = max(16, int(self._font_size * 1.2))

        self._canvas = tk.Canvas(
            self, width=self._box_size, height=self._box_size,
            bg=COLORS["bg_card"], highlightthickness=0, bd=0,
            cursor="hand2",
        )
        self._canvas.pack(side="left")
        self._canvas.bind("<Button-1>", lambda e: self._toggle())

        self._label = tk.Label(
            self, text=text, bg=COLORS["bg_card"],
            fg=COLORS["fg_primary"],
            font=(FONT_FAMILY, self._font_size),
        )
        self._label.pack(side="left", padx=(5, 0))
        self._label.bind("<Button-1>", lambda e: self._toggle())

        # Trace variable changes
        self._var.trace_add("write", lambda *args: self._draw_checkbox())
        self._draw_checkbox()

    def _draw_checkbox(self):
        self._canvas.delete("all")
        checked = self._var.get()
        size = self._box_size
        padding = 2

        # Draw checkbox background
        if checked:
            self._canvas.create_rectangle(
                padding, padding, size - padding, size - padding,
                fill=COLORS["bg_input"], outline=COLORS["fg_primary"], width=2,
            )
            # Draw checkmark
            margin = size // 4
            self._canvas.create_line(
                margin, size // 2,
                size // 2 - 2, size - margin - 2,
                fill=COLORS["fg_primary"], width=2,
            )
            self._canvas.create_line(
                size // 2 - 2, size - margin - 2,
                size - margin, margin,
                fill=COLORS["fg_primary"], width=2,
            )
        else:
            self._canvas.create_rectangle(
                padding, padding, size - padding, size - padding,
                fill=COLORS["bg_card"], outline=COLORS["fg_secondary"], width=2,
            )

    def _toggle(self):
        self._var.set(not self._var.get())
        self._on_toggle()

    def _on_toggle(self):
        if self._command:
            self._command()

    def get(self):
        return self._var.get()

    def set(self, value):
        self._var.set(value)

    def update_font_size(self, size):
        self._font_size = size
        self._box_size = max(16, int(size * 1.2))
        self._canvas.configure(width=self._box_size, height=self._box_size)
        self._label.configure(font=(FONT_FAMILY, size))
        self._draw_checkbox()


class InfoBox(tk.Frame):
    def __init__(self, parent, text="", tip_id="", state_manager=None, **kwargs):
        super().__init__(parent, bg=COLORS["bg_info"], **kwargs)
        self._tip_id = tip_id
        self._state = state_manager

        if self._state and tip_id:
            closed = self._state.get_setting("closed_tips", [])
            if tip_id in closed:
                return

        inner = tk.Frame(self, bg=COLORS["bg_info"], padx=SPACING["sm"], pady=SPACING["sm"])
        inner.pack(fill="x", expand=True)

        self._label = tk.Label(
            inner, text=text, bg=COLORS["bg_info"],
            fg=COLORS["fg_primary"], font=(FONT_FAMILY, FONT_SIZE_BASE),
            wraplength=1400, justify="left", anchor="w",
        )
        self._label.pack(side="left", fill="x", expand=True)

        close_btn = tk.Label(
            inner, text="✕", bg=COLORS["bg_info"],
            fg=COLORS["fg_secondary"], font=(FONT_FAMILY, FONT_SIZE_BASE),
            cursor="hand2",
        )
        close_btn.pack(side="right", padx=(SPACING["sm"], 0))
        close_btn.bind("<Button-1>", self._close)

    def _close(self, event=None):
        if self._state and self._tip_id:
            closed = list(self._state.get_setting("closed_tips", []))
            if self._tip_id not in closed:
                closed.append(self._tip_id)
                self._state.update_setting("closed_tips", closed)
        self.pack_forget()
        self.destroy()

    def update_font_size(self, size):
        self._label.configure(font=(FONT_FAMILY, size))


class ScrollableFrame(tk.Frame):
    def __init__(self, parent, bg=None, **kwargs):
        bg = bg or COLORS["bg_dark"]
        super().__init__(parent, bg=bg, **kwargs)

        self._canvas = tk.Canvas(self, bg=bg, highlightthickness=0, bd=0)
        self._v_scrollbar = tk.Scrollbar(self, orient="vertical", command=self._canvas.yview)
        self._h_scrollbar = tk.Scrollbar(self, orient="horizontal", command=self._canvas.xview)

        self._canvas.configure(yscrollcommand=self._v_scrollbar.set, xscrollcommand=self._h_scrollbar.set)

        self._v_scrollbar.pack(side="right", fill="y")
        self._h_scrollbar.pack(side="bottom", fill="x")
        self._canvas.pack(side="left", fill="both", expand=True)

        self.interior = tk.Frame(self._canvas, bg=bg)
        self._window_id = self._canvas.create_window((0, 0), window=self.interior, anchor="nw")

        self.interior.bind("<Configure>", self._on_interior_configure)
        self._canvas.bind("<Configure>", self._on_canvas_configure)
        self._canvas.bind("<MouseWheel>", self._on_mousewheel)
        self._canvas.bind("<Shift-MouseWheel>", self._on_shift_mousewheel)
        self.interior.bind("<MouseWheel>", self._on_mousewheel)
        self.interior.bind("<Shift-MouseWheel>", self._on_shift_mousewheel)

    def _on_interior_configure(self, event):
        self._canvas.configure(scrollregion=self._canvas.bbox("all"))

    def _on_canvas_configure(self, event):
        self._canvas.itemconfig(self._window_id, width=event.width)

    def _on_mousewheel(self, event):
        self._canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def _on_shift_mousewheel(self, event):
        self._canvas.xview_scroll(int(-1 * (event.delta / 120)), "units")

    def bind_mousewheel_recursive(self, widget):
        widget.bind("<MouseWheel>", self._on_mousewheel)
        widget.bind("<Shift-MouseWheel>", self._on_shift_mousewheel)
        for child in widget.winfo_children():
            self.bind_mousewheel_recursive(child)


class DarkDropdown(tk.Frame):
    def __init__(self, parent, values=None, variable=None, command=None, width=20, **kwargs):
        super().__init__(parent, bg=COLORS["bg_input"], highlightthickness=1,
                         highlightbackground=COLORS["border"], **kwargs)
        self._values = values or []
        self._var = variable or tk.StringVar()
        self._command = command

        self._menu_btn = tk.Menubutton(
            self, textvariable=self._var, bg=COLORS["bg_input"],
            fg=COLORS["fg_primary"], font=(FONT_FAMILY, FONT_SIZE_BASE),
            relief="flat", highlightthickness=0, bd=0, width=width,
            activebackground=COLORS["bg_hover"],
            activeforeground=COLORS["fg_primary"],
            anchor="w", padx=5, indicatoron=True,
        )
        self._menu_btn.pack(fill="x")

        self._menu = tk.Menu(
            self._menu_btn, tearoff=0,
            bg=COLORS["bg_card"], fg=COLORS["fg_primary"],
            activebackground=COLORS["bg_hover"],
            activeforeground=COLORS["fg_primary"],
            font=(FONT_FAMILY, FONT_SIZE_BASE),
            bd=0, relief="flat",
        )
        self._menu_btn.configure(menu=self._menu)
        self._populate()

    def _populate(self):
        self._menu.delete(0, "end")
        for val in self._values:
            self._menu.add_command(label=val, command=lambda v=val: self._select(v))

    def _select(self, value):
        self._var.set(value)
        if self._command:
            self._command(value)

    def set_values(self, values):
        self._values = values
        self._populate()

    def get(self):
        return self._var.get()

    def set(self, value):
        self._var.set(value)

    def update_font_size(self, size):
        self._menu_btn.configure(font=(FONT_FAMILY, size))
        self._menu.configure(font=(FONT_FAMILY, size))
        self._populate()
