import tkinter as tk
from app.config import COLORS, FONT_FAMILY, FONT_SIZE_BASE, FONT_SIZE_SMALL, SPACING, MAX_FILTER_VALUES, FILTER_PANEL_WIDTH
from app.ui.widgets import DarkCheckbutton


class FilterPanel(tk.Frame):
    def __init__(self, parent, columns=None, data=None, on_filter_change=None, **kwargs):
        super().__init__(parent, bg=COLORS["bg_filter"], width=FILTER_PANEL_WIDTH, **kwargs)
        self.pack_propagate(False)

        self._columns = columns or []
        self._all_data = data or []
        self._on_filter_change = on_filter_change
        self._sections = {}
        self._active_filters = {}
        self._is_visible = True

        self._header_frame = tk.Frame(self, bg=COLORS["bg_filter"])
        self._header_frame.pack(fill="x", padx=SPACING["sm"], pady=SPACING["sm"])

        self._count_label = tk.Label(
            self._header_frame, text="Showing 0 of 0 components",
            bg=COLORS["bg_filter"], fg=COLORS["fg_secondary"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL), anchor="w",
        )
        self._count_label.pack(fill="x", anchor="w")

        self._clear_btn = tk.Label(
            self._header_frame, text="Clear All Filters",
            bg=COLORS["bg_filter"], fg=COLORS["fg_accent"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL), cursor="hand2", anchor="w",
        )
        self._clear_btn.pack(fill="x", anchor="w", pady=(2, 0))
        self._clear_btn.bind("<Button-1>", lambda e: self.clear_all())

        sep = tk.Frame(self, bg=COLORS["border"], height=1)
        sep.pack(fill="x", padx=SPACING["sm"])

        self._scroll_frame = tk.Frame(self, bg=COLORS["bg_filter"])
        self._scroll_frame.pack(fill="both", expand=True)

        self._canvas = tk.Canvas(
            self._scroll_frame, bg=COLORS["bg_filter"],
            highlightthickness=0, bd=0,
        )
        self._scrollbar = tk.Scrollbar(
            self._scroll_frame, orient="vertical",
            command=self._canvas.yview,
        )
        self._h_scrollbar = tk.Scrollbar(
            self._scroll_frame, orient="horizontal",
            command=self._canvas.xview,
        )
        self._canvas.configure(yscrollcommand=self._scrollbar.set, xscrollcommand=self._h_scrollbar.set)
        self._scrollbar.pack(side="right", fill="y")
        self._h_scrollbar.pack(side="bottom", fill="x")
        self._canvas.pack(side="left", fill="both", expand=True)

        self._interior = tk.Frame(self._canvas, bg=COLORS["bg_filter"])
        self._window_id = self._canvas.create_window((0, 0), window=self._interior, anchor="nw")

        self._interior.bind("<Configure>", lambda e: self._canvas.configure(scrollregion=self._canvas.bbox("all")))
        self._canvas.bind("<Configure>", self._on_canvas_configure)
        self._canvas.bind("<MouseWheel>", lambda e: self._canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))

    def _on_canvas_configure(self, event):
        interior_w = self._interior.winfo_reqwidth()
        if interior_w < event.width:
            self._canvas.itemconfig(self._window_id, width=event.width)

    def set_columns_and_data(self, columns, data, renames=None):
        self._columns = columns
        self._all_data = data
        self._renames = renames or {}
        self._active_filters = {}
        self._build_sections()

    def _build_sections(self):
        for widget in self._interior.winfo_children():
            widget.destroy()
        self._sections = {}

        skip_cols = {"Full Part Name", "Asset Path", "Part Name", "DLC2 Random Jobs",
                     "Exclude From Random Jobs", "Part Name (Base)"}

        for col in self._columns:
            if col in skip_cols:
                continue

            values = set()
            is_numeric = True
            for row in self._all_data:
                val = self._get_val(row, col)
                if val:
                    values.add(val)
                    if is_numeric:
                        try:
                            float(val)
                        except (ValueError, TypeError):
                            is_numeric = False

            if len(values) <= 1:
                continue

            display_name = self._renames.get(col, col) if hasattr(self, '_renames') else col
            section = AccordionSection(
                self._interior, col, values, is_numeric,
                on_change=lambda c=col: self._on_section_change(c),
                display_name=display_name,
            )
            section.pack(fill="x", padx=SPACING["xs"], pady=(0, 2))
            self._sections[col] = section

        self._bind_mousewheel_recursive(self._interior)

    def _get_val(self, row, col):
        if isinstance(row, dict):
            data = row.get("data", row)
            return str(data.get(col, "")).strip()
        elif hasattr(row, "get"):
            return str(row.get(col, "")).strip()
        return ""

    def _on_section_change(self, column):
        section = self._sections.get(column)
        if section is None:
            return

        filter_val = section.get_filter()
        if filter_val is None:
            self._active_filters.pop(column, None)
        else:
            self._active_filters[column] = filter_val

        self._update_dynamic_filters()

        if self._on_filter_change:
            self._on_filter_change(self._active_filters)

    def _update_dynamic_filters(self):
        filtered = list(self._all_data)
        for col, filt in self._active_filters.items():
            filtered = [r for r in filtered if self._row_matches_filter(r, col, filt)]

        for col, section in self._sections.items():
            if col in self._active_filters:
                continue
            available = set()
            for row in filtered:
                val = self._get_val(row, col)
                if val:
                    available.add(val)
            section.update_available(available)

    def _row_matches_filter(self, row, col, filt):
        val = self._get_val(row, col)
        if isinstance(filt, dict):
            if "min" in filt or "max" in filt:
                try:
                    num = float(val) if val else None
                except (ValueError, TypeError):
                    return False
                if num is None:
                    return False
                if "min" in filt and num < filt["min"]:
                    return False
                if "max" in filt and num > filt["max"]:
                    return False
                return True
        elif isinstance(filt, set):
            return val in filt
        return True

    def apply_filters(self, data):
        if not self._active_filters:
            return data
        result = []
        for row in data:
            match = True
            for col, filt in self._active_filters.items():
                if not self._row_matches_filter(row, col, filt):
                    match = False
                    break
            if match:
                result.append(row)
        return result

    def update_counts(self, showing, total, filtered=False):
        text = f"Showing {showing} of {total} components"
        if filtered:
            text += " (filtered)"
        self._count_label.configure(text=text)

    def clear_all(self):
        self._active_filters = {}
        for section in self._sections.values():
            section.reset()
        if self._on_filter_change:
            self._on_filter_change({})

    def has_active_filters(self):
        return len(self._active_filters) > 0

    def toggle_visibility(self):
        self._is_visible = not self._is_visible
        if self._is_visible:
            self.pack(side="left", fill="y")
        else:
            self.pack_forget()
        return self._is_visible

    def set_visible(self, visible):
        self._is_visible = visible
        if visible:
            self.pack(side="left", fill="y")
        else:
            self.pack_forget()

    def _bind_mousewheel_recursive(self, widget):
        widget.bind("<MouseWheel>", lambda e: self._canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))
        for child in widget.winfo_children():
            self._bind_mousewheel_recursive(child)

    def update_font_size(self, size):
        self._count_label.configure(font=(FONT_FAMILY, max(size - 1, 8)))
        self._clear_btn.configure(font=(FONT_FAMILY, max(size - 1, 8)))
        for section in self._sections.values():
            section.update_font_size(size)


class AccordionSection(tk.Frame):
    def __init__(self, parent, column_name, values, is_numeric=False, on_change=None, display_name=None, **kwargs):
        super().__init__(parent, bg=COLORS["bg_accordion"], **kwargs)
        self._column = column_name
        self._display_name = display_name or column_name
        self._values = sorted(values)
        self._is_numeric = is_numeric
        self._on_change = on_change
        self._expanded = False
        self._check_vars = {}
        self._all_var = tk.BooleanVar(value=True)
        self._min_var = tk.StringVar(value="")
        self._max_var = tk.StringVar(value="")
        self._available_values = set(values)

        self._all_cb = None
        self._min_entry = None
        self._max_entry = None
        self._min_label = None
        self._max_label = None

        self._header = tk.Frame(self, bg=COLORS["bg_accordion"], cursor="hand2")
        self._header.pack(fill="x")

        self._arrow = tk.Label(
            self._header, text="▶", bg=COLORS["bg_accordion"],
            fg=COLORS["fg_secondary"], font=(FONT_FAMILY, FONT_SIZE_SMALL),
        )
        self._arrow.pack(side="left", padx=(SPACING["xs"], 2))

        self._title = tk.Label(
            self._header, text=self._display_name, bg=COLORS["bg_accordion"],
            fg=COLORS["fg_primary"], font=(FONT_FAMILY, FONT_SIZE_SMALL),
            anchor="w",
        )
        self._title.pack(side="left", fill="x", expand=True)

        self._header.bind("<Button-1>", self._toggle)
        self._arrow.bind("<Button-1>", self._toggle)
        self._title.bind("<Button-1>", self._toggle)

        self._body = tk.Frame(self, bg=COLORS["bg_accordion"])

        if is_numeric:
            self._build_numeric_body()
        else:
            self._build_checkbox_body()

    def _toggle(self, event=None):
        self._expanded = not self._expanded
        if self._expanded:
            self._arrow.configure(text="▼")
            self._body.pack(fill="x", padx=SPACING["sm"], pady=(0, SPACING["xs"]))
        else:
            self._arrow.configure(text="▶")
            self._body.pack_forget()

    def _build_numeric_body(self):
        row = tk.Frame(self._body, bg=COLORS["bg_accordion"])
        row.pack(fill="x", pady=2)

        self._min_label = tk.Label(row, text="Min:", bg=COLORS["bg_accordion"], fg=COLORS["fg_secondary"],
                 font=(FONT_FAMILY, FONT_SIZE_SMALL))
        self._min_label.pack(side="left")
        self._min_entry = tk.Entry(
            row, textvariable=self._min_var, width=10,
            bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
            insertbackground=COLORS["fg_primary"], relief="flat",
            font=(FONT_FAMILY, FONT_SIZE_SMALL),
            highlightthickness=1, highlightbackground=COLORS["border"],
            highlightcolor=COLORS["border_accent"],
        )
        self._min_entry.pack(side="left", padx=(4, SPACING["sm"]))

        self._max_label = tk.Label(row, text="Max:", bg=COLORS["bg_accordion"], fg=COLORS["fg_secondary"],
                 font=(FONT_FAMILY, FONT_SIZE_SMALL))
        self._max_label.pack(side="left")
        self._max_entry = tk.Entry(
            row, textvariable=self._max_var, width=10,
            bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
            insertbackground=COLORS["fg_primary"], relief="flat",
            font=(FONT_FAMILY, FONT_SIZE_SMALL),
            highlightthickness=1, highlightbackground=COLORS["border"],
            highlightcolor=COLORS["border_accent"],
        )
        self._max_entry.pack(side="left", padx=4)

        self._min_var.trace_add("write", lambda *a: self._on_numeric_change())
        self._max_var.trace_add("write", lambda *a: self._on_numeric_change())

    def _on_numeric_change(self):
        if self._on_change:
            self._on_change()

    def _build_checkbox_body(self):
        display_vals = self._values[:MAX_FILTER_VALUES]

        all_frame = tk.Frame(self._body, bg=COLORS["bg_accordion"])
        all_frame.pack(fill="x", pady=(0, 2))
        self._all_cb = DarkCheckbutton(
            all_frame, text="All", variable=self._all_var,
            command=self._on_all_toggle,
            font_size=FONT_SIZE_SMALL,
        )
        self._all_cb.pack(anchor="w")

        for val in display_vals:
            var = tk.BooleanVar(value=True)
            frame = tk.Frame(self._body, bg=COLORS["bg_accordion"])
            frame.pack(fill="x")
            cb = DarkCheckbutton(
                frame, text=val, variable=var,
                command=self._on_check_change,
                font_size=FONT_SIZE_SMALL,
            )
            cb.pack(anchor="w")
            self._check_vars[val] = (var, cb, frame)

    def _on_all_toggle(self):
        state = self._all_var.get()
        for val, (var, cb, frame) in self._check_vars.items():
            var.set(state)
        if self._on_change:
            self._on_change()

    def _on_check_change(self):
        all_checked = all(var.get() for var, cb, f in self._check_vars.values())
        self._all_var.set(all_checked)
        if self._on_change:
            self._on_change()

    def get_filter(self):
        if self._is_numeric:
            min_val = self._min_var.get().strip()
            max_val = self._max_var.get().strip()
            filt = {}
            try:
                if min_val:
                    filt["min"] = float(min_val)
            except ValueError:
                pass
            try:
                if max_val:
                    filt["max"] = float(max_val)
            except ValueError:
                pass
            return filt if filt else None
        else:
            if self._all_var.get():
                return None
            selected = set()
            for val, (var, cb, f) in self._check_vars.items():
                if var.get():
                    selected.add(val)
            if len(selected) == len(self._check_vars):
                return None
            if not selected:
                return set()
            return selected

    def reset(self):
        if self._is_numeric:
            self._min_var.set("")
            self._max_var.set("")
        else:
            self._all_var.set(True)
            for var, cb, f in self._check_vars.values():
                var.set(True)

    def update_available(self, available):
        self._available_values = available
        if not self._is_numeric:
            for val, (var, cb, frame) in self._check_vars.items():
                if val in available:
                    cb._label.configure(fg=COLORS["fg_primary"])
                else:
                    cb._label.configure(fg=COLORS["fg_muted"])

    def update_font_size(self, size):
        s = max(size - 1, 8)
        self._title.configure(font=(FONT_FAMILY, s))
        self._arrow.configure(font=(FONT_FAMILY, s))
        if not self._is_numeric:
            if self._all_cb:
                self._all_cb.update_font_size(s)
            for val, (var, cb, frame) in self._check_vars.items():
                cb.update_font_size(s)
        else:
            if self._min_label:
                self._min_label.configure(font=(FONT_FAMILY, s))
            if self._max_label:
                self._max_label.configure(font=(FONT_FAMILY, s))
            if self._min_entry:
                self._min_entry.configure(font=(FONT_FAMILY, s))
            if self._max_entry:
                self._max_entry.configure(font=(FONT_FAMILY, s))
