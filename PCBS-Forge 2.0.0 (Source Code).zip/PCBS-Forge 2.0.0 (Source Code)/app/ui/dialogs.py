import tkinter as tk
from app.config import COLORS, FONT_FAMILY, FONT_SIZE_BASE, FONT_SIZE_LARGE, SPACING


def show_confirmation(parent, title, message, on_confirm, font_size=None):
    fs = font_size or FONT_SIZE_BASE
    scale = fs / FONT_SIZE_BASE
    w = int(400 * max(scale, 1.0))
    h = int(180 * max(scale, 1.0))

    dialog = tk.Toplevel(parent)
    dialog.title(title)
    dialog.configure(bg=COLORS["bg_popup"])
    dialog.transient(parent)
    dialog.grab_set()
    dialog.resizable(False, False)

    dialog.geometry(f"{w}x{h}")
    dialog.update_idletasks()
    x = parent.winfo_rootx() + (parent.winfo_width() - w) // 2
    y = parent.winfo_rooty() + (parent.winfo_height() - h) // 2
    dialog.geometry(f"+{x}+{y}")

    frame = tk.Frame(dialog, bg=COLORS["bg_popup"], padx=SPACING["lg"], pady=SPACING["lg"])
    frame.pack(fill="both", expand=True)

    tk.Label(
        frame, text=title, bg=COLORS["bg_popup"],
        fg=COLORS["fg_header"], font=(FONT_FAMILY, max(fs + 2, 12), "bold"),
    ).pack(anchor="w", pady=(0, SPACING["sm"]))

    tk.Label(
        frame, text=message, bg=COLORS["bg_popup"],
        fg=COLORS["fg_primary"], font=(FONT_FAMILY, fs),
        wraplength=int(w * 0.9), justify="left",
    ).pack(anchor="w", pady=(0, SPACING["lg"]))

    btn_frame = tk.Frame(frame, bg=COLORS["bg_popup"])
    btn_frame.pack(fill="x")

    def confirm():
        dialog.destroy()
        on_confirm()

    cancel_btn = tk.Button(
        btn_frame, text="Cancel", command=dialog.destroy,
        bg=COLORS["bg_card"], fg=COLORS["fg_primary"],
        font=(FONT_FAMILY, fs), relief="flat",
        activebackground=COLORS["bg_hover"],
        activeforeground=COLORS["fg_primary"],
        padx=15, pady=5, cursor="hand2",
    )
    cancel_btn.pack(side="right", padx=(SPACING["sm"], 0))

    confirm_btn = tk.Button(
        btn_frame, text="Confirm", command=confirm,
        bg="#f93333", fg=COLORS["fg_primary"],
        font=(FONT_FAMILY, fs), relief="flat",
        activebackground="#d62a2a",
        activeforeground=COLORS["fg_primary"],
        padx=15, pady=5, cursor="hand2",
    )
    confirm_btn.pack(side="right")


def show_input_dialog(parent, title, prompt, on_submit, default_text="", font_size=None):
    fs = font_size or FONT_SIZE_BASE
    scale = fs / FONT_SIZE_BASE
    w = int(400 * max(scale, 1.0))
    h = int(170 * max(scale, 1.0))

    dialog = tk.Toplevel(parent)
    dialog.title(title)
    dialog.configure(bg=COLORS["bg_popup"])
    dialog.transient(parent)
    dialog.grab_set()
    dialog.resizable(False, False)

    dialog.geometry(f"{w}x{h}")
    dialog.update_idletasks()
    x = parent.winfo_rootx() + (parent.winfo_width() - w) // 2
    y = parent.winfo_rooty() + (parent.winfo_height() - h) // 2
    dialog.geometry(f"+{x}+{y}")

    frame = tk.Frame(dialog, bg=COLORS["bg_popup"], padx=SPACING["lg"], pady=SPACING["lg"])
    frame.pack(fill="both", expand=True)

    tk.Label(
        frame, text=prompt, bg=COLORS["bg_popup"],
        fg=COLORS["fg_primary"], font=(FONT_FAMILY, fs),
    ).pack(anchor="w", pady=(0, SPACING["sm"]))

    entry = tk.Entry(
        frame, bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
        insertbackground=COLORS["fg_primary"], relief="flat",
        font=(FONT_FAMILY, fs), highlightthickness=1,
        highlightbackground=COLORS["border"],
        highlightcolor=COLORS["border_accent"],
    )
    entry.pack(fill="x", pady=(0, SPACING["lg"]))
    entry.insert(0, default_text)
    entry.select_range(0, "end")
    entry.focus_set()

    btn_frame = tk.Frame(frame, bg=COLORS["bg_popup"])
    btn_frame.pack(fill="x")

    def submit(event=None):
        text = entry.get().strip()
        if text:
            dialog.destroy()
            on_submit(text)

    entry.bind("<Return>", submit)

    cancel_btn = tk.Button(
        btn_frame, text="Cancel", command=dialog.destroy,
        bg=COLORS["bg_card"], fg=COLORS["fg_primary"],
        font=(FONT_FAMILY, fs), relief="flat",
        activebackground=COLORS["bg_hover"],
        activeforeground=COLORS["fg_primary"],
        padx=15, pady=5, cursor="hand2",
    )
    cancel_btn.pack(side="right", padx=(SPACING["sm"], 0))

    ok_btn = tk.Button(
        btn_frame, text="OK", command=submit,
        bg=COLORS["bg_button"], fg=COLORS["fg_button"],
        font=(FONT_FAMILY, fs), relief="flat",
        activebackground=COLORS["bg_button_hover"],
        activeforeground=COLORS["fg_button"],
        padx=15, pady=5, cursor="hand2",
    )
    ok_btn.pack(side="right")
