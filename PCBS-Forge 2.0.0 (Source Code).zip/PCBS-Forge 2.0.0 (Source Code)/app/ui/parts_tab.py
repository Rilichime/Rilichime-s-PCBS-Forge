import tkinter as tk
from app.config import COLORS, FONT_FAMILY, FONT_SIZE_BASE, FONT_SIZE_SMALL, SPACING, PART_CATEGORIES
from app.ui.tab_bar import SubTabBar
from app.ui.virtual_table import VirtualTable
from app.ui.filter_panel import FilterPanel
from app.ui.search_panel import SearchPanel
from app.ui.widgets import FlatButton
from app.ui.dialogs import show_confirmation
from app.logger import get_logger


class PartsTab(tk.Frame):
    def __init__(self, parent, state_manager, inventory_type="used", **kwargs):
        super().__init__(parent, bg=COLORS["bg_dark"], **kwargs)
        self._state = state_manager
        self._inventory_type = inventory_type
        self._inventory_categories = [cat for cat in PART_CATEGORIES if cat != "Cables"]
        self._current_category = self._inventory_categories[0]
        self._tables = {}
        self._filters = {}
        self._stale_categories = set()
        self._current_font_size = FONT_SIZE_BASE
        self._log = get_logger(f"{'UsedParts' if inventory_type == 'used' else 'NewParts'}")

        self._sub_tabs = SubTabBar(
            self, self._inventory_categories,
            command=self._on_subtab_change,
        )
        self._sub_tabs.pack(fill="x")

        self._search = SearchPanel(
            self, state_manager=state_manager,
            inventory_type=inventory_type,
            on_add=self._on_search_add,
        )
        self._search.pack(fill="x", padx=SPACING["sm"], pady=(SPACING["sm"], 0))

        self._toggle_row = tk.Frame(self, bg=COLORS["bg_dark"])
        self._toggle_row.pack(fill="x", padx=SPACING["sm"], pady=(SPACING["xs"], 0))

        self._toggle_btn = tk.Label(
            self._toggle_row, text="◀ Hide Filters",
            bg=COLORS["bg_dark"], fg=COLORS["fg_accent"],
            font=(FONT_FAMILY, FONT_SIZE_BASE - 1), cursor="hand2",
        )
        self._toggle_btn.pack(side="left")
        self._toggle_btn.bind("<Button-1>", self._toggle_filters)
        self._filter_visible = True

        self._content_frame = tk.Frame(self, bg=COLORS["bg_dark"])
        self._content_frame.pack(fill="both", expand=True, padx=SPACING["sm"], pady=(SPACING["xs"], SPACING["sm"]))

        self._filter_container = tk.Frame(self._content_frame, bg=COLORS["bg_filter"])
        self._filter_container.pack(side="left", fill="y")

        self._table_container = tk.Frame(self._content_frame, bg=COLORS["bg_dark"])
        self._table_container.pack(side="left", fill="both", expand=True, padx=(SPACING["xs"], 0))

        self._bottom_frame = tk.Frame(self, bg=COLORS["bg_dark"])
        self._bottom_frame.pack(fill="x", padx=SPACING["sm"], pady=(0, SPACING["sm"]))

        self._delete_all_btn = FlatButton(
            self._bottom_frame, text="Delete All",
            command=self._on_delete_all,
            bg="#f93333",
            hover_bg="#d62a2a",
            width=120, height=30,
        )
        self._delete_all_btn.pack(side="left")

        for cat in self._inventory_categories:
            filter_panel = FilterPanel(
                self._filter_container,
                on_filter_change=lambda filters, c=cat: self._on_filter_change(c, filters),
            )

            show_add = (inventory_type == "used")
            table = VirtualTable(
                self._table_container,
                on_add_click=self._on_add_to_build if inventory_type == "used" else None,
                on_delete_click=self._on_delete_part,
                on_double_click=self._on_double_click,
                show_add_column=show_add,
                show_delete_column=True,
                state_manager=state_manager,
                inventory_type=inventory_type,
            )

            self._tables[cat] = table
            self._filters[cat] = filter_panel

        if inventory_type == "used":
            self._state.subscribe("used_parts", self._refresh_current)
        else:
            self._state.subscribe("new_parts", self._refresh_current)
        self._state.subscribe("catalog", self._on_catalog_loaded)
        self._state.subscribe("builds", self._refresh_current)
        self._state.subscribe("settings", self._on_settings_change)

        self._show_category(self._current_category)

    def _on_catalog_loaded(self):
        for cat in self._inventory_categories:
            columns = self._get_display_columns(cat)
            renames = self._get_column_renames(cat)
            self._tables[cat].set_columns(columns, renames)

            filter_cols = self._get_display_columns(cat)
            filter_renames = self._get_column_renames(cat)
            data = self._state.catalog.get(cat, [])
            self._filters[cat].set_columns_and_data(filter_cols, data, renames=filter_renames)

        self._refresh_current()

    def _get_display_columns(self, category):
        all_columns = self._state.column_map.get(category, [])
        col_settings = self._state.get_setting("column_display", {})
        cat_settings = col_settings.get(category, None)

        if cat_settings and "visible" in cat_settings:
            visible_set = set(cat_settings["visible"])
            ordered = cat_settings.get("order", all_columns)
            result = [c for c in ordered if c in visible_set and c in all_columns]
            if "Full Part Name" not in result:
                result.insert(0, "Full Part Name")
            return result
        else:
            return list(all_columns)

    def _get_column_renames(self, category):
        col_settings = self._state.get_setting("column_display", {})
        cat_settings = col_settings.get(category, None)
        if cat_settings:
            return cat_settings.get("renames", {})
        return {}

    def _show_category(self, category):
        for cat, table in self._tables.items():
            if cat == category:
                table.pack(fill="both", expand=True)
            else:
                table.pack_forget()

        for cat, fp in self._filters.items():
            if cat == category:
                fp.pack(fill="both", expand=True)
            else:
                fp.pack_forget()

        self._current_category = category
        # If this category was marked stale, rebuild its filters now
        if category in self._stale_categories:
            self._stale_categories.discard(category)
            filter_cols = self._get_display_columns(category)
            filter_renames = self._get_column_renames(category)
            data = self._state.catalog.get(category, [])
            if data:
                self._filters[category].set_columns_and_data(filter_cols, data, renames=filter_renames)
        self._refresh_current()

    def _on_subtab_change(self, name):
        self._show_category(name)

    def _refresh_current(self):
        cat = self._current_category
        table = self._tables.get(cat)
        filter_panel = self._filters.get(cat)
        if not table:
            return

        columns = self._get_display_columns(cat)
        renames = self._get_column_renames(cat)
        table.set_columns(columns, renames)

        parts = self._state.get_parts_for_category(cat, self._inventory_type)

        if filter_panel and filter_panel.has_active_filters():
            filtered = filter_panel.apply_filters(parts)
        else:
            filtered = parts

        table.set_data(filtered)

        total = len(parts)
        showing = len(filtered)
        has_filter = filter_panel.has_active_filters() if filter_panel else False
        if filter_panel:
            filter_panel.update_counts(showing, total, has_filter)

    def _on_filter_change(self, category, filters):
        if category == self._current_category:
            self._refresh_current()

    def _toggle_filters(self, event=None):
        self._filter_visible = not self._filter_visible
        if self._filter_visible:
            self._filter_container.pack(side="left", fill="y", before=self._table_container)
            self._toggle_btn.configure(text="◀ Hide Filters")
        else:
            self._filter_container.pack_forget()
            self._toggle_btn.configure(text="▶ Show Filters")

    def _on_search_add(self, category, catalog_part):
        if self._inventory_type == "used":
            part_data = catalog_part.data if hasattr(catalog_part, "data") else catalog_part
            self._state.add_used_part(category, part_data)
        else:
            part_data = catalog_part.data if hasattr(catalog_part, "data") else catalog_part
            self._state.add_new_part(category, part_data)

    def _on_add_to_build(self, row):
        if not isinstance(row, dict):
            return
        instance_id = row.get("instance_id", "")
        used_in = row.get("used_in_build")

        if used_in:
            self._state.remove_part_from_build(used_in, instance_id)
        else:
            active = self._state.get_active_build()
            if active is None:
                self._log.warning("No active build to add part to")
                return
            self._state.assign_part_to_build(instance_id, active["id"])

    def _on_delete_part(self, row):
        if not isinstance(row, dict):
            return
        instance_id = row.get("instance_id", "")
        if self._inventory_type == "used":
            self._state.remove_used_part(instance_id)
        else:
            self._state.remove_new_part(instance_id)

    def _on_double_click(self, row):
        name = ""
        if isinstance(row, dict):
            name = row.get("data", {}).get("Full Part Name", "")
        if name:
            try:
                self.clipboard_clear()
                self.clipboard_append(name)
                self._log.debug(f"Copied to clipboard: {name}")
            except Exception:
                pass

    def _on_delete_all(self):
        def do_delete():
            if self._inventory_type == "used":
                self._state.delete_all_used_parts()
            else:
                self._state.delete_all_new_parts()

        show_confirmation(
            self.winfo_toplevel(),
            "Delete All Parts",
            f"Are you sure you want to delete ALL {'used' if self._inventory_type == 'used' else 'new'} parts? This cannot be undone.",
            do_delete,
            font_size=self._current_font_size,
        )

    def _on_settings_change(self):
        # Only rebuild filters for the current category; mark others stale
        cat = self._current_category
        filter_cols = self._get_display_columns(cat)
        filter_renames = self._get_column_renames(cat)
        data = self._state.catalog.get(cat, [])
        if data:
            self._filters[cat].set_columns_and_data(filter_cols, data, renames=filter_renames)
        for other in self._inventory_categories:
            if other != cat:
                self._stale_categories.add(other)
        self._refresh_current()

    def update_font_size(self, size):
        self._current_font_size = size
        self._sub_tabs.update_font_size(size)
        self._search.update_font_size(size)
        self._toggle_btn.configure(font=(FONT_FAMILY, max(size - 1, 8)))
        self._delete_all_btn.update_font_size(size)
        for table in self._tables.values():
            table.update_font_size(size)
        for fp in self._filters.values():
            fp.update_font_size(size)
