import tkinter as tk
from app.config import COLORS, FONT_FAMILY, FONT_SIZE_BASE, ROW_HEIGHT, HEADER_HEIGHT, SPACING


def _get_scale_steps(size):
    scale = size / FONT_SIZE_BASE
    if scale <= 1.0:
        return 0
    elif scale <= 1.5:
        return 1
    elif scale <= 2.0:
        return 2
    elif scale <= 3.0:
        return 3
    return 4


def get_text_width(text, font_size):
    """Estimate text width in pixels based on font size."""
    avg_char_width = font_size * 0.8
    return int(len(text) * avg_char_width + 50)


class VirtualTable(tk.Frame):
    def __init__(self, parent, columns=None, on_add_click=None, on_delete_click=None,
                 on_double_click=None, show_add_column=True, show_delete_column=True,
                 state_manager=None, inventory_type="used", **kwargs):
        super().__init__(parent, bg=COLORS["bg_dark"], **kwargs)

        self._columns = columns or []
        self._all_data = []
        self._display_data = []
        self._sort_col = None
        self._sort_dir = "default"
        self._default_order = []
        self._on_add_click = on_add_click
        self._on_delete_click = on_delete_click
        self._on_double_click = on_double_click
        self._show_add = show_add_column
        self._show_delete = show_delete_column
        self._state = state_manager
        self._inventory_type = inventory_type

        self._col_widths = {}
        self._col_renames = {}
        self._user_resized_cols = set()
        self._min_col_width = 60
        self._action_col_width = 90
        self._header_height = HEADER_HEIGHT
        self._resize_col = None
        self._resize_start_x = 0
        self._resize_start_w = 0
        self._font_size = FONT_SIZE_BASE
        self._row_height = ROW_HEIGHT

        self._header_frame = tk.Frame(self, bg=COLORS["bg_header"], height=self._header_height)
        self._header_frame.pack(fill="x", side="top")
        self._header_frame.pack_propagate(False)

        self._header_canvas = tk.Canvas(
            self._header_frame, bg=COLORS["bg_header"],
            highlightthickness=0, bd=0, height=self._header_height,
        )
        self._header_canvas.pack(fill="both", expand=True)

        body_frame = tk.Frame(self, bg=COLORS["bg_dark"])
        body_frame.pack(fill="both", expand=True)

        self._canvas = tk.Canvas(
            body_frame, bg=COLORS["bg_dark"],
            highlightthickness=0, bd=0,
        )
        self._v_scroll = tk.Scrollbar(body_frame, orient="vertical", command=self._canvas.yview)
        self._h_scroll = tk.Scrollbar(self, orient="horizontal", command=self._on_h_scroll)

        self._canvas.configure(yscrollcommand=self._v_scroll.set, xscrollcommand=self._h_scroll.set)

        self._v_scroll.pack(side="right", fill="y")
        self._canvas.pack(side="left", fill="both", expand=True)
        self._h_scroll.pack(side="bottom", fill="x")

        self._canvas.bind("<MouseWheel>", self._on_mousewheel)
        self._canvas.bind("<Shift-MouseWheel>", self._on_shift_mousewheel)
        self._canvas.bind("<Configure>", self._on_configure)
        self._canvas.bind("<Button-1>", self._on_canvas_click)
        self._canvas.bind("<Double-Button-1>", self._on_canvas_double_click)
        self._canvas.bind("<Motion>", self._on_canvas_motion)

        self._header_canvas.bind("<Button-1>", self._on_header_click)
        self._header_canvas.bind("<B1-Motion>", self._on_header_drag)
        self._header_canvas.bind("<ButtonRelease-1>", self._on_header_release)
        self._header_canvas.bind("<Motion>", self._on_header_motion)

        self._visible_start = 0
        self._visible_count = 0
        self._canvas_width = 0
        self._total_content_width = 0
        self._hover_row = -1

    def set_columns(self, columns, renames=None):
        self._columns = list(columns)
        self._col_renames = renames or {}
        self._compute_col_widths()
        self._draw_header()
        self._redraw()

    def set_data(self, data):
        self._all_data = list(data)
        self._default_order = list(data)
        self._compute_col_widths()
        self._apply_sort()
        self._update_scroll_region()
        self._draw_header()
        self._redraw()

    def _get_full_columns(self):
        cols = []
        if self._show_add:
            cols.append(("__add__", "Add To Build", self._action_col_width))
        if self._show_delete:
            cols.append(("__delete__", "Delete", self._action_col_width))
        for c in self._columns:
            w = self._col_widths.get(c, 120)
            display_label = self._col_renames.get(c, c)
            cols.append((c, display_label, w))
        return cols

    def _compute_col_widths(self, force=False):
        for c in self._columns:
            if c not in self._col_widths or force:
                name_width = get_text_width(c, self._font_size)
                self._col_widths[c] = max(name_width, self._min_col_width)

        if self._all_data:
            sample = self._all_data[:50]
            for c in self._columns:
                if c in self._user_resized_cols and not force:
                    continue
                max_data_w = 0
                for row in sample:
                    val = self._get_cell_value(row, c)
                    val_width = get_text_width(str(val), self._font_size)
                    if val_width > max_data_w:
                        max_data_w = val_width
                header_w = get_text_width(c, self._font_size)
                self._col_widths[c] = max(
                    min(max(max_data_w, header_w), 800),
                    self._min_col_width
                )

    def _get_cell_value(self, row, col):
        if isinstance(row, dict):
            data = row.get("data", row)
            return data.get(col, "")
        elif hasattr(row, "get"):
            return row.get(col, "")
        return ""

    def _get_instance_id(self, row):
        if isinstance(row, dict):
            return row.get("instance_id", "")
        return ""

    def _get_used_in_build(self, row):
        if isinstance(row, dict):
            return row.get("used_in_build", None)
        return None

    def _total_width(self):
        full_cols = self._get_full_columns()
        return sum(w for _, _, w in full_cols)

    def _update_scroll_region(self):
        total_h = len(self._display_data) * self._row_height
        total_w = max(self._total_width(), self._canvas_width)
        self._total_content_width = total_w
        self._canvas.configure(scrollregion=(0, 0, total_w, total_h))
        self._header_canvas.configure(scrollregion=(0, 0, total_w, self._header_height))

    def _on_h_scroll(self, *args):
        self._canvas.xview(*args)
        self._header_canvas.xview(*args)

    def _on_configure(self, event):
        self._canvas_width = event.width
        self._visible_count = (event.height // self._row_height) + 2
        self._update_scroll_region()
        self._redraw()

    def _on_mousewheel(self, event):
        self._canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        self.after(5, self._redraw)

    def _on_shift_mousewheel(self, event):
        self._canvas.xview_scroll(int(-1 * (event.delta / 120)), "units")
        self._header_canvas.xview_scroll(int(-1 * (event.delta / 120)), "units")

    def _draw_header(self):
        self._header_canvas.delete("all")
        full_cols = self._get_full_columns()
        x = 0
        for col_key, col_label, w in full_cols:
            self._header_canvas.create_rectangle(
                x, 0, x + w, self._header_height,
                fill=COLORS["bg_header"], outline=COLORS["border"],
            )

            sort_indicator = ""
            if col_key == self._sort_col:
                if self._sort_dir == "asc":
                    sort_indicator = " ▲"
                elif self._sort_dir == "desc":
                    sort_indicator = " ▼"

            display_text = col_label + sort_indicator
            self._header_canvas.create_text(
                x + 8, self._header_height // 2,
                text=display_text, anchor="w",
                fill=COLORS["fg_primary"],
                font=(FONT_FAMILY, self._font_size, "bold"),
            )

            if col_key not in ("__add__", "__delete__"):
                self._header_canvas.create_line(
                    x + w - 1, 2, x + w - 1, self._header_height - 2,
                    fill=COLORS["border_light"], width=2, tags="resize"
                )
            x += w

        total_w = max(self._total_width(), self._canvas_width)
        self._header_canvas.configure(scrollregion=(0, 0, total_w, self._header_height))

    def _redraw(self):
        self._canvas.delete("all")

        if not self._display_data:
            self._canvas.create_text(
                self._canvas_width // 2, 50,
                text="No parts in inventory",
                fill=COLORS["fg_muted"],
                font=(FONT_FAMILY, self._font_size),
            )
            return

        y_top = self._canvas.canvasy(0)
        start_idx = max(0, int(y_top // self._row_height))
        end_idx = min(len(self._display_data), start_idx + self._visible_count)

        full_cols = self._get_full_columns()
        total_w = max(self._total_width(), self._canvas_width)

        for i in range(start_idx, end_idx):
            row = self._display_data[i]
            y = i * self._row_height
            bg = COLORS["bg_row_even"] if i % 2 == 0 else COLORS["bg_row_odd"]

            if i == self._hover_row:
                bg = COLORS["bg_hover"]

            self._canvas.create_rectangle(
                0, y, total_w, y + self._row_height,
                fill=bg, outline="", tags=f"row_{i}",
            )

            x = 0
            for col_key, col_label, w in full_cols:
                if col_key == "__add__":
                    used = self._get_used_in_build(row)
                    btn_text = "USED" if used else "ADD"
                    btn_bg = COLORS["bg_button_danger"] if used else COLORS["bg_button_success"]
                    bx = x + 5
                    by = y + 3
                    bw = w - 10
                    bh = self._row_height - 6
                    self._canvas.create_rectangle(
                        bx, by, bx + bw, by + bh,
                        fill=btn_bg, outline="",
                        tags=(f"add_btn_{i}", "add_btn"),
                    )
                    self._canvas.create_text(
                        bx + bw // 2, by + bh // 2,
                        text=btn_text, fill=COLORS["fg_primary"],
                        font=(FONT_FAMILY, self._font_size - 1, "bold"),
                        tags=(f"add_btn_{i}", "add_btn"),
                    )
                elif col_key == "__delete__":
                    bx = x + 5
                    by = y + 3
                    bw = w - 10
                    bh = self._row_height - 6
                    self._canvas.create_rectangle(
                        bx, by, bx + bw, by + bh,
                        fill="#f93333", outline="",
                        tags=(f"del_btn_{i}", "del_btn"),
                    )
                    self._canvas.create_text(
                        bx + bw // 2, by + bh // 2,
                        text="✕", fill=COLORS["fg_primary"],
                        font=(FONT_FAMILY, self._font_size - 1, "bold"),
                        tags=(f"del_btn_{i}", "del_btn"),
                    )
                else:
                    val = str(self._get_cell_value(row, col_key))
                    avg_char_width = self._font_size * 0.8
                    clip_chars = max(1, int((w - 24) / avg_char_width))
                    if len(val) > clip_chars:
                        val = val[:clip_chars] + "…"
                    self._canvas.create_text(
                        x + 8, y + self._row_height // 2,
                        text=val, anchor="w",
                        fill=COLORS["fg_primary"],
                        font=(FONT_FAMILY, self._font_size),
                        tags=f"cell_{i}",
                    )

                self._canvas.create_line(
                    x + w, y, x + w, y + self._row_height,
                    fill=COLORS["border"], tags="grid",
                )
                x += w

    def _on_canvas_click(self, event):
        canvas_x = self._canvas.canvasx(event.x)
        canvas_y = self._canvas.canvasy(event.y)
        row_idx = int(canvas_y // self._row_height)

        if row_idx < 0 or row_idx >= len(self._display_data):
            return

        row = self._display_data[row_idx]
        full_cols = self._get_full_columns()
        x = 0
        for col_key, col_label, w in full_cols:
            if x <= canvas_x < x + w:
                if col_key == "__add__":
                    if self._on_add_click:
                        self._on_add_click(row)
                    return
                elif col_key == "__delete__":
                    if self._on_delete_click:
                        self._on_delete_click(row)
                    return
                break
            x += w

    def _on_canvas_double_click(self, event):
        canvas_x = self._canvas.canvasx(event.x)
        canvas_y = self._canvas.canvasy(event.y)
        row_idx = int(canvas_y // self._row_height)

        if row_idx < 0 or row_idx >= len(self._display_data):
            return

        full_cols = self._get_full_columns()
        x = 0
        for col_key, col_label, w in full_cols:
            if x <= canvas_x < x + w:
                if col_key in ("__add__", "__delete__"):
                    return
                break
            x += w

        row = self._display_data[row_idx]
        if self._on_double_click:
            self._on_double_click(row)
        else:
            name = ""
            if isinstance(row, dict):
                name = row.get("data", {}).get("Full Part Name", "")
            elif hasattr(row, "get"):
                name = row.get("Full Part Name", "")
            if name:
                try:
                    self.clipboard_clear()
                    self.clipboard_append(name)
                except Exception:
                    pass

    def _on_canvas_motion(self, event):
        canvas_y = self._canvas.canvasy(event.y)
        row_idx = int(canvas_y // self._row_height)
        if row_idx != self._hover_row:
            old_hover = self._hover_row
            self._hover_row = row_idx
            self._redraw_row(old_hover)
            self._redraw_row(row_idx)

    def _redraw_row(self, row_idx):
        if row_idx < 0 or row_idx >= len(self._display_data):
            return
        y_top = self._canvas.canvasy(0)
        start_vis = max(0, int(y_top // self._row_height))
        end_vis = min(len(self._display_data), start_vis + self._visible_count)
        if row_idx < start_vis or row_idx >= end_vis:
            return
        self._canvas.delete(f"row_{row_idx}")
        self._canvas.delete(f"add_btn_{row_idx}")
        self._canvas.delete(f"del_btn_{row_idx}")
        self._canvas.delete(f"cell_{row_idx}")

        row = self._display_data[row_idx]
        y = row_idx * self._row_height
        bg = COLORS["bg_row_even"] if row_idx % 2 == 0 else COLORS["bg_row_odd"]
        if row_idx == self._hover_row:
            bg = COLORS["bg_hover"]

        full_cols = self._get_full_columns()
        total_w = max(self._total_width(), self._canvas_width)

        self._canvas.create_rectangle(
            0, y, total_w, y + self._row_height,
            fill=bg, outline="", tags=f"row_{row_idx}",
        )

        x = 0
        for col_key, col_label, w in full_cols:
            if col_key == "__add__":
                used = self._get_used_in_build(row)
                btn_text = "USED" if used else "ADD"
                btn_bg = COLORS["bg_button_danger"] if used else COLORS["bg_button_success"]
                bx = x + 5
                by = y + 3
                bw = w - 10
                bh = self._row_height - 6
                self._canvas.create_rectangle(
                    bx, by, bx + bw, by + bh,
                    fill=btn_bg, outline="",
                    tags=(f"add_btn_{row_idx}", "add_btn"),
                )
                self._canvas.create_text(
                    bx + bw // 2, by + bh // 2,
                    text=btn_text, fill=COLORS["fg_primary"],
                    font=(FONT_FAMILY, self._font_size - 1, "bold"),
                    tags=(f"add_btn_{row_idx}", "add_btn"),
                )
            elif col_key == "__delete__":
                bx = x + 5
                by = y + 3
                bw = w - 10
                bh = self._row_height - 6
                self._canvas.create_rectangle(
                    bx, by, bx + bw, by + bh,
                    fill="#f93333", outline="",
                    tags=(f"del_btn_{row_idx}", "del_btn"),
                )
                self._canvas.create_text(
                    bx + bw // 2, by + bh // 2,
                    text="\u2715", fill=COLORS["fg_primary"],
                    font=(FONT_FAMILY, self._font_size - 1, "bold"),
                    tags=(f"del_btn_{row_idx}", "del_btn"),
                )
            else:
                val = str(self._get_cell_value(row, col_key))
                avg_char_width = self._font_size * 0.8
                clip_chars = max(1, int((w - 24) / avg_char_width))
                if len(val) > clip_chars:
                    val = val[:clip_chars] + "\u2026"
                self._canvas.create_text(
                    x + 8, y + self._row_height // 2,
                    text=val, anchor="w",
                    fill=COLORS["fg_primary"],
                    font=(FONT_FAMILY, self._font_size),
                    tags=f"cell_{row_idx}",
                )

            self._canvas.create_line(
                x + w, y, x + w, y + self._row_height,
                fill=COLORS["border"], tags=f"cell_{row_idx}",
            )
            x += w

    def _on_header_click(self, event):
        canvas_x = self._header_canvas.canvasx(event.x)

        full_cols = self._get_full_columns()
        x = 0
        for col_key, col_label, w in full_cols:
            edge = x + w
            if abs(canvas_x - edge) < 5 and col_key not in ("__add__", "__delete__"):
                self._resize_col = col_key
                self._resize_start_x = event.x
                self._resize_start_w = w
                return
            if x <= canvas_x < edge:
                if col_key not in ("__add__", "__delete__"):
                    self._toggle_sort(col_key)
                return
            x += w

    def _on_header_drag(self, event):
        if self._resize_col is None:
            return
        delta = event.x - self._resize_start_x
        new_w = max(self._min_col_width, self._resize_start_w + delta)
        self._col_widths[self._resize_col] = new_w
        self._draw_header()
        self._update_scroll_region()
        self._redraw()

    def _on_header_release(self, event):
        if self._resize_col is not None:
            self._user_resized_cols.add(self._resize_col)
        self._resize_col = None

    def _on_header_motion(self, event):
        canvas_x = self._header_canvas.canvasx(event.x)
        full_cols = self._get_full_columns()
        x = 0
        near_edge = False
        for col_key, col_label, w in full_cols:
            edge = x + w
            if abs(canvas_x - edge) < 5 and col_key not in ("__add__", "__delete__"):
                near_edge = True
                break
            x += w
        if near_edge:
            self._header_canvas.configure(cursor="sb_h_double_arrow")
        else:
            self._header_canvas.configure(cursor="")

    def _toggle_sort(self, col_key):
        if self._sort_col == col_key:
            if self._sort_dir == "asc":
                self._sort_dir = "desc"
            elif self._sort_dir == "desc":
                self._sort_dir = "default"
                self._sort_col = None
            else:
                self._sort_dir = "asc"
        else:
            self._sort_col = col_key
            self._sort_dir = "asc"

        self._apply_sort()
        self._draw_header()
        self._redraw()

    def _apply_sort(self):
        if self._sort_col is None or self._sort_dir == "default":
            self._display_data = list(self._all_data)
            if not self._display_data:
                return
            try:
                self._display_data.sort(
                    key=lambda r: str(self._get_cell_value(r, "Full Part Name")).lower()
                )
            except Exception:
                pass
            return

        col = self._sort_col
        reverse = self._sort_dir == "desc"

        def sort_key(row):
            val = self._get_cell_value(row, col)
            try:
                return (0, float(val))
            except (ValueError, TypeError):
                return (1, str(val).lower())

        self._display_data = sorted(self._all_data, key=sort_key, reverse=reverse)

    def update_font_size(self, size):
        self._font_size = size
        self._row_height = max(ROW_HEIGHT, int(size * 2.5))
        steps = _get_scale_steps(size)
        extra = 1.0 + steps * 0.2
        self._header_height = int(HEADER_HEIGHT * extra)
        self._action_col_width = int(90 * extra)
        self._header_frame.configure(height=self._header_height)
        self._header_canvas.configure(height=self._header_height)
        self._user_resized_cols.clear()
        self._compute_col_widths(force=True)
        self._draw_header()
        self._update_scroll_region()
        self._redraw()

    def refresh(self):
        self._update_scroll_region()
        self._draw_header()
        self._redraw()

    def get_display_count(self):
        return len(self._display_data)

    def get_total_count(self):
        return len(self._all_data)
