import webbrowser
import tkinter as tk
from app.config import (
    COLORS, FONT_FAMILY, FONT_SIZE_BASE, FONT_SIZE_SMALL, FONT_SIZE_LARGE,
    FONT_SIZE_TITLE, SPACING, PART_CATEGORIES, APP_NAME, APP_VERSION,
    DEFAULT_PART_PRIORITY,
)
from app.ui.tab_bar import SubTabBar
from app.ui.widgets import InfoBox, DarkCheckbutton
from app.logger import get_logger

log = get_logger("Settings")


class SettingsTab(tk.Frame):
    def __init__(self, parent, state_manager, on_scale_change=None, **kwargs):
        super().__init__(parent, bg=COLORS["bg_dark"], **kwargs)
        self._state = state_manager
        self._on_scale_change = on_scale_change

        self._main_sections = ["General", "Column Display", "Part Priority"]

        self._section_bar = SubTabBar(
            self, self._main_sections,
            command=self._on_section_change,
        )
        self._section_bar.pack(fill="x")

        self._container = tk.Frame(self, bg=COLORS["bg_dark"])
        self._container.pack(fill="both", expand=True)

        self._section_frames = {}

        self._build_general()
        self._build_column_display()
        self._build_part_priority()

        self._show_section("General")

    def _show_section(self, name):
        for section_name, frame in self._section_frames.items():
            if section_name == name or section_name.startswith(name + "::"):
                pass
            else:
                frame.pack_forget()

        frame = self._section_frames.get(name)
        if frame:
            frame.pack(fill="both", expand=True)

    def _on_section_change(self, name):
        for f in self._section_frames.values():
            f.pack_forget()

        if name == "Column Display":
            self._col_display_frame.pack(fill="both", expand=True)
        else:
            frame = self._section_frames.get(name)
            if frame:
                frame.pack(fill="both", expand=True)

    def _build_general(self):
        frame = tk.Frame(self._container, bg=COLORS["bg_dark"])
        self._section_frames["General"] = frame

        canvas = tk.Canvas(frame, bg=COLORS["bg_dark"], highlightthickness=0, bd=0)
        scrollbar = tk.Scrollbar(frame, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        inner = tk.Frame(canvas, bg=COLORS["bg_dark"])
        win_id = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(win_id, width=e.width))
        canvas.bind("<MouseWheel>", lambda e: canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))

        padding = {"padx": SPACING["lg"], "pady": SPACING["sm"]}

        self._general_labels = []
        self._general_title_labels = []

        lbl = tk.Label(
            inner, text="General Settings", bg=COLORS["bg_dark"],
            fg=COLORS["fg_header"], font=(FONT_FAMILY, FONT_SIZE_TITLE, "bold"),
        )
        lbl.pack(anchor="w", **padding)
        self._general_title_labels.append(lbl)

        # --- HEM Section ---
        hem_card = tk.Frame(inner, bg=COLORS["bg_card"], padx=SPACING["md"], pady=SPACING["md"])
        hem_card.pack(fill="x", **padding)

        lbl = tk.Label(
            hem_card, text="Hardware Expansion Mod (HEM)",
            bg=COLORS["bg_card"], fg=COLORS["fg_primary"],
            font=(FONT_FAMILY, FONT_SIZE_BASE, "bold"),
        )
        lbl.pack(anchor="w")
        self._general_labels.append((lbl, "bold"))

        lbl = tk.Label(
            hem_card, text="Enable to load additional parts from the HEM mod CSV files.",
            bg=COLORS["bg_card"], fg=COLORS["fg_secondary"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL),
        )
        lbl.pack(anchor="w", pady=(2, SPACING["xs"]))
        self._general_labels.append((lbl, "small"))

        self._hem_var = tk.BooleanVar(value=self._state.get_setting("hem_enabled", False))
        self._hem_cb = DarkCheckbutton(
            hem_card, text="Enable HEM", variable=self._hem_var,
            command=self._on_hem_toggle,
            font_size=FONT_SIZE_BASE,
        )
        self._hem_cb.pack(anchor="w")

        lbl = tk.Label(
            hem_card, text="Note: Changing this requires a restart to reload CSV data.",
            bg=COLORS["bg_card"], fg=COLORS["fg_warning"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL),
        )
        lbl.pack(anchor="w", pady=(SPACING["xs"], 0))
        self._general_labels.append((lbl, "small"))

        # --- Tips Section ---
        tips_card = tk.Frame(inner, bg=COLORS["bg_card"], padx=SPACING["md"], pady=SPACING["md"])
        tips_card.pack(fill="x", **padding)

        lbl = tk.Label(
            tips_card, text="Tips & Info Boxes",
            bg=COLORS["bg_card"], fg=COLORS["fg_primary"],
            font=(FONT_FAMILY, FONT_SIZE_BASE, "bold"),
        )
        lbl.pack(anchor="w")
        self._general_labels.append((lbl, "bold"))

        lbl = tk.Label(
            tips_card, text="Reset all dismissed info boxes and tips throughout the application.",
            bg=COLORS["bg_card"], fg=COLORS["fg_secondary"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL),
        )
        lbl.pack(anchor="w", pady=(2, SPACING["xs"]))
        self._general_labels.append((lbl, "small"))

        self._reset_btn = tk.Button(
            tips_card, text="Reset Tips", command=self._on_reset_tips,
            bg=COLORS["bg_button"], fg=COLORS["fg_button"],
            font=(FONT_FAMILY, FONT_SIZE_BASE), relief="flat",
            activebackground=COLORS["bg_button_hover"],
            activeforeground=COLORS["fg_button"],
            padx=15, pady=5, cursor="hand2",
        )
        self._reset_btn.pack(anchor="w")

        # --- Accessibility Section ---
        lbl = tk.Label(
            inner, text="Accessibility", bg=COLORS["bg_dark"],
            fg=COLORS["fg_header"], font=(FONT_FAMILY, FONT_SIZE_TITLE, "bold"),
        )
        lbl.pack(anchor="w", **padding)
        self._general_title_labels.append(lbl)

        scale_card = tk.Frame(inner, bg=COLORS["bg_card"], padx=SPACING["md"], pady=SPACING["md"])
        scale_card.pack(fill="x", **padding)

        lbl = tk.Label(
            scale_card, text="Text Scaling",
            bg=COLORS["bg_card"], fg=COLORS["fg_primary"],
            font=(FONT_FAMILY, FONT_SIZE_BASE, "bold"),
        )
        lbl.pack(anchor="w")
        self._general_labels.append((lbl, "bold"))

        lbl = tk.Label(
            scale_card, text="Adjust the size of all text in the application. Updates live.",
            bg=COLORS["bg_card"], fg=COLORS["fg_secondary"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL),
        )
        lbl.pack(anchor="w", pady=(2, SPACING["xs"]))
        self._general_labels.append((lbl, "small"))

        # Dropdown for text scale
        scale_frame = tk.Frame(scale_card, bg=COLORS["bg_card"])
        scale_frame.pack(fill="x", pady=(SPACING["xs"], 0))

        self._scale_options = {
            "Small (1x)": 1.0,
            "Medium (1.5x)": 1.5,
            "Large (2x)": 2.0,
            "X-Large (3x)": 3.0,
        }
        current_scale = self._state.get_setting("text_scale", 1.0)
        current_label = "Small (1x)"
        for label, value in self._scale_options.items():
            if abs(value - current_scale) < 0.01:
                current_label = label
                break

        self._scale_var = tk.StringVar(value=current_label)
        self._scale_dropdown = tk.OptionMenu(
            scale_frame, self._scale_var,
            *self._scale_options.keys(),
            command=self._on_scale_change_internal,
        )
        self._scale_dropdown.configure(
            bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
            font=(FONT_FAMILY, FONT_SIZE_BASE),
            activebackground=COLORS["bg_button_hover"],
            activeforeground=COLORS["fg_button"],
            highlightthickness=0, bd=0,
        )
        self._scale_dropdown["menu"].configure(
            bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
            font=(FONT_FAMILY, FONT_SIZE_BASE),
            activebackground=COLORS["bg_button_hover"],
            activeforeground=COLORS["fg_button"],
        )
        self._scale_dropdown.pack(side="left")

        self._scale_display = tk.Label(
            scale_card, text=f"Current: {current_label}",
            bg=COLORS["bg_card"], fg=COLORS["fg_accent"],
            font=(FONT_FAMILY, FONT_SIZE_BASE),
        )
        self._scale_display.pack(anchor="w", pady=(SPACING["xs"], 0))

        # --- Credits Section ---
        lbl = tk.Label(
            inner, text="Credits", bg=COLORS["bg_dark"],
            fg=COLORS["fg_header"], font=(FONT_FAMILY, FONT_SIZE_TITLE, "bold"),
        )
        lbl.pack(anchor="w", **padding)
        self._general_title_labels.append(lbl)

        credits_card = tk.Frame(inner, bg=COLORS["bg_card"], padx=SPACING["md"], pady=SPACING["md"])
        credits_card.pack(fill="x", **padding)

        self._credits_labels = []

        # Application Icon line
        clbl = tk.Label(
            credits_card, text="Application Icon by Freepik from https://www.flaticon.com/free-icon/pc-tower_4617777",
            bg=COLORS["bg_card"], fg=COLORS["fg_muted"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL), anchor="w",
        )
        clbl.pack(anchor="w")
        self._credits_labels.append((clbl, "small"))

        tk.Frame(credits_card, bg=COLORS["bg_card"], height=5).pack()

        # CSV data line with clickable link
        csv_frame = tk.Frame(credits_card, bg=COLORS["bg_card"])
        csv_frame.pack(anchor="w")

        tk.Label(
            csv_frame, text="CSV data compiled from PUC_Snakeman's spreadsheet ",
            bg=COLORS["bg_card"], fg=COLORS["fg_muted"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL), anchor="w",
        ).pack(side="left")

        link_lbl = tk.Label(
            csv_frame, text="[Parts & Unlock Levels]",
            bg=COLORS["bg_card"], fg=COLORS["fg_accent"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL, "underline"), anchor="w",
            cursor="hand2",
        )
        link_lbl.pack(side="left")
        link_lbl.bind("<Button-1>", lambda e: self._open_url("https://steamcommunity.com/sharedfiles/filedetails/?id=1798336403"))
        self._credits_labels.append((link_lbl, "small_link"))

        self._bind_mw(inner, canvas)

    def _build_column_display(self):
        self._col_display_frame = tk.Frame(self._container, bg=COLORS["bg_dark"])
        self._section_frames["Column Display"] = self._col_display_frame

        padding = {"padx": SPACING["lg"], "pady": SPACING["sm"]}

        self._col_title_label = tk.Label(
            self._col_display_frame, text="Column Display Settings",
            bg=COLORS["bg_dark"], fg=COLORS["fg_header"],
            font=(FONT_FAMILY, FONT_SIZE_TITLE, "bold"),
        )
        self._col_title_label.pack(anchor="w", **padding)

        self._col_desc_label = tk.Label(
            self._col_display_frame,
            text="Configure which columns are visible and their order for each part type. Changes apply to both Used and New Parts tabs.",
            bg=COLORS["bg_dark"], fg=COLORS["fg_secondary"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL), wraplength=800, justify="left",
        )
        self._col_desc_label.pack(anchor="w", padx=SPACING["lg"], pady=(0, SPACING["xs"]))

        self._col_subtabs = SubTabBar(
            self._col_display_frame, PART_CATEGORIES,
            command=self._on_col_subtab_change,
        )
        self._col_subtabs.pack(fill="x", padx=SPACING["sm"])

        self._col_editor_frame = tk.Frame(self._col_display_frame, bg=COLORS["bg_dark"])
        self._col_editor_frame.pack(fill="both", expand=True, padx=SPACING["lg"], pady=SPACING["sm"])

        self._col_editors = {}
        self._current_col_cat = PART_CATEGORIES[0]

        self._state.subscribe("catalog", self._build_column_editors)

    def _build_column_editors(self):
        for cat in PART_CATEGORIES:
            columns = self._state.column_map.get(cat, [])
            if not columns:
                continue
            editor = ColumnEditor(
                self._col_editor_frame, cat, columns,
                state_manager=self._state,
            )
            self._col_editors[cat] = editor

        self._show_col_editor(self._current_col_cat)

    def _on_col_subtab_change(self, name):
        self._current_col_cat = name
        self._show_col_editor(name)

    def _show_col_editor(self, category):
        for cat, editor in self._col_editors.items():
            if cat == category:
                editor.pack(fill="both", expand=True)
            else:
                editor.pack_forget()

    def _build_part_priority(self):
        frame = tk.Frame(self._container, bg=COLORS["bg_dark"])
        self._section_frames["Part Priority"] = frame

        padding = {"padx": SPACING["lg"], "pady": SPACING["sm"]}

        self._priority_title_label = tk.Label(
            frame, text="Part Priority", bg=COLORS["bg_dark"],
            fg=COLORS["fg_header"], font=(FONT_FAMILY, FONT_SIZE_TITLE, "bold"),
        )
        self._priority_title_label.pack(anchor="w", **padding)

        self._priority_info = InfoBox(
            frame,
            text="Auto-build will exclude optional parts from being replaced when there are budget constraints. Parts that are lower on this list will be excluded before higher parts.",
            tip_id="part_priority_info",
            state_manager=self._state,
        )
        self._priority_info.pack(fill="x", padx=SPACING["lg"], pady=(0, SPACING["sm"]))

        card = tk.Frame(frame, bg=COLORS["bg_card"], padx=SPACING["md"], pady=SPACING["md"])
        card.pack(fill="both", expand=True, **padding)

        btn_bar = tk.Frame(card, bg=COLORS["bg_card"])
        btn_bar.pack(fill="x", pady=(0, SPACING["xs"]))

        self._up_btn = tk.Button(
            btn_bar, text="▲ Move Up", command=self._priority_move_up,
            bg=COLORS["bg_button"], fg=COLORS["fg_button"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL), relief="flat",
            activebackground=COLORS["bg_button_hover"],
            activeforeground=COLORS["fg_button"],
            padx=10, pady=3, cursor="hand2",
        )
        self._up_btn.pack(side="left", padx=(0, SPACING["xs"]))

        self._down_btn = tk.Button(
            btn_bar, text="▼ Move Down", command=self._priority_move_down,
            bg=COLORS["bg_button"], fg=COLORS["fg_button"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL), relief="flat",
            activebackground=COLORS["bg_button_hover"],
            activeforeground=COLORS["fg_button"],
            padx=10, pady=3, cursor="hand2",
        )
        self._down_btn.pack(side="left")

        list_frame = tk.Frame(card, bg=COLORS["bg_input"], highlightthickness=1,
                              highlightbackground=COLORS["border"])
        list_frame.pack(fill="both", expand=True)

        self._priority_listbox = tk.Listbox(
            list_frame, bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
            font=(FONT_FAMILY, FONT_SIZE_BASE),
            selectbackground=COLORS["bg_selected"],
            selectforeground=COLORS["fg_primary"],
            highlightthickness=0, bd=0, relief="flat",
            activestyle="none",
        )
        lb_scroll = tk.Scrollbar(list_frame, orient="vertical", command=self._priority_listbox.yview)
        self._priority_listbox.configure(yscrollcommand=lb_scroll.set)
        lb_scroll.pack(side="right", fill="y")
        self._priority_listbox.pack(side="left", fill="both", expand=True)

        self._priority_order = list(self._state.get_setting("part_priority", DEFAULT_PART_PRIORITY))
        self._populate_priority_list()

    def _populate_priority_list(self):
        self._priority_listbox.delete(0, "end")
        for i, cat in enumerate(self._priority_order):
            self._priority_listbox.insert("end", f"{i + 1}. {cat}")

    def _priority_move_up(self):
        sel = self._priority_listbox.curselection()
        if not sel or sel[0] == 0:
            return
        idx = sel[0]
        self._priority_order[idx - 1], self._priority_order[idx] = (
            self._priority_order[idx], self._priority_order[idx - 1]
        )
        self._populate_priority_list()
        self._priority_listbox.selection_set(idx - 1)
        self._save_priority()

    def _priority_move_down(self):
        sel = self._priority_listbox.curselection()
        if not sel or sel[0] >= len(self._priority_order) - 1:
            return
        idx = sel[0]
        self._priority_order[idx], self._priority_order[idx + 1] = (
            self._priority_order[idx + 1], self._priority_order[idx]
        )
        self._populate_priority_list()
        self._priority_listbox.selection_set(idx + 1)
        self._save_priority()

    def _save_priority(self):
        self._state.update_setting("part_priority", list(self._priority_order))
        log.info("Part priority updated")

    def _build_credits(self):
        frame = tk.Frame(self._container, bg=COLORS["bg_dark"])
        self._section_frames["Credits"] = frame

        padding = {"padx": SPACING["lg"], "pady": SPACING["sm"]}

        self._credits_title_label = tk.Label(
            frame, text="Credits", bg=COLORS["bg_dark"],
            fg=COLORS["fg_header"], font=(FONT_FAMILY, FONT_SIZE_TITLE, "bold"),
        )
        self._credits_title_label.pack(anchor="w", **padding)

        credits_card = tk.Frame(frame, bg=COLORS["bg_card"], padx=SPACING["md"], pady=SPACING["md"])
        credits_card.pack(fill="x", **padding)

        self._credits_section_labels = []

        # Application Icon line
        clbl = tk.Label(
            credits_card, text="Application Icon by Freepik from https://www.flaticon.com/free-icon/pc-tower_4617777",
            bg=COLORS["bg_card"], fg=COLORS["fg_muted"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL), anchor="w",
        )
        clbl.pack(anchor="w")
        self._credits_section_labels.append((clbl, "small"))

        tk.Frame(credits_card, bg=COLORS["bg_card"], height=5).pack()

        # CSV data line with clickable link
        csv_frame = tk.Frame(credits_card, bg=COLORS["bg_card"])
        csv_frame.pack(anchor="w")

        tk.Label(
            csv_frame, text="CSV data compiled from PUC_Snakeman's spreadsheet ",
            bg=COLORS["bg_card"], fg=COLORS["fg_muted"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL), anchor="w",
        ).pack(side="left")

        link_lbl = tk.Label(
            csv_frame, text="[Parts & Unlock Levels]",
            bg=COLORS["bg_card"], fg=COLORS["fg_accent"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL, "underline"), anchor="w",
            cursor="hand2",
        )
        link_lbl.pack(side="left")
        link_lbl.bind("<Button-1>", lambda e: self._open_url("https://steamcommunity.com/sharedfiles/filedetails/?id=1798336403"))
        self._credits_section_labels.append((link_lbl, "small_link"))

    def _open_url(self, url):
        webbrowser.open(url)

    def _on_hem_toggle(self):
        self._state.update_setting("hem_enabled", self._hem_var.get())
        log.info(f"HEM {'enabled' if self._hem_var.get() else 'disabled'}")

    def _on_reset_tips(self):
        self._state.reset_tips()
        log.info("Tips reset by user")

    def _on_scale_change_internal(self, value):
        label = value
        scale = self._scale_options.get(label, 1.0)
        self._scale_display.configure(text=f"Current: {label}")
        self._state.update_setting("text_scale", scale)
        if self._on_scale_change:
            self._on_scale_change(scale)

    def _bind_mw(self, widget, canvas):
        widget.bind("<MouseWheel>", lambda e: canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))
        for child in widget.winfo_children():
            self._bind_mw(child, canvas)

    def update_font_size(self, size):
        self._section_bar.update_font_size(size)
        if hasattr(self, "_col_subtabs"):
            self._col_subtabs.update_font_size(size)
        # Update scale dropdown and display
        if hasattr(self, "_scale_dropdown"):
            self._scale_dropdown.configure(font=(FONT_FAMILY, size))
            self._scale_dropdown["menu"].configure(font=(FONT_FAMILY, size))
        if hasattr(self, "_scale_display"):
            self._scale_display.configure(font=(FONT_FAMILY, size))
        # Update priority listbox
        if hasattr(self, "_priority_listbox"):
            self._priority_listbox.configure(font=(FONT_FAMILY, size))
        # Update info boxes
        if hasattr(self, "_priority_info"):
            self._priority_info.update_font_size(size)
        # Update HEM checkbox (DarkCheckbutton)
        if hasattr(self, "_hem_cb"):
            self._hem_cb.update_font_size(size)
        # Update Reset Tips button
        if hasattr(self, "_reset_btn"):
            self._reset_btn.configure(font=(FONT_FAMILY, size))
        # Update Move Up/Down buttons
        if hasattr(self, "_up_btn"):
            self._up_btn.configure(font=(FONT_FAMILY, max(size - 1, 8)))
        if hasattr(self, "_down_btn"):
            self._down_btn.configure(font=(FONT_FAMILY, max(size - 1, 8)))
        # Update ColumnEditors
        for editor in getattr(self, "_col_editors", {}).values():
            if hasattr(editor, "update_font_size"):
                editor.update_font_size(size)
        # Update General section title labels (section headings)
        for lbl in getattr(self, "_general_title_labels", []):
            lbl.configure(font=(FONT_FAMILY, max(size + 4, 14), "bold"))
        # Update General section body labels
        for lbl, style in getattr(self, "_general_labels", []):
            if style == "bold":
                lbl.configure(font=(FONT_FAMILY, size, "bold"))
            else:
                lbl.configure(font=(FONT_FAMILY, max(size - 1, 8)))
        # Update Column Display section labels
        if hasattr(self, "_col_title_label"):
            self._col_title_label.configure(font=(FONT_FAMILY, max(size + 4, 14), "bold"))
        if hasattr(self, "_col_desc_label"):
            self._col_desc_label.configure(font=(FONT_FAMILY, max(size - 1, 8)))
        # Update Part Priority title label
        if hasattr(self, "_priority_title_label"):
            self._priority_title_label.configure(font=(FONT_FAMILY, max(size + 4, 14), "bold"))
        # Update credits labels
        for clbl, scale_type in getattr(self, "_credits_labels", []):
            if scale_type == "large_bold":
                clbl.configure(font=(FONT_FAMILY, max(size + 2, 12), "bold"))
            elif scale_type == "base":
                clbl.configure(font=(FONT_FAMILY, size))
            elif scale_type == "small":
                clbl.configure(font=(FONT_FAMILY, max(size - 1, 8)))
            elif scale_type == "small_link":
                clbl.configure(font=(FONT_FAMILY, max(size - 1, 8), "underline"))
        # Update standalone Credits section
        if hasattr(self, "_credits_title_label"):
            self._credits_title_label.configure(font=(FONT_FAMILY, max(size + 4, 14), "bold"))
        for clbl, scale_type in getattr(self, "_credits_section_labels", []):
            if scale_type == "large_bold":
                clbl.configure(font=(FONT_FAMILY, max(size + 2, 12), "bold"))
            elif scale_type == "base":
                clbl.configure(font=(FONT_FAMILY, size))
            elif scale_type == "small":
                clbl.configure(font=(FONT_FAMILY, max(size - 1, 8)))
            elif scale_type == "small_link":
                clbl.configure(font=(FONT_FAMILY, max(size - 1, 8), "underline"))
        # Update ColumnEditor instructions label
        for editor in getattr(self, "_col_editors", {}).values():
            for child in editor.winfo_children():
                if isinstance(child, tk.Label):
                    child.configure(font=(FONT_FAMILY, max(size - 1, 8)))


class ColumnEditor(tk.Frame):
    def __init__(self, parent, category, columns, state_manager=None, **kwargs):
        super().__init__(parent, bg=COLORS["bg_dark"], **kwargs)
        self._category = category
        self._all_columns = list(columns)
        self._state = state_manager

        col_settings = self._state.get_setting("column_display", {})
        cat_settings = col_settings.get(category, {})
        saved_visible = cat_settings.get("visible", list(columns))
        saved_order = cat_settings.get("order", list(columns))
        saved_renames = cat_settings.get("renames", {})

        self._ordered = []
        for c in saved_order:
            if c in self._all_columns:
                self._ordered.append(c)
        for c in self._all_columns:
            if c not in self._ordered:
                self._ordered.append(c)

        self._visible_set = set(saved_visible)
        self._renames = dict(saved_renames)

        if "Full Part Name" not in self._visible_set:
            self._visible_set.add("Full Part Name")

        # Drag state
        self._drag_col = None
        self._drag_start_y = 0
        self._drop_indicator = None

        # Instructions
        self._instructions_label = tk.Label(
            self, text="Check to show column. Uncheck to hide. Type new name to rename. Drag ≡ to reorder.",
            bg=COLORS["bg_dark"], fg=COLORS["fg_secondary"],
            font=(FONT_FAMILY, FONT_SIZE_SMALL),
            anchor="w",
        )
        self._instructions_label.pack(fill="x", pady=(0, SPACING["xs"]))

        # Scrollable frame for columns
        self._canvas = tk.Canvas(self, bg=COLORS["bg_dark"], highlightthickness=0, bd=0)
        scrollbar = tk.Scrollbar(self, orient="vertical", command=self._canvas.yview)
        self._canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self._canvas.pack(side="left", fill="both", expand=True)

        self._inner = tk.Frame(self._canvas, bg=COLORS["bg_dark"])
        self._win_id = self._canvas.create_window((0, 0), window=self._inner, anchor="nw")
        self._inner.bind("<Configure>", lambda e: self._canvas.configure(scrollregion=self._canvas.bbox("all")))
        self._canvas.bind("<Configure>", lambda e: self._canvas.itemconfig(self._win_id, width=e.width))
        self._canvas.bind("<MouseWheel>", lambda e: self._canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))

        # Drop indicator line
        self._drop_indicator = tk.Frame(self._inner, bg=COLORS["fg_accent"], height=3)

        self._column_rows = {}
        self._drag_handles = {}
        self._check_vars = {}
        self._rename_entries = {}

        for col in self._ordered:
            self._create_row(col)

    def _create_row(self, col):
        is_visible = col in self._visible_set
        display_name = self._renames.get(col, col)
        is_locked = col == "Full Part Name"

        row = tk.Frame(self._inner, bg=COLORS["bg_card"], padx=SPACING["sm"], pady=SPACING["xs"])
        row.pack(fill="x", pady=(0, 2))
        self._column_rows[col] = row

        # Drag handle
        handle = tk.Label(
            row, text="\u2261", bg=COLORS["bg_card"], fg=COLORS["fg_muted"],
            font=(FONT_FAMILY, FONT_SIZE_BASE + 2), cursor="fleur",
        )
        handle.pack(side="left", padx=(0, SPACING["xs"]))
        self._drag_handles[col] = handle

        handle.bind("<ButtonPress-1>", lambda e, c=col: self._on_drag_start(e, c))
        handle.bind("<B1-Motion>", self._on_drag_motion)
        handle.bind("<ButtonRelease-1>", self._on_drag_end)

        # Checkbox for visibility
        var = tk.BooleanVar(value=is_visible)
        self._check_vars[col] = var
        cb = DarkCheckbutton(
            row, variable=var,
            command=lambda c=col: self._on_visibility_change(c),
            font_size=FONT_SIZE_BASE,
        )
        if is_locked:
            cb._canvas.configure(state="disabled")
        cb.pack(side="left")

        # Original column name label
        tk.Label(
            row, text=col,
            bg=COLORS["bg_card"], fg=COLORS["fg_muted"] if is_visible else COLORS["fg_secondary"],
            font=(FONT_FAMILY, FONT_SIZE_BASE),
        ).pack(side="left", padx=(SPACING["xs"], 0))

        # Arrow
        tk.Label(
            row, text="\u2192",
            bg=COLORS["bg_card"], fg=COLORS["fg_accent"],
            font=(FONT_FAMILY, FONT_SIZE_BASE),
        ).pack(side="left", padx=SPACING["xs"])

        # Rename input
        entry = tk.Entry(
            row, bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
            insertbackground=COLORS["fg_primary"], relief="flat",
            font=(FONT_FAMILY, FONT_SIZE_BASE),
            highlightthickness=1, highlightbackground=COLORS["border"],
            highlightcolor=COLORS["border_accent"],
            width=25,
        )
        entry.insert(0, display_name)
        entry.pack(side="left", fill="x", expand=True)
        self._rename_entries[col] = entry

        entry.bind("<FocusOut>", lambda e, c=col: self._on_rename(c))
        entry.bind("<Return>", lambda e, c=col: self._on_rename(c))

    # ── Drag and Drop ────────────────────────────────────────────────

    def _on_drag_start(self, event, col):
        self._drag_col = col
        row = self._column_rows[col]
        row.configure(bg=COLORS["bg_hover"])
        for child in row.winfo_children():
            try:
                child.configure(bg=COLORS["bg_hover"])
            except tk.TclError:
                pass

    def _on_drag_motion(self, event):
        if self._drag_col is None:
            return
        # Get mouse Y in canvas coordinates
        widget = event.widget
        mouse_y_screen = widget.winfo_rooty() + event.y
        canvas_y = mouse_y_screen - self._inner.winfo_rooty()

        # Determine which position the mouse is over
        target_idx = len(self._ordered) - 1
        for i, col in enumerate(self._ordered):
            row = self._column_rows[col]
            row_y = row.winfo_y()
            row_h = row.winfo_height()
            if canvas_y < row_y + row_h // 2:
                target_idx = i
                break

        # Show drop indicator
        self._drop_indicator.pack_forget()
        if target_idx < len(self._ordered):
            target_col = self._ordered[target_idx]
            target_row = self._column_rows[target_col]
            self._drop_indicator.pack(fill="x", before=target_row)
        else:
            self._drop_indicator.pack(fill="x")

    def _on_drag_end(self, event):
        if self._drag_col is None:
            return

        col = self._drag_col
        row = self._column_rows[col]

        # Reset row styling
        row.configure(bg=COLORS["bg_card"])
        for child in row.winfo_children():
            try:
                child.configure(bg=COLORS["bg_card"])
            except tk.TclError:
                pass

        # Hide drop indicator
        self._drop_indicator.pack_forget()

        # Determine drop position
        widget = event.widget
        mouse_y_screen = widget.winfo_rooty() + event.y
        canvas_y = mouse_y_screen - self._inner.winfo_rooty()

        target_idx = len(self._ordered)
        for i, c in enumerate(self._ordered):
            r = self._column_rows[c]
            row_y = r.winfo_y()
            row_h = r.winfo_height()
            if canvas_y < row_y + row_h // 2:
                target_idx = i
                break

        old_idx = self._ordered.index(col)
        if old_idx != target_idx and old_idx != target_idx - 1:
            self._ordered.remove(col)
            if target_idx > old_idx:
                target_idx -= 1
            self._ordered.insert(target_idx, col)
            self._rebuild_rows()
            self._save()

        self._drag_col = None

    # ── Callbacks ────────────────────────────────────────────────────

    def _on_visibility_change(self, col):
        is_visible = self._check_vars[col].get()
        if is_visible:
            self._visible_set.add(col)
        else:
            if col != "Full Part Name":
                self._visible_set.discard(col)
        self._save()
        # Update label color
        row = self._column_rows.get(col)
        if row:
            for child in row.winfo_children():
                if isinstance(child, tk.Label) and child.cget("text") == col:
                    child.configure(fg=COLORS["fg_muted"] if is_visible else COLORS["fg_secondary"])
                    break

    def _on_rename(self, col):
        entry = self._rename_entries.get(col)
        if not entry:
            return
        new_name = entry.get().strip()
        if not new_name or new_name == col:
            if col in self._renames:
                del self._renames[col]
        else:
            self._renames[col] = new_name
        self._save()

    def _rebuild_rows(self):
        self._drop_indicator.pack_forget()
        for col in self._ordered:
            row = self._column_rows[col]
            row.pack_forget()
            row.pack(fill="x", pady=(0, 2))

    def _save(self):
        col_settings = dict(self._state.get_setting("column_display", {}))
        col_settings[self._category] = {
            "visible": list(self._visible_set),
            "order": list(self._ordered),
            "renames": dict(self._renames),
        }
        self._state.update_setting("column_display", col_settings)
        log.info(f"Column display updated for {self._category}")

    def update_font_size(self, size):
        self._instructions_label.configure(font=(FONT_FAMILY, max(size - 1, 8)))
        for entry in self._rename_entries.values():
            entry.configure(font=(FONT_FAMILY, size))
        for col, handle in self._drag_handles.items():
            handle.configure(font=(FONT_FAMILY, size + 2))
        for row in self._column_rows.values():
            for child in row.winfo_children():
                if isinstance(child, DarkCheckbutton):
                    child.update_font_size(size)
                elif isinstance(child, tk.Label):
                    child.configure(font=(FONT_FAMILY, size))
                elif isinstance(child, tk.Entry):
                    child.configure(font=(FONT_FAMILY, size))
