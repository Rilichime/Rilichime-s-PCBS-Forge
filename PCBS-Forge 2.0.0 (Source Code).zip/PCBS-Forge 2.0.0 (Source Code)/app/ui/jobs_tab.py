import tkinter as tk
import math
from app.config import (
    COLORS, FONT_FAMILY, FONT_SIZE_BASE, FONT_SIZE_SMALL, FONT_SIZE_LARGE,
    SPACING, JOB_SLOT_ORDER, JOB_SLOTS, JOB_PART_CATEGORIES,
    DEFAULT_PART_PRIORITY, SEARCH_DEBOUNCE_MS,
)
from app.ui.widgets import FlatButton, InfoBox, ScrollableFrame, DarkCheckbutton
from app.ui.dialogs import show_confirmation, show_input_dialog
from app.scoring import calculate_3dmark
from app.compatibility import check_compatibility
from app.logger import get_logger

log = get_logger("Jobs")


def _safe_float(value, default=0.0):
    try:
        return float(value)
    except (ValueError, TypeError):
        return default


def _safe_int(value, default=0):
    try:
        return int(float(value))
    except (ValueError, TypeError):
        return default


def _is_inferior(original_data, replacement_data, category):
    if original_data is None or replacement_data is None:
        return False
    if category == "CPU":
        if _safe_float(replacement_data.get("Frequency", 0)) < _safe_float(original_data.get("Frequency", 0)):
            return True
        if _safe_int(replacement_data.get("Cores", 0)) < _safe_int(original_data.get("Cores", 0)):
            return True
    elif category == "GPU":
        if _safe_float(replacement_data.get("VRAM (GB)", 0)) < _safe_float(original_data.get("VRAM (GB)", 0)):
            return True
        if _safe_float(replacement_data.get("Base Core Freq", 0)) < _safe_float(original_data.get("Base Core Freq", 0)):
            return True
        if _safe_float(replacement_data.get("Base Mem Freq", 0)) < _safe_float(original_data.get("Base Mem Freq", 0)):
            return True
    elif category == "RAM":
        if _safe_float(replacement_data.get("Size (GB)", 0)) < _safe_float(original_data.get("Size (GB)", 0)):
            return True
        if _safe_float(replacement_data.get("Frequency", 0)) < _safe_float(original_data.get("Frequency", 0)):
            return True
    elif category == "Storage":
        if _safe_float(replacement_data.get("Size (GB)", 0)) < _safe_float(original_data.get("Size (GB)", 0)):
            return True
        if _safe_float(replacement_data.get("Transfer Speed (MB/s)", 0)) < _safe_float(original_data.get("Transfer Speed (MB/s)", 0)):
            return True
    elif category == "PSU":
        if _safe_float(replacement_data.get("Wattage", 0)) < _safe_float(original_data.get("Wattage", 0)):
            return True
    elif category == "Motherboard":
        if _safe_float(replacement_data.get("Max RAM Speed", 0)) < _safe_float(original_data.get("Max RAM Speed", 0)):
            return True
    elif category in ("CPU Cooler", "Case Fan"):
        if _safe_float(replacement_data.get("Air Flow", 0)) < _safe_float(original_data.get("Air Flow", 0)):
            return True
    return False


def _get_unlocked_categories(replace_parts_checked, three_dmark_check):
    unlocked = set()
    if replace_parts_checked.get("CPU Cooler"):
        unlocked.add("CPU Cooler")
        unlocked.add("Case Fan")
    if replace_parts_checked.get("CPU"):
        unlocked.update(["CPU", "CPU Cooler", "Motherboard", "PSU"])
    if replace_parts_checked.get("GPU"):
        unlocked.update(["GPU", "PSU"])
    if replace_parts_checked.get("Motherboard"):
        unlocked.add("Motherboard")
    if replace_parts_checked.get("PSU"):
        unlocked.add("PSU")
    if replace_parts_checked.get("RAM"):
        unlocked.add("RAM")
    if replace_parts_checked.get("Storage"):
        unlocked.add("Storage")
    if three_dmark_check:
        unlocked.update(["Motherboard", "CPU", "CPU Cooler", "GPU", "RAM", "PSU"])
    return unlocked


def _get_required_optional(replace_parts_checked):
    required = set()
    optional = set()
    if replace_parts_checked.get("CPU Cooler"):
        required.add("CPU Cooler")
        optional.add("Case Fan")
    if replace_parts_checked.get("CPU"):
        required.add("CPU")
        optional.update(["CPU Cooler", "Motherboard", "PSU"])
    if replace_parts_checked.get("GPU"):
        required.add("GPU")
        optional.add("PSU")
    if replace_parts_checked.get("Motherboard"):
        required.add("Motherboard")
    if replace_parts_checked.get("PSU"):
        required.add("PSU")
    if replace_parts_checked.get("RAM"):
        required.add("RAM")
    if replace_parts_checked.get("Storage"):
        required.add("Storage")
    optional -= required
    return required, optional


class JobsTab(tk.Frame):
    def __init__(self, parent, state_manager, **kwargs):
        super().__init__(parent, bg=COLORS["bg_dark"], **kwargs)
        self._state = state_manager
        self._current_font_size = FONT_SIZE_BASE
        self._debounce_ids = {}

        self._info_box = InfoBox(
            self,
            text="This section is designed to help you complete email jobs. It will only take parts from the New Parts inventory.",
            tip_id="jobs_info",
            state_manager=state_manager,
        )
        self._info_box.pack(fill="x", padx=SPACING["sm"], pady=(SPACING["sm"], 0))

        top_buttons = tk.Frame(self, bg=COLORS["bg_dark"])
        top_buttons.pack(fill="x", padx=SPACING["sm"], pady=SPACING["sm"])

        self._create_btn = FlatButton(
            top_buttons, text="Create", command=self._on_create,
            bg="#33f95d", hover_bg="#2ad94f",
            width=90, height=30,
        )
        self._create_btn.pack(side="left", padx=(0, SPACING["xs"]))

        self._rename_btn = FlatButton(
            top_buttons, text="Rename", command=self._on_rename,
            width=90, height=30,
        )
        self._rename_btn.pack(side="left", padx=(0, SPACING["xs"]))

        self._delete_btn = FlatButton(
            top_buttons, text="Delete", command=self._on_delete,
            bg="#f93333", hover_bg="#d62a2a",
            width=90, height=30,
        )
        self._delete_btn.pack(side="left", padx=(0, SPACING["xs"]))

        self._complete_btn = FlatButton(
            top_buttons, text="Complete", command=self._on_complete,
            bg="#33d1f9", hover_bg="#2ab8d6",
            width=100, height=30,
        )
        self._complete_btn.pack(side="left")

        main_area = tk.Frame(self, bg=COLORS["bg_dark"])
        main_area.pack(fill="both", expand=True, padx=SPACING["sm"], pady=(0, SPACING["sm"]))

        self._job_list_frame = tk.Frame(main_area, bg=COLORS["bg_card"], width=220)
        self._job_list_frame.pack(side="left", fill="y", padx=(0, SPACING["sm"]))
        self._job_list_frame.pack_propagate(False)
        self._base_list_width = 220  # Store base width for scaling

        self._list_label = tk.Label(
            self._job_list_frame, text="Jobs", bg=COLORS["bg_card"],
            fg=COLORS["fg_header"], font=(FONT_FAMILY, FONT_SIZE_BASE, "bold"),
            anchor="w", padx=SPACING["sm"], pady=SPACING["xs"],
        )
        self._list_label.pack(fill="x")

        self._job_listbox_frame = tk.Frame(self._job_list_frame, bg=COLORS["bg_card"])
        self._job_listbox_frame.pack(fill="both", expand=True)

        self._job_listbox = tk.Listbox(
            self._job_listbox_frame, bg=COLORS["bg_card"], fg=COLORS["fg_primary"],
            font=(FONT_FAMILY, FONT_SIZE_BASE),
            selectbackground=COLORS["bg_selected"],
            selectforeground=COLORS["fg_button"],
            highlightthickness=0, bd=0, relief="flat",
            activestyle="none",
        )
        lb_scroll = tk.Scrollbar(self._job_listbox_frame, orient="vertical", command=self._job_listbox.yview)
        self._job_listbox.configure(yscrollcommand=lb_scroll.set)
        lb_scroll.pack(side="right", fill="y")
        self._job_listbox.pack(side="left", fill="both", expand=True)
        self._job_listbox.bind("<<ListboxSelect>>", self._on_job_select)

        self._detail_frame = tk.Frame(main_area, bg=COLORS["bg_dark"])
        self._detail_frame.pack(side="left", fill="both", expand=True)

        self._detail_canvas = tk.Canvas(
            self._detail_frame, bg=COLORS["bg_dark"], highlightthickness=0, bd=0,
        )
        self._detail_scroll = tk.Scrollbar(
            self._detail_frame, orient="vertical", command=self._detail_canvas.yview,
        )
        self._detail_canvas.configure(yscrollcommand=self._detail_scroll.set)
        self._detail_scroll.pack(side="right", fill="y")
        self._detail_canvas.pack(side="left", fill="both", expand=True)

        self._detail_inner = tk.Frame(self._detail_canvas, bg=COLORS["bg_dark"])
        self._detail_window = self._detail_canvas.create_window((0, 0), window=self._detail_inner, anchor="nw")

        self._detail_inner.bind("<Configure>", lambda e: self._detail_canvas.configure(scrollregion=self._detail_canvas.bbox("all")))
        self._detail_canvas.bind("<Configure>", lambda e: self._detail_canvas.itemconfig(self._detail_window, width=e.width))
        self._detail_canvas.bind("<MouseWheel>", lambda e: self._detail_canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))

        self._state.subscribe("jobs", self._refresh)
        self._state.subscribe("active_job", self._refresh)
        self._state.subscribe("new_parts", self._refresh)
        self._state.subscribe("settings", self._on_settings_change)
        self._state.subscribe("catalog", self._refresh)

        self.after(100, self._refresh)

    # ── Refresh ──────────────────────────────────────────────────────

    def _refresh(self):
        self._refresh_job_list()
        self._refresh_detail()

    def _refresh_job_list(self):
        self._job_listbox.delete(0, "end")
        active_id = self._state.active_job_id
        select_idx = None
        for i, job in enumerate(self._state.jobs):
            self._job_listbox.insert("end", job["name"])
            if job["id"] == active_id:
                select_idx = i
        if select_idx is not None:
            self._job_listbox.selection_set(select_idx)
            self._job_listbox.see(select_idx)

    def _refresh_detail(self):
        for widget in self._detail_inner.winfo_children():
            widget.destroy()

        job = self._state.get_active_job()
        if job is None:
            no_job = tk.Label(
                self._detail_inner, text="No job selected. Create a job to get started.",
                bg=COLORS["bg_dark"], fg=COLORS["fg_muted"],
                font=(FONT_FAMILY, self._current_font_size),
            )
            no_job.pack(pady=SPACING["xl"])
            return

        self._build_level_budget_section(job)
        self._build_job_details_section(job)
        self._build_bonus_objectives_section(job)
        if job.get("replace_upgrade") or job.get("new_pc_build"):
            self._build_auto_build_section(job)
        self._build_job_build_section(job)

        self._bind_mousewheel_recursive(self._detail_inner)

    # ── Level & Budget Section ───────────────────────────────────────

    def _build_level_budget_section(self, job):
        section = tk.Frame(self._detail_inner, bg=COLORS["bg_card"])
        section.pack(fill="x", pady=(0, SPACING["sm"]))

        tk.Label(
            section, text="Level & Budget", bg=COLORS["bg_card"],
            fg=COLORS["fg_header"], font=(FONT_FAMILY, self._current_font_size, "bold"),
            anchor="w", padx=SPACING["sm"], pady=SPACING["xs"],
        ).pack(fill="x")

        content = tk.Frame(section, bg=COLORS["bg_card"], padx=SPACING["sm"], pady=SPACING["xs"])
        content.pack(fill="x")

        story_var = tk.BooleanVar(value=job.get("story_job", False))
        DarkCheckbutton(
            content, text="Story Job", variable=story_var,
            command=lambda: self._on_story_toggle(job, story_var),
            font_size=self._current_font_size,
        ).pack(anchor="w")

        budget_row = tk.Frame(content, bg=COLORS["bg_card"])
        budget_row.pack(fill="x", pady=(SPACING["xs"], 0))

        tk.Label(
            budget_row, text="Budget: $", bg=COLORS["bg_card"],
            fg=COLORS["fg_primary"], font=(FONT_FAMILY, self._current_font_size),
        ).pack(side="left")

        budget_entry = tk.Entry(
            budget_row, bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
            insertbackground=COLORS["fg_primary"], relief="flat",
            font=(FONT_FAMILY, self._current_font_size), width=8,
            highlightthickness=1, highlightbackground=COLORS["border"],
            highlightcolor=COLORS["border_accent"],
        )
        budget_entry.pack(side="left", padx=(0, SPACING["sm"]))
        budget_entry.insert(0, str(job.get("budget", 0)))
        budget_entry.bind("<KeyRelease>", lambda e: self._on_budget_change(job, budget_entry))

        budget_val = job.get("budget", 0)
        actual_budget = budget_val * 1.1

        if job.get("story_job"):
            actual_text = "Actual Budget: $unlimited"
        else:
            actual_text = f"Actual Budget: ${int(actual_budget):,}"

        tk.Label(
            budget_row, text=actual_text, bg=COLORS["bg_card"],
            fg=COLORS["fg_primary"], font=(FONT_FAMILY, self._current_font_size),
        ).pack(side="left", padx=(0, SPACING["sm"]))

        total_price = self._calculate_job_total_price(job)

        if job.get("story_job"):
            budget_left_text = "Budget Left: $unlimited"
        else:
            budget_left = actual_budget - total_price
            budget_left_text = f"Budget Left: ${int(budget_left):,}"

        tk.Label(
            budget_row, text=budget_left_text, bg=COLORS["bg_card"],
            fg="#f9aa33", font=(FONT_FAMILY, self._current_font_size),
        ).pack(side="left")

        level_row = tk.Frame(content, bg=COLORS["bg_card"])
        level_row.pack(fill="x", pady=(SPACING["xs"], SPACING["xs"]))

        tk.Label(
            level_row, text="Level:", bg=COLORS["bg_card"],
            fg=COLORS["fg_primary"], font=(FONT_FAMILY, self._current_font_size),
        ).pack(side="left")

        level_entry = tk.Entry(
            level_row, bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
            insertbackground=COLORS["fg_primary"], relief="flat",
            font=(FONT_FAMILY, self._current_font_size), width=5,
            highlightthickness=1, highlightbackground=COLORS["border"],
            highlightcolor=COLORS["border_accent"],
        )
        level_entry.pack(side="left", padx=(SPACING["xs"], SPACING["sm"]))
        level_entry.insert(0, str(job.get("level", 1)))
        level_entry.bind("<KeyRelease>", lambda e: self._on_level_change(job, level_entry))

        tk.Label(
            level_row, text="Progress:", bg=COLORS["bg_card"],
            fg=COLORS["fg_primary"], font=(FONT_FAMILY, self._current_font_size),
        ).pack(side="left")

        progress_entry = tk.Entry(
            level_row, bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
            insertbackground=COLORS["fg_primary"], relief="flat",
            font=(FONT_FAMILY, self._current_font_size), width=5,
            highlightthickness=1, highlightbackground=COLORS["border"],
            highlightcolor=COLORS["border_accent"],
        )
        progress_entry.pack(side="left", padx=(SPACING["xs"], 0))
        progress_entry.insert(0, str(job.get("progress", 0)))
        progress_entry.bind("<KeyRelease>", lambda e: self._on_progress_change(job, progress_entry))

        tk.Label(
            level_row, text="%", bg=COLORS["bg_card"],
            fg=COLORS["fg_primary"], font=(FONT_FAMILY, self._current_font_size),
        ).pack(side="left")

    def _calculate_job_total_price(self, job):
        total = 0.0
        if job.get("new_pc_build"):
            for cat in JOB_SLOT_ORDER:
                for s in job.get("build_slots", {}).get(cat, []):
                    if s is not None:
                        part = self._resolve_slot(s)
                        if part:
                            total += _safe_float(part.get("Price", 0))
        elif job.get("replace_upgrade"):
            for cat in JOB_SLOT_ORDER:
                for s in job.get("player_slots", {}).get(cat, []):
                    if s is not None:
                        if isinstance(s, dict) and (s.get("locked") or s.get("original")):
                            continue
                        part = self._resolve_slot(s)
                        if part:
                            total += _safe_float(part.get("Price", 0))
        return total

    def _resolve_slot(self, slot_val):
        if slot_val is None:
            return None
        if isinstance(slot_val, str):
            for p in self._state.new_parts:
                if p["instance_id"] == slot_val:
                    return p.get("data", {})
            return None
        if isinstance(slot_val, dict):
            if "data" in slot_val:
                return slot_val["data"]
            if "Full Part Name" in slot_val:
                return slot_val
        return None

    # ── Job Details Section ──────────────────────────────────────────

    def _build_job_details_section(self, job):
        section = tk.Frame(self._detail_inner, bg=COLORS["bg_card"])
        section.pack(fill="x", pady=(0, SPACING["sm"]))

        tk.Label(
            section, text="Job Details", bg=COLORS["bg_card"],
            fg=COLORS["fg_header"], font=(FONT_FAMILY, self._current_font_size, "bold"),
            anchor="w", padx=SPACING["sm"], pady=SPACING["xs"],
        ).pack(fill="x")

        content = tk.Frame(section, bg=COLORS["bg_card"], padx=SPACING["sm"], pady=SPACING["xs"])
        content.pack(fill="x")

        new_build_var = tk.BooleanVar(value=job.get("new_pc_build", False))
        DarkCheckbutton(
            content, text="New PC Build", variable=new_build_var,
            command=lambda: self._on_detail_toggle(job, "new_pc_build", new_build_var),
            font_size=self._current_font_size,
        ).pack(anchor="w")

        replace_var = tk.BooleanVar(value=job.get("replace_upgrade", False))
        DarkCheckbutton(
            content, text="Replace / Upgrade Parts", variable=replace_var,
            command=lambda: self._on_detail_toggle(job, "replace_upgrade", replace_var),
            font_size=self._current_font_size,
        ).pack(anchor="w")

        if job.get("replace_upgrade"):
            parts_frame = tk.Frame(content, bg=COLORS["bg_card"], padx=SPACING["lg"])
            parts_frame.pack(fill="x")
            replace_checked = job.get("replace_parts_checked", {})
            for cat in JOB_PART_CATEGORIES:
                cat_var = tk.BooleanVar(value=replace_checked.get(cat, False))
                DarkCheckbutton(
                    parts_frame, text=cat, variable=cat_var,
                    command=lambda c=cat, v=cat_var: self._on_replace_part_toggle(job, c, v),
                    font_size=self._current_font_size,
                ).pack(anchor="w")

        # Show AIO Cooling Required checkbox when CPU Cooler is relevant
        cpu_cooler_relevant = job.get("new_pc_build", False) or (
            job.get("replace_upgrade", False) and job.get("replace_parts_checked", {}).get("CPU Cooler", False)
        )
        if cpu_cooler_relevant:
            aio_frame = tk.Frame(content, bg=COLORS["bg_card"], padx=SPACING["lg"])
            aio_frame.pack(fill="x")
            aio_var = tk.BooleanVar(value=job.get("aio_cooling_required", False))
            DarkCheckbutton(
                aio_frame, text="AIO Cooling Required", variable=aio_var,
                command=lambda: self._on_detail_toggle(job, "aio_cooling_required", aio_var),
                font_size=self._current_font_size,
            ).pack(anchor="w")

        three_d_var = tk.BooleanVar(value=job.get("three_dmark_check", False))
        DarkCheckbutton(
            content, text="3DMark Score", variable=three_d_var,
            command=lambda: self._on_detail_toggle(job, "three_dmark_check", three_d_var),
            font_size=self._current_font_size,
        ).pack(anchor="w")

        if job.get("three_dmark_check"):
            three_d_frame = tk.Frame(content, bg=COLORS["bg_card"], padx=SPACING["lg"])
            three_d_frame.pack(fill="x")
            tk.Label(
                three_d_frame, text="3DMark Score:", bg=COLORS["bg_card"],
                fg=COLORS["fg_primary"], font=(FONT_FAMILY, self._current_font_size),
            ).pack(side="left")
            three_d_entry = tk.Entry(
                three_d_frame, bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
                insertbackground=COLORS["fg_primary"], relief="flat",
                font=(FONT_FAMILY, self._current_font_size), width=10,
                highlightthickness=1, highlightbackground=COLORS["border"],
                highlightcolor=COLORS["border_accent"],
            )
            three_d_entry.pack(side="left", padx=(SPACING["xs"], 0))
            three_d_entry.insert(0, str(job.get("three_dmark_target", 0)))
            three_d_entry.bind("<KeyRelease>", lambda e: self._on_3dmark_target_change(job, three_d_entry))

    # ── Bonus Objectives Section ─────────────────────────────────────

    def _build_bonus_objectives_section(self, job):
        section = tk.Frame(self._detail_inner, bg=COLORS["bg_card"])
        section.pack(fill="x", pady=(0, SPACING["sm"]))

        tk.Label(
            section, text="Bonus Objectives", bg=COLORS["bg_card"],
            fg=COLORS["fg_header"], font=(FONT_FAMILY, self._current_font_size, "bold"),
            anchor="w", padx=SPACING["sm"], pady=SPACING["xs"],
        ).pack(fill="x")

        content = tk.Frame(section, bg=COLORS["bg_card"], padx=SPACING["sm"], pady=SPACING["xs"])
        content.pack(fill="x")

        dust_var = tk.BooleanVar(value=job.get("clean_dust", False))
        DarkCheckbutton(
            content, text="Clean Out Dust", variable=dust_var,
            command=lambda: self._on_detail_toggle(job, "clean_dust", dust_var),
            font_size=self._current_font_size,
        ).pack(anchor="w")

        virus_var = tk.BooleanVar(value=job.get("remove_viruses", False))
        DarkCheckbutton(
            content, text="Remove Viruses", variable=virus_var,
            command=lambda: self._on_detail_toggle(job, "remove_viruses", virus_var),
            font_size=self._current_font_size,
        ).pack(anchor="w")

        if job.get("clean_dust") and job.get("remove_viruses"):
            InfoBox(
                content,
                text="Don't forget to clean out dust and remove viruses!",
                tip_id="",
                state_manager=None,
            ).pack(fill="x", pady=(SPACING["xs"], 0))
        elif job.get("clean_dust"):
            InfoBox(
                content,
                text="Don't forget to clean out dust!",
                tip_id="",
                state_manager=None,
            ).pack(fill="x", pady=(SPACING["xs"], 0))
        elif job.get("remove_viruses"):
            InfoBox(
                content,
                text="Don't forget to remove viruses!",
                tip_id="",
                state_manager=None,
            ).pack(fill="x", pady=(SPACING["xs"], 0))

        cables_var = tk.BooleanVar(value=job.get("new_cables", False))
        DarkCheckbutton(
            content, text="New Cables", variable=cables_var,
            command=lambda: self._on_detail_toggle(job, "new_cables", cables_var),
            font_size=self._current_font_size,
        ).pack(anchor="w")

        if job.get("new_cables"):
            self._build_cable_search(content, job)

        brand_var = tk.BooleanVar(value=job.get("brand_preference", False))
        DarkCheckbutton(
            content, text="Brand Preference", variable=brand_var,
            command=lambda: self._on_detail_toggle(job, "brand_preference", brand_var),
            font_size=self._current_font_size,
        ).pack(anchor="w")

        if job.get("brand_preference"):
            self._build_brand_search(content, job)

    def _build_cable_search(self, parent, job):
        frame = tk.Frame(parent, bg=COLORS["bg_card"], padx=SPACING["lg"])
        frame.pack(fill="x", pady=(SPACING["xs"], 0))

        for cable_name in job.get("cables_list", []):
            row = tk.Frame(frame, bg=COLORS["bg_card"])
            row.pack(fill="x", pady=1)
            tk.Label(
                row, text=cable_name, bg=COLORS["bg_card"],
                fg=COLORS["fg_primary"], font=(FONT_FAMILY, self._current_font_size),
                anchor="w",
            ).pack(side="left", fill="x", expand=True)
            remove_lbl = tk.Label(
                row, text="✕", bg="#f93333", fg=COLORS["fg_primary"],
                font=(FONT_FAMILY, max(self._current_font_size - 1, 8), "bold"),
                padx=6, pady=1, cursor="hand2",
            )
            remove_lbl.pack(side="right")
            remove_lbl.bind("<Button-1>", lambda e, cn=cable_name: self._remove_cable(job, cn))

        search_frame = tk.Frame(frame, bg=COLORS["bg_card"])
        search_frame.pack(fill="x", pady=(SPACING["xs"], 0))

        cable_entry = tk.Entry(
            search_frame, bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
            insertbackground=COLORS["fg_primary"], relief="flat",
            font=(FONT_FAMILY, self._current_font_size), width=30,
            highlightthickness=1, highlightbackground=COLORS["border"],
            highlightcolor=COLORS["border_accent"],
        )
        cable_entry.pack(fill="x")

        cable_listbox = tk.Listbox(
            frame, bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
            font=(FONT_FAMILY, max(self._current_font_size - 1, 8)),
            selectbackground=COLORS["bg_selected"],
            selectforeground=COLORS["fg_primary"],
            highlightthickness=0, bd=0, relief="flat",
            activestyle="none", height=5,
        )
        cable_listbox.pack(fill="x")

        self._cable_results = []

        def on_cable_key(event):
            key = "cable_search"
            if key in self._debounce_ids:
                self.after_cancel(self._debounce_ids[key])
            self._debounce_ids[key] = self.after(SEARCH_DEBOUNCE_MS, lambda: do_cable_search())

        def do_cable_search():
            query = cable_entry.get().strip().lower()
            cable_listbox.delete(0, "end")
            self._cable_results = []
            if not query:
                return
            cables = self._state.catalog.get("Cables", [])
            for c in cables:
                name = c.get("Full Part Name", "")
                if query in name.lower():
                    self._cable_results.append(name)
                    cable_listbox.insert("end", name)
                if len(self._cable_results) >= 50:
                    break

        def on_cable_select(event):
            sel = cable_listbox.curselection()
            if sel and sel[0] < len(self._cable_results):
                cable_name = self._cable_results[sel[0]]
                cables = list(job.get("cables_list", []))
                cables.append(cable_name)
                self._state.update_job(job["id"], cables_list=cables)

        cable_entry.bind("<KeyRelease>", on_cable_key)
        cable_listbox.bind("<Double-Button-1>", on_cable_select)

    def _remove_cable(self, job, cable_name):
        cables = list(job.get("cables_list", []))
        if cable_name in cables:
            cables.remove(cable_name)
        self._state.update_job(job["id"], cables_list=cables)

    def _build_brand_search(self, parent, job):
        frame = tk.Frame(parent, bg=COLORS["bg_card"], padx=SPACING["lg"])
        frame.pack(fill="x", pady=(SPACING["xs"], 0))

        for brand_name in job.get("brand_list", []):
            row = tk.Frame(frame, bg=COLORS["bg_card"])
            row.pack(fill="x", pady=1)
            tk.Label(
                row, text=brand_name, bg=COLORS["bg_card"],
                fg=COLORS["fg_primary"], font=(FONT_FAMILY, self._current_font_size),
                anchor="w",
            ).pack(side="left", fill="x", expand=True)
            remove_lbl = tk.Label(
                row, text="✕", bg="#f93333", fg=COLORS["fg_primary"],
                font=(FONT_FAMILY, max(self._current_font_size - 1, 8), "bold"),
                padx=6, pady=1, cursor="hand2",
            )
            remove_lbl.pack(side="right")
            remove_lbl.bind("<Button-1>", lambda e, bn=brand_name: self._remove_brand(job, bn))

        search_frame = tk.Frame(frame, bg=COLORS["bg_card"])
        search_frame.pack(fill="x", pady=(SPACING["xs"], 0))

        brand_entry = tk.Entry(
            search_frame, bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
            insertbackground=COLORS["fg_primary"], relief="flat",
            font=(FONT_FAMILY, self._current_font_size), width=30,
            highlightthickness=1, highlightbackground=COLORS["border"],
            highlightcolor=COLORS["border_accent"],
        )
        brand_entry.pack(fill="x")

        brand_listbox = tk.Listbox(
            frame, bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
            font=(FONT_FAMILY, max(self._current_font_size - 1, 8)),
            selectbackground=COLORS["bg_selected"],
            selectforeground=COLORS["fg_primary"],
            highlightthickness=0, bd=0, relief="flat",
            activestyle="none", height=5,
        )
        brand_listbox.pack(fill="x")

        self._brand_results = []

        def on_brand_key(event):
            key = "brand_search"
            if key in self._debounce_ids:
                self.after_cancel(self._debounce_ids[key])
            self._debounce_ids[key] = self.after(SEARCH_DEBOUNCE_MS, lambda: do_brand_search())

        def do_brand_search():
            query = brand_entry.get().strip().lower()
            brand_listbox.delete(0, "end")
            self._brand_results = []
            if not query:
                return
            seen = set()
            catalog = self._state.catalog
            for cat, parts in catalog.items():
                if cat == "Cables":
                    continue
                for part in parts:
                    mfr = part.get("Manufacturer", "").strip()
                    if mfr and query in mfr.lower() and mfr not in seen:
                        seen.add(mfr)
                        self._brand_results.append(mfr)
                        brand_listbox.insert("end", mfr)
                    if len(self._brand_results) >= 50:
                        break
                if len(self._brand_results) >= 50:
                    break

        def on_brand_select(event):
            sel = brand_listbox.curselection()
            if sel and sel[0] < len(self._brand_results):
                brand_name = self._brand_results[sel[0]]
                brands = list(job.get("brand_list", []))
                if brand_name not in brands:
                    brands.append(brand_name)
                self._state.update_job(job["id"], brand_list=brands)

        brand_entry.bind("<KeyRelease>", on_brand_key)
        brand_listbox.bind("<Double-Button-1>", on_brand_select)

    def _remove_brand(self, job, brand_name):
        brands = list(job.get("brand_list", []))
        if brand_name in brands:
            brands.remove(brand_name)
        self._state.update_job(job["id"], brand_list=brands)

    # ── Job Build Section ────────────────────────────────────────────

    def _build_job_build_section(self, job):
        section = tk.Frame(self._detail_inner, bg=COLORS["bg_card"])
        section.pack(fill="x", pady=(0, SPACING["sm"]))

        tk.Label(
            section, text="Job Build", bg=COLORS["bg_card"],
            fg=COLORS["fg_header"], font=(FONT_FAMILY, self._current_font_size, "bold"),
            anchor="w", padx=SPACING["sm"], pady=SPACING["xs"],
        ).pack(fill="x")

        content = tk.Frame(section, bg=COLORS["bg_card"], padx=SPACING["sm"], pady=SPACING["xs"])
        content.pack(fill="x")

        if not job.get("new_pc_build") and not job.get("replace_upgrade"):
            tk.Label(
                content, text="Select Job Details above to populate the build area.",
                bg=COLORS["bg_card"], fg=COLORS["fg_muted"],
                font=(FONT_FAMILY, self._current_font_size),
            ).pack(anchor="w", pady=SPACING["sm"])
            return

        if job.get("new_pc_build"):
            self._build_new_pc_build_slots(content, job)

        if job.get("replace_upgrade"):
            self._build_replace_upgrade_section(content, job)

    def _build_new_pc_build_slots(self, parent, job):
        tk.Label(
            parent, text="New PC Build", bg=COLORS["bg_card"],
            fg=COLORS["fg_accent"], font=(FONT_FAMILY, self._current_font_size, "bold"),
            anchor="w",
        ).pack(fill="x", pady=(0, SPACING["xs"]))

        build_parts = self._state.get_job_build_parts(job["id"], "build_slots")

        compat_slots = {}
        for cat in JOB_SLOT_ORDER:
            slots = build_parts.get(cat, [])
            resolved = []
            for sp in slots:
                if sp is not None:
                    if isinstance(sp, dict) and "data" in sp:
                        resolved.append(sp["data"])
                    elif isinstance(sp, dict):
                        resolved.append(sp)
                    else:
                        resolved.append(None)
                else:
                    resolved.append(None)
            compat_slots[cat] = resolved

        warnings = check_compatibility(compat_slots)
        if warnings:
            warn_frame = tk.Frame(parent, bg=COLORS["bg_warning"])
            warn_frame.pack(fill="x", pady=(0, SPACING["xs"]))
            tk.Label(
                warn_frame, text="⚠ WARNING! Selected parts are not compatible!",
                bg=COLORS["bg_warning"], fg=COLORS["fg_warning"],
                font=(FONT_FAMILY, self._current_font_size, "bold"),
                anchor="w", padx=SPACING["sm"], pady=SPACING["xs"],
            ).pack(fill="x")
            for w in warnings:
                tk.Label(
                    warn_frame, text=f"  • {w}",
                    bg=COLORS["bg_warning"], fg=COLORS["fg_warning"],
                    font=(FONT_FAMILY, max(self._current_font_size - 1, 8)),
                    anchor="w", padx=SPACING["sm"], wraplength=1400, justify="left",
                ).pack(fill="x")

        for cat in JOB_SLOT_ORDER:
            max_slots = JOB_SLOTS.get(cat, 1)
            slots = build_parts.get(cat, [None] * max_slots)

            cat_frame = tk.Frame(parent, bg=COLORS["bg_card"])
            cat_frame.pack(fill="x", pady=(0, 2))

            tk.Label(
                cat_frame, text=f"{cat}  ({max_slots} slot{'s' if max_slots > 1 else ''})",
                bg=COLORS["bg_card"], fg=COLORS["fg_header"],
                font=(FONT_FAMILY, self._current_font_size, "bold"),
                anchor="w",
            ).pack(fill="x")

            for i in range(max_slots):
                slot_part = slots[i] if i < len(slots) else None
                slot_frame = tk.Frame(cat_frame, bg=COLORS["bg_card"])
                slot_frame.pack(fill="x", padx=SPACING["sm"], pady=(0, 2))

                if slot_part is not None:
                    part_data = slot_part.get("data", {}) if isinstance(slot_part, dict) else {}
                    part_name = part_data.get("Full Part Name", "Unknown")
                    instance_id = slot_part.get("instance_id", "") if isinstance(slot_part, dict) else ""

                    name_label = tk.Label(
                        slot_frame, text=f"Slot {i + 1}: {part_name}",
                        bg=COLORS["bg_card"], fg=COLORS["fg_primary"],
                        font=(FONT_FAMILY, self._current_font_size),
                        anchor="w", cursor="hand2",
                    )
                    name_label.pack(side="left", fill="x", expand=True)
                    name_label.bind("<Double-Button-1>", lambda e, n=part_name: self._copy_name(n))

                    remove_btn = tk.Label(
                        slot_frame, text="✕",
                        bg="#f93333", fg=COLORS["fg_primary"],
                        font=(FONT_FAMILY, max(self._current_font_size - 1, 8), "bold"),
                        padx=6, pady=1, cursor="hand2",
                    )
                    remove_btn.pack(side="right", padx=(SPACING["xs"], 0))
                    remove_btn.bind(
                        "<Button-1>",
                        lambda e, jid=job["id"], iid=instance_id: self._state.remove_part_from_job(jid, iid, "build_slots"),
                    )
                else:
                    tk.Label(
                        slot_frame, text=f"Slot {i + 1}: [EMPTY]",
                        bg=COLORS["bg_card"], fg=COLORS["fg_muted"],
                        font=(FONT_FAMILY, self._current_font_size),
                        anchor="w",
                    ).pack(side="left", fill="x", expand=True)

    def _build_replace_upgrade_section(self, parent, job):
        tk.Label(
            parent, text="Replace / Upgrade Parts", bg=COLORS["bg_card"],
            fg=COLORS["fg_accent"], font=(FONT_FAMILY, self._current_font_size, "bold"),
            anchor="w",
        ).pack(fill="x", pady=(SPACING["xs"], SPACING["xs"]))

        tab_bar = tk.Frame(parent, bg=COLORS["bg_dark"])
        tab_bar.pack(fill="x")

        self._replace_tab = tk.StringVar(value="customer")

        cust_btn = tk.Label(
            tab_bar, text="Customer Original Parts",
            bg=COLORS["bg_tab_active"], fg=COLORS["fg_button"],
            font=(FONT_FAMILY, max(self._current_font_size - 1, 8)),
            padx=SPACING["sm"], pady=SPACING["xs"], cursor="hand2",
        )
        cust_btn.pack(side="left", padx=(0, 2))

        player_btn = tk.Label(
            tab_bar, text="Player Chosen Parts",
            bg=COLORS["bg_dark"], fg=COLORS["fg_muted"],
            font=(FONT_FAMILY, max(self._current_font_size - 1, 8)),
            padx=SPACING["sm"], pady=SPACING["xs"], cursor="hand2",
        )
        player_btn.pack(side="left")

        customer_frame = tk.Frame(parent, bg=COLORS["bg_card"])
        player_frame = tk.Frame(parent, bg=COLORS["bg_card"])

        def show_customer():
            self._replace_tab.set("customer")
            player_frame.pack_forget()
            customer_frame.pack(fill="x")
            cust_btn.configure(bg=COLORS["bg_tab_active"], fg=COLORS["fg_button"])
            player_btn.configure(bg=COLORS["bg_dark"], fg=COLORS["fg_muted"])

        def show_player():
            self._replace_tab.set("player")
            customer_frame.pack_forget()
            player_frame.pack(fill="x")
            player_btn.configure(bg=COLORS["bg_tab_active"], fg=COLORS["fg_button"])
            cust_btn.configure(bg=COLORS["bg_dark"], fg=COLORS["fg_muted"])

        cust_btn.bind("<Button-1>", lambda e: show_customer())
        player_btn.bind("<Button-1>", lambda e: show_player())

        self._build_customer_original_slots(customer_frame, job)
        self._build_player_chosen_slots(player_frame, job)

        customer_frame.pack(fill="x")

    def _build_customer_original_slots(self, parent, job):
        """Build customer original parts section with single search panel (like Parts Tab) and simple list display (like build menu)."""
        
        # --- Search Panel (like Parts Tab) ---
        search_frame = tk.Frame(parent, bg=COLORS["bg_card"], padx=SPACING["sm"], pady=SPACING["sm"])
        search_frame.pack(fill="x", pady=(0, SPACING["xs"]))

        left = tk.Frame(search_frame, bg=COLORS["bg_card"])
        left.pack(side="left", fill="x", expand=True)

        tk.Label(
            left, text="Search Parts:", bg=COLORS["bg_card"],
            fg=COLORS["fg_secondary"], font=(FONT_FAMILY, max(self._current_font_size - 1, 8)),
            anchor="w",
        ).pack(fill="x")

        search_entry = tk.Entry(
            left, bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
            insertbackground=COLORS["fg_primary"], relief="flat",
            font=(FONT_FAMILY, self._current_font_size),
            highlightthickness=1, highlightbackground=COLORS["border"],
            highlightcolor=COLORS["border_accent"],
        )
        search_entry.pack(fill="x", pady=(2, 0))

        right = tk.Frame(search_frame, bg=COLORS["bg_card"], height=200)
        right.pack(side="right", fill="both", padx=(SPACING["sm"], 0), expand=True)
        right.pack_propagate(False)

        tk.Label(
            right, text="Recommendations (double-click to add):",
            bg=COLORS["bg_card"], fg=COLORS["fg_secondary"],
            font=(FONT_FAMILY, max(self._current_font_size - 1, 8)), anchor="w",
        ).pack(fill="x")

        list_frame = tk.Frame(right, bg=COLORS["bg_input"], highlightthickness=1,
                              highlightbackground=COLORS["border"])
        list_frame.pack(fill="both", expand=True, pady=(2, 0))

        results_listbox = tk.Listbox(
            list_frame, bg=COLORS["bg_input"], fg=COLORS["fg_primary"],
            font=(FONT_FAMILY, max(self._current_font_size - 1, 8)),
            selectbackground=COLORS["bg_selected"],
            selectforeground=COLORS["fg_primary"],
            highlightthickness=0, bd=0, relief="flat",
            activestyle="none",
        )
        scrollbar = tk.Scrollbar(list_frame, orient="vertical", command=results_listbox.yview)
        results_listbox.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        results_listbox.pack(side="left", fill="both", expand=True)

        self._search_results = []

        def do_search():
            query = search_entry.get().strip()
            results_listbox.delete(0, "end")
            self._search_results.clear()
            if not query:
                return
            keywords = query.lower().split()
            catalog = self._state.catalog
            matches = []
            for category, parts in catalog.items():
                for part in parts:
                    name = part.get("Full Part Name", "").lower()
                    if all(kw in name for kw in keywords):
                        matches.append((category, part))
            matches.sort(key=lambda x: x[1].get("Full Part Name", "").lower())
            matches = matches[:200]
            self._search_results = matches
            for category, part in matches:
                display = f"[{category}] {part.get('Full Part Name', '?')}"
                results_listbox.insert("end", display)

        def on_search_key(event):
            key = "cust_search"
            if key in self._debounce_ids:
                self.after_cancel(self._debounce_ids[key])
            self._debounce_ids[key] = self.after(SEARCH_DEBOUNCE_MS, do_search)

        def on_search_select(event):
            selection = results_listbox.curselection()
            if not selection:
                return
            idx = selection[0]
            if idx < len(self._search_results):
                category, part = self._search_results[idx]
                part_dict = dict(part.data) if hasattr(part, "data") else dict(part)
                # Find first empty slot in this category
                max_slots = JOB_SLOTS.get(category, 1)
                customer_slots = job.get("customer_slots", {}).get(category, [None] * max_slots)
                for slot_idx in range(max_slots):
                    if slot_idx >= len(customer_slots) or customer_slots[slot_idx] is None:
                        self._state.set_job_customer_slot(job["id"], category, slot_idx, part_dict)
                        return
                # No empty slots
                self._show_popup("Add Part", f"No empty slots available for {category}")

        search_entry.bind("<KeyRelease>", on_search_key)
        results_listbox.bind("<Double-Button-1>", on_search_select)

        # --- Selected Parts List (like build menu slots) ---
        tk.Label(
            parent, text="Customer's Original Parts:",
            bg=COLORS["bg_card"], fg=COLORS["fg_header"],
            font=(FONT_FAMILY, self._current_font_size, "bold"),
            anchor="w", padx=SPACING["sm"],
        ).pack(fill="x", pady=(SPACING["xs"], 0))

        for cat in JOB_SLOT_ORDER:
            max_slots = JOB_SLOTS.get(cat, 1)
            customer_slots = job.get("customer_slots", {}).get(cat, [None] * max_slots)

            cat_frame = tk.Frame(parent, bg=COLORS["bg_card"])
            cat_frame.pack(fill="x", pady=(0, SPACING["xs"]))

            tk.Label(
                cat_frame, text=f"{cat}  ({max_slots} slot{'s' if max_slots > 1 else ''})",
                bg=COLORS["bg_card"], fg=COLORS["fg_header"],
                font=(FONT_FAMILY, self._current_font_size, "bold"),
                anchor="w", padx=SPACING["sm"], pady=SPACING["xs"],
            ).pack(fill="x")

            for i in range(max_slots):
                slot_data = customer_slots[i] if i < len(customer_slots) else None
                slot_frame = tk.Frame(cat_frame, bg=COLORS["bg_card"])
                slot_frame.pack(fill="x", padx=SPACING["sm"], pady=(0, 2))

                if slot_data is not None:
                    part_name = slot_data.get("Full Part Name", "Unknown") if isinstance(slot_data, dict) else str(slot_data)
                    name_label = tk.Label(
                        slot_frame, text=f"Slot {i + 1}: {part_name}",
                        bg=COLORS["bg_card"], fg=COLORS["fg_primary"],
                        font=(FONT_FAMILY, self._current_font_size),
                        anchor="w", cursor="hand2",
                    )
                    name_label.pack(side="left", fill="x", expand=True)
                    name_label.bind("<Double-Button-1>", lambda e, n=part_name: self._copy_name(n))

                    remove_btn = tk.Label(
                        slot_frame, text="✕",
                        bg="#f93333", fg=COLORS["fg_primary"],
                        font=(FONT_FAMILY, max(self._current_font_size - 1, 8), "bold"),
                        padx=6, pady=1, cursor="hand2",
                    )
                    remove_btn.pack(side="right", padx=(SPACING["xs"], 0))
                    remove_btn.bind(
                        "<Button-1>",
                        lambda e, jid=job["id"], c=cat, si=i: self._state.clear_job_customer_slot(jid, c, si),
                    )
                else:
                    tk.Label(
                        slot_frame, text=f"Slot {i + 1}: [EMPTY]",
                        bg=COLORS["bg_card"], fg=COLORS["fg_muted"],
                        font=(FONT_FAMILY, self._current_font_size),
                        anchor="w",
                    ).pack(side="left", fill="x", expand=True)

    def _build_player_chosen_slots(self, parent, job):
        unlocked = _get_unlocked_categories(
            job.get("replace_parts_checked", {}),
            job.get("three_dmark_check", False),
        )

        player_parts = self._state.get_job_build_parts(job["id"], "player_slots")
        customer_parts_raw = job.get("customer_slots", {})

        compat_slots = {}
        for cat in JOB_SLOT_ORDER:
            slots = player_parts.get(cat, [])
            resolved = []
            for sp in slots:
                if sp is not None:
                    if isinstance(sp, dict) and "data" in sp:
                        resolved.append(sp["data"])
                    elif isinstance(sp, dict):
                        resolved.append(sp)
                    else:
                        resolved.append(None)
                else:
                    cust_slots = customer_parts_raw.get(cat, [])
                    if cat not in unlocked and cust_slots:
                        idx = len(resolved)
                        if idx < len(cust_slots) and cust_slots[idx] is not None:
                            resolved.append(cust_slots[idx] if isinstance(cust_slots[idx], dict) else None)
                        else:
                            resolved.append(None)
                    else:
                        resolved.append(None)
            compat_slots[cat] = resolved

        warnings = check_compatibility(compat_slots)
        if warnings:
            warn_frame = tk.Frame(parent, bg=COLORS["bg_warning"])
            warn_frame.pack(fill="x", pady=(0, SPACING["xs"]))
            tk.Label(
                warn_frame, text="⚠ WARNING! Selected parts are not compatible!",
                bg=COLORS["bg_warning"], fg=COLORS["fg_warning"],
                font=(FONT_FAMILY, self._current_font_size, "bold"),
                anchor="w", padx=SPACING["sm"], pady=SPACING["xs"],
            ).pack(fill="x")
            for w in warnings:
                tk.Label(
                    warn_frame, text=f"  • {w}",
                    bg=COLORS["bg_warning"], fg=COLORS["fg_warning"],
                    font=(FONT_FAMILY, max(self._current_font_size - 1, 8)),
                    anchor="w", padx=SPACING["sm"], wraplength=1400, justify="left",
                ).pack(fill="x")

        if job.get("three_dmark_check"):
            cpu_data = None
            gpu_parts = []
            ram_parts = []
            for cat in JOB_SLOT_ORDER:
                slots_resolved = compat_slots.get(cat, [])
                for p in slots_resolved:
                    if p is not None:
                        if cat == "CPU":
                            cpu_data = p
                        elif cat == "GPU":
                            gpu_parts.append(p)
                        elif cat == "RAM":
                            ram_parts.append(p)
            score = calculate_3dmark(cpu_data, gpu_parts, ram_parts)
            score_frame = tk.Frame(parent, bg=COLORS["bg_card"])
            score_frame.pack(fill="x", pady=(0, SPACING["xs"]))
            tk.Label(
                score_frame, text=f"3DMark Score: {score:,}",
                bg=COLORS["bg_card"], fg=COLORS["fg_accent"],
                font=(FONT_FAMILY, self._current_font_size + 2, "bold"),
                padx=SPACING["sm"],
            ).pack(anchor="w")

        inferior_warnings = []

        for cat in JOB_SLOT_ORDER:
            max_slots = JOB_SLOTS.get(cat, 1)
            p_slots = player_parts.get(cat, [None] * max_slots)
            cust_slots = customer_parts_raw.get(cat, [None] * max_slots)
            is_locked = cat not in unlocked and cat != "Case"
            is_case = cat == "Case"

            cat_frame = tk.Frame(parent, bg=COLORS["bg_card"])
            cat_frame.pack(fill="x", pady=(0, 2))

            tk.Label(
                cat_frame, text=f"{cat}  ({max_slots} slot{'s' if max_slots > 1 else ''})",
                bg=COLORS["bg_card"], fg=COLORS["fg_header"],
                font=(FONT_FAMILY, self._current_font_size, "bold"),
                anchor="w", padx=SPACING["sm"],
            ).pack(fill="x")

            for i in range(max_slots):
                slot_frame = tk.Frame(cat_frame, bg=COLORS["bg_card"])
                slot_frame.pack(fill="x", padx=SPACING["sm"], pady=(0, 2))

                if is_case or is_locked:
                    cust_data = cust_slots[i] if i < len(cust_slots) else None
                    if cust_data is not None:
                        cust_name = cust_data.get("Full Part Name", "Unknown") if isinstance(cust_data, dict) else str(cust_data)
                        locked_label = tk.Label(
                            slot_frame, bg=COLORS["bg_card"],
                            font=(FONT_FAMILY, self._current_font_size),
                            anchor="w",
                        )
                        locked_label.pack(side="left", fill="x", expand=True)
                        locked_label.configure(text=f"Slot {i + 1}: [LOCKED] {cust_name}")
                        locked_label.configure(fg="#f93333")
                        locked_label.bind("<Double-Button-1>", lambda e, n=cust_name: self._copy_name(n))
                    else:
                        tk.Label(
                            slot_frame, text=f"Slot {i + 1}: [LOCKED] [EMPTY]",
                            bg=COLORS["bg_card"], fg="#f93333",
                            font=(FONT_FAMILY, self._current_font_size),
                            anchor="w",
                        ).pack(side="left", fill="x", expand=True)
                else:
                    slot_part = p_slots[i] if i < len(p_slots) else None

                    if slot_part is not None:
                        if isinstance(slot_part, dict) and slot_part.get("locked"):
                            cust_data = cust_slots[i] if i < len(cust_slots) else None
                            cust_name = cust_data.get("Full Part Name", "Unknown") if isinstance(cust_data, dict) and cust_data else "Unknown"
                            locked_label = tk.Label(
                                slot_frame, text=f"Slot {i + 1}: [LOCKED] {cust_name}",
                                bg=COLORS["bg_card"], fg="#f93333",
                                font=(FONT_FAMILY, self._current_font_size),
                                anchor="w",
                            )
                            locked_label.pack(side="left", fill="x", expand=True)
                        elif isinstance(slot_part, dict) and slot_part.get("original"):
                            cust_data = cust_slots[i] if i < len(cust_slots) else None
                            cust_name = cust_data.get("Full Part Name", "Unknown") if isinstance(cust_data, dict) and cust_data else "Unknown"
                            orig_label = tk.Label(
                                slot_frame, text=f"Slot {i + 1}: [ORIGINAL] {cust_name}",
                                bg=COLORS["bg_card"], fg="#33D1F9",
                                font=(FONT_FAMILY, self._current_font_size),
                                anchor="w",
                            )
                            orig_label.pack(side="left", fill="x", expand=True)
                        else:
                            part_data = slot_part.get("data", {}) if isinstance(slot_part, dict) else {}
                            part_name = part_data.get("Full Part Name", "Unknown")
                            instance_id = slot_part.get("instance_id", "") if isinstance(slot_part, dict) else ""

                            prefix = ""
                            prefix_color = COLORS["fg_primary"]
                            if isinstance(slot_part, dict) and slot_part.get("purchase"):
                                prefix = "[PURCHASE] "
                                prefix_color = "#f9aa33"
                            elif isinstance(slot_part, dict) and slot_part.get("inventory"):
                                prefix = "[INVENTORY] "
                                prefix_color = "#33f95d"

                            name_label = tk.Label(
                                slot_frame,
                                bg=COLORS["bg_card"],
                                font=(FONT_FAMILY, self._current_font_size),
                                anchor="w", cursor="hand2",
                            )
                            name_label.configure(text=f"Slot {i + 1}: {prefix}{part_name}", fg=prefix_color if prefix else COLORS["fg_primary"])
                            name_label.pack(side="left", fill="x", expand=True)
                            name_label.bind("<Double-Button-1>", lambda e, n=part_name: self._copy_name(n))

                            cust_data = cust_slots[i] if i < len(cust_slots) else None
                            if cust_data and isinstance(cust_data, dict) and cat != "Case":
                                if _is_inferior(cust_data, part_data, cat):
                                    inferior_warnings.append(f"{cat} Slot {i+1}: '{part_name}' is inferior to the customer's original part")

                            remove_btn = tk.Label(
                                slot_frame, text="✕",
                                bg="#f93333", fg=COLORS["fg_primary"],
                                font=(FONT_FAMILY, max(self._current_font_size - 1, 8), "bold"),
                                padx=6, pady=1, cursor="hand2",
                            )
                            remove_btn.pack(side="right", padx=(SPACING["xs"], 0))
                            remove_btn.bind(
                                "<Button-1>",
                                lambda e, jid=job["id"], iid=instance_id: self._state.remove_part_from_job(jid, iid, "player_slots"),
                            )
                    else:
                        tk.Label(
                            slot_frame, text=f"Slot {i + 1}: [EMPTY]",
                            bg=COLORS["bg_card"], fg=COLORS["fg_muted"],
                            font=(FONT_FAMILY, self._current_font_size),
                            anchor="w",
                        ).pack(side="left", fill="x", expand=True)

        if inferior_warnings:
            inf_frame = tk.Frame(parent, bg=COLORS["bg_warning"])
            inf_frame.pack(fill="x", pady=(SPACING["xs"], 0))
            tk.Label(
                inf_frame, text="⚠ WARNING! Some replacement parts are inferior!",
                bg=COLORS["bg_warning"], fg=COLORS["fg_warning"],
                font=(FONT_FAMILY, self._current_font_size, "bold"),
                anchor="w", padx=SPACING["sm"], pady=SPACING["xs"],
            ).pack(fill="x")
            for w in inferior_warnings:
                tk.Label(
                    inf_frame, text=f"  • {w}",
                    bg=COLORS["bg_warning"], fg=COLORS["fg_warning"],
                    font=(FONT_FAMILY, max(self._current_font_size - 1, 8)),
                    anchor="w", padx=SPACING["sm"], wraplength=1400, justify="left",
                ).pack(fill="x")

    # ── Auto Build Section ───────────────────────────────────────────

    def _build_auto_build_section(self, job):
        """Build Auto Build section just above Job Build section."""
        section = tk.Frame(self._detail_inner, bg=COLORS["bg_card"])
        section.pack(fill="x", pady=(0, SPACING["sm"]))

        tk.Label(
            section, text="Auto Build",
            bg=COLORS["bg_card"], fg=COLORS["fg_header"],
            font=(FONT_FAMILY, self._current_font_size, "bold"),
            anchor="w", padx=SPACING["sm"], pady=SPACING["xs"],
        ).pack(fill="x")

        content = tk.Frame(section, bg=COLORS["bg_card"], padx=SPACING["sm"], pady=SPACING["xs"])
        content.pack(fill="x")

        tk.Label(
            content,
            text="Automatically select best parts based on job requirements, level, and budget.",
            bg=COLORS["bg_card"], fg=COLORS["fg_secondary"],
            font=(FONT_FAMILY, max(self._current_font_size - 1, 8)),
            anchor="w", wraplength=1400, justify="left",
        ).pack(fill="x", pady=(0, SPACING["xs"]))

        btn_frame = tk.Frame(content, bg=COLORS["bg_card"])
        btn_frame.pack(anchor="w")

        if job.get("new_pc_build"):
            auto_btn = FlatButton(
                btn_frame, text="Run Auto Build (New PC)", command=lambda: self._on_auto_build_new_pc(job),
                bg=COLORS["bg_button"], hover_bg=COLORS["bg_button_hover"],
                font_size=self._current_font_size,
            )
            auto_btn.pack(side="left", padx=(0, SPACING["xs"]))

        if job.get("replace_upgrade"):
            auto_btn = FlatButton(
                btn_frame, text="Run Auto Build (Replace/Upgrade)", command=lambda: self._on_auto_build(job),
                bg=COLORS["bg_button"], hover_bg=COLORS["bg_button_hover"],
                font_size=self._current_font_size,
            )
            auto_btn.pack(side="left")

    # ── Auto Build ───────────────────────────────────────────────────

    def _on_auto_build(self, job):
        if not job.get("replace_upgrade"):
            self._show_popup("Auto Build", "Auto Build requires Replace / Upgrade Parts to be checked under Job Details.")
            return

        replace_checked = job.get("replace_parts_checked", {})
        unlocked = _get_unlocked_categories(replace_checked, job.get("three_dmark_check", False))
        required, optional = _get_required_optional(replace_checked)

        if not unlocked:
            self._show_popup("Auto Build", "No part types are unlocked. Check parts under Replace / Upgrade in Job Details.")
            return

        level = _safe_int(job.get("level", 1), 1)
        progress = _safe_int(job.get("progress", 0), 0)
        budget = _safe_float(job.get("budget", 0))
        actual_budget = budget * 1.1
        is_story = job.get("story_job", False)

        customer_parts_raw = job.get("customer_slots", {})
        aio_required = job.get("aio_cooling_required", False)

        catalog = self._state.catalog
        hem_enabled = self._state.get_setting("hem_enabled", False)

        priority_order = self._state.get_setting("part_priority", DEFAULT_PART_PRIORITY)

        brand_pref = job.get("brand_preference", False)
        brand_list = [b.strip().lower() for b in job.get("brand_list", [])] if brand_pref else []

        chosen = {}
        locked_parts = {}

        # Count how many slots the client originally has for each category
        client_original_slots = {}
        for cat in JOB_SLOT_ORDER:
            cust_slots = customer_parts_raw.get(cat, [])
            # Count non-None slots (client's original parts)
            client_original_slots[cat] = sum(1 for s in cust_slots if s is not None)

        for cat in JOB_SLOT_ORDER:
            if cat not in unlocked or cat == "Case":
                cust_slots = customer_parts_raw.get(cat, [])
                max_s = JOB_SLOTS.get(cat, 1)
                locked_parts[cat] = []
                for i in range(max_s):
                    if i < len(cust_slots) and cust_slots[i] is not None:
                        locked_parts[cat].append(cust_slots[i])
                    else:
                        locked_parts[cat].append(None)

        all_chosen_so_far = {}
        first_gpu_multi_type = None  # Track multi-GPU type for dual GPU builds
        first_ram_size = None  # Track first RAM size for matching
        first_ram_freq = None  # Track first RAM frequency for matching

        # Determine how many slots to fill initially
        # For GPU/RAM: start with 1 unless client had more
        # For Storage: match client's original count
        initial_slots_to_fill = {}
        for cat in JOB_SLOT_ORDER:
            if cat not in unlocked or cat == "Case":
                initial_slots_to_fill[cat] = 0
            elif cat == "GPU":
                # Start with 1 GPU, unless client had 2
                initial_slots_to_fill[cat] = max(1, min(client_original_slots.get(cat, 0), 1)) if client_original_slots.get(cat, 0) > 0 else 1
            elif cat == "RAM":
                # Start with 1 RAM, unless client had more
                initial_slots_to_fill[cat] = max(1, min(client_original_slots.get(cat, 0), 1)) if client_original_slots.get(cat, 0) > 0 else 1
            elif cat == "Storage":
                # Only replace same number of storage slots client had
                initial_slots_to_fill[cat] = client_original_slots.get(cat, 0)
            else:
                # Other categories: fill all available slots
                max_s = JOB_SLOTS.get(cat, 1)
                initial_slots_to_fill[cat] = max_s

        for cat in JOB_SLOT_ORDER:
            if cat not in unlocked or cat == "Case":
                continue

            max_s = JOB_SLOTS.get(cat, 1)
            cust_slots = customer_parts_raw.get(cat, [None] * max_s)
            best_parts = []

            # Only fill the initially determined number of slots
            slots_to_fill = initial_slots_to_fill.get(cat, max_s)

            for slot_idx in range(max_s):
                # Skip slots beyond what we initially want to fill
                if slot_idx >= slots_to_fill:
                    best_parts.append(None)
                    continue

                cust_data = cust_slots[slot_idx] if slot_idx < len(cust_slots) else None

                candidates = list(catalog.get(cat, []))

                valid = []
                for part in candidates:
                    p_data = part.data if hasattr(part, "data") else part

                    part_level = _safe_int(p_data.get("Level", 0))
                    part_pct = _safe_float(p_data.get("Level %", 0))

                    if part_level > level:
                        continue
                    if part_level == level and part_pct > progress:
                        continue

                    # AIO filter: only pick Liquid Cooler for CPU Cooler when required
                    if cat == "CPU Cooler" and aio_required:
                        cooler_type = str(p_data.get("Type", "")).strip()
                        if cooler_type != "Liquid Cooler":
                            continue

                    if cust_data and isinstance(cust_data, dict):
                        if _is_inferior(cust_data, p_data, cat):
                            continue

                    # Multi-GPU compatibility check for second GPU slot
                    if cat == "GPU" and slot_idx == 1 and first_gpu_multi_type:
                        gpu_multi = p_data.get("Multi-GPU", "").strip()
                        # Second GPU must have same multi-GPU type as first
                        if gpu_multi != first_gpu_multi_type:
                            continue
                        # Motherboard must support this multi-GPU type
                        mobo_part = None
                        for mp in all_chosen_so_far.get("Motherboard", []):
                            if mp is not None:
                                mobo_part = mp
                                break
                        if mobo_part:
                            if first_gpu_multi_type == "SLI":
                                mobo_sli = mobo_part.get("Support SLI", "").strip().upper()
                                if mobo_sli != "Y":
                                    continue
                            elif first_gpu_multi_type == "CrossFire":
                                mobo_cf = mobo_part.get("Support CrossFire", "").strip().upper()
                                if mobo_cf != "Y":
                                    continue

                    # RAM matching check for additional RAM slots
                    if cat == "RAM" and slot_idx >= 1 and (first_ram_size is not None or first_ram_freq is not None):
                        ram_size = _safe_int(p_data.get("Size (GB)", 0))
                        ram_freq = _safe_int(p_data.get("Frequency", 0))
                        if first_ram_size is not None and ram_size != first_ram_size:
                            continue
                        if first_ram_freq is not None and ram_freq != first_ram_freq:
                            continue

                    valid.append(p_data)

                if not valid:
                    best_parts.append(None)
                    continue

                final_candidates = []
                for v in valid:
                    test_slots = dict(all_chosen_so_far)
                    if cat not in test_slots:
                        test_slots[cat] = []
                    test_entry = list(test_slots[cat])
                    test_entry.append(v)
                    test_slots[cat] = test_entry

                    for lcat, lslots in locked_parts.items():
                        if lcat not in test_slots:
                            test_slots[lcat] = []
                        for lp in lslots:
                            if lp is not None:
                                test_slots[lcat] = list(test_slots[lcat]) + [lp if isinstance(lp, dict) else None]

                    compat_check = {}
                    for check_cat in JOB_SLOT_ORDER:
                        compat_check[check_cat] = test_slots.get(check_cat, [None])

                    warns = check_compatibility(compat_check)
                    if not warns:
                        final_candidates.append(v)

                if not final_candidates:
                    final_candidates = valid

                if brand_list:
                    final_candidates.sort(key=lambda p: (
                        0 if p.get("Manufacturer", "").strip().lower() in brand_list else 1,
                        _safe_float(p.get("Price", 99999)),
                    ))
                else:
                    final_candidates.sort(key=lambda p: _safe_float(p.get("Price", 99999)))
                best = final_candidates[0] if final_candidates else None
                best_parts.append(best)

                if best:
                    if cat not in all_chosen_so_far:
                        all_chosen_so_far[cat] = []
                    all_chosen_so_far[cat].append(best)
                    # Track multi-GPU type for first GPU selected
                    if cat == "GPU" and slot_idx == 0:
                        first_gpu_multi_type = best.get("Multi-GPU", "").strip()
                    # Track first RAM size and frequency for matching
                    if cat == "RAM" and slot_idx == 0:
                        first_ram_size = _safe_int(best.get("Size (GB)", 0))
                        first_ram_freq = _safe_int(best.get("Frequency", 0))

            chosen[cat] = best_parts

        if job.get("three_dmark_check"):
            target_score = _safe_int(job.get("three_dmark_target", 0))
            if target_score > 0:
                all_parts_for_score = {}
                for cat in JOB_SLOT_ORDER:
                    all_parts_for_score[cat] = []
                    if cat in chosen:
                        for p in chosen[cat]:
                            if p is not None:
                                all_parts_for_score[cat].append(p)
                    if cat in locked_parts:
                        for lp in locked_parts[cat]:
                            if lp is not None and isinstance(lp, dict):
                                all_parts_for_score[cat].append(lp)

                cpu_data = all_parts_for_score.get("CPU", [None])[0] if all_parts_for_score.get("CPU") else None
                gpu_parts = all_parts_for_score.get("GPU", [])
                ram_parts = all_parts_for_score.get("RAM", [])
                score = calculate_3dmark(cpu_data, gpu_parts, ram_parts)

                if score < target_score:
                    log.warning(f"Auto build 3DMark score {score} < target {target_score}. Trying higher-priced parts and additional slots.")
                    
                    # First, try upgrading parts in existing slots
                    for cat in ["GPU", "CPU", "RAM"]:
                        if cat not in unlocked:
                            continue
                        max_s = JOB_SLOTS.get(cat, 1)
                        cust_slots = customer_parts_raw.get(cat, [None] * max_s)
                        for slot_idx in range(max_s):
                            # Skip empty slots
                            if slot_idx >= len(chosen.get(cat, [])) or chosen[cat][slot_idx] is None:
                                continue
                            cust_data = cust_slots[slot_idx] if slot_idx < len(cust_slots) else None
                            candidates = list(catalog.get(cat, []))
                            valid = []
                            for part in candidates:
                                p_data = part.data if hasattr(part, "data") else part
                                part_level = _safe_int(p_data.get("Level", 0))
                                part_pct = _safe_float(p_data.get("Level %", 0))
                                if part_level > level:
                                    continue
                                if part_level == level and part_pct > progress:
                                    continue
                                if cust_data and isinstance(cust_data, dict):
                                    if _is_inferior(cust_data, p_data, cat):
                                        continue
                                # Multi-GPU check for second GPU
                                if cat == "GPU" and slot_idx == 1 and first_gpu_multi_type:
                                    gpu_multi = p_data.get("Multi-GPU", "").strip()
                                    if gpu_multi != first_gpu_multi_type:
                                        continue
                                    mobo_part = None
                                    for mp in all_chosen_so_far.get("Motherboard", []):
                                        if mp is not None:
                                            mobo_part = mp
                                            break
                                    if mobo_part:
                                        if first_gpu_multi_type == "SLI" and mobo_part.get("Support SLI", "").strip().upper() != "Y":
                                            continue
                                        if first_gpu_multi_type == "CrossFire" and mobo_part.get("Support CrossFire", "").strip().upper() != "Y":
                                            continue
                                # RAM matching check
                                if cat == "RAM" and slot_idx >= 1 and (first_ram_size is not None or first_ram_freq is not None):
                                    ram_size = _safe_int(p_data.get("Size (GB)", 0))
                                    ram_freq = _safe_int(p_data.get("Frequency", 0))
                                    if first_ram_size is not None and ram_size != first_ram_size:
                                        continue
                                    if first_ram_freq is not None and ram_freq != first_ram_freq:
                                        continue
                                valid.append(p_data)
                            if brand_list:
                                valid.sort(key=lambda p: (
                                    0 if p.get("Manufacturer", "").strip().lower() in brand_list else 1,
                                    -_safe_float(p.get("Price", 0)),
                                ))
                            else:
                                valid.sort(key=lambda p: _safe_float(p.get("Price", 0)), reverse=True)
                            for v in valid:
                                test_chosen = dict(chosen)
                                test_chosen[cat] = list(test_chosen.get(cat, []))
                                if slot_idx < len(test_chosen[cat]):
                                    test_chosen[cat][slot_idx] = v
                                test_all = {}
                                for tc in JOB_SLOT_ORDER:
                                    test_all[tc] = []
                                    if tc in test_chosen:
                                        for tp in test_chosen[tc]:
                                            if tp is not None:
                                                test_all[tc].append(tp)
                                    if tc in locked_parts:
                                        for lp in locked_parts[tc]:
                                            if lp is not None and isinstance(lp, dict):
                                                test_all[tc].append(lp)
                                t_cpu = test_all.get("CPU", [None])[0] if test_all.get("CPU") else None
                                t_gpu = test_all.get("GPU", [])
                                t_ram = test_all.get("RAM", [])
                                t_score = calculate_3dmark(t_cpu, t_gpu, t_ram)
                                if t_score >= target_score:
                                    chosen[cat] = test_chosen[cat]
                                    score = t_score
                                    # Update tracking vars if needed
                                    if cat == "GPU" and slot_idx == 0:
                                        first_gpu_multi_type = v.get("Multi-GPU", "").strip()
                                    if cat == "RAM" and slot_idx == 0:
                                        first_ram_size = _safe_int(v.get("Size (GB)", 0))
                                        first_ram_freq = _safe_int(v.get("Frequency", 0))
                                    break
                            if score >= target_score:
                                break
                        if score >= target_score:
                            break
                    
                    # If still not meeting target, try adding additional GPU/RAM slots
                    if score < target_score:
                        # Try adding second GPU
                        if "GPU" in unlocked and len(chosen.get("GPU", [])) < 2 and first_gpu_multi_type:
                            max_s = JOB_SLOTS.get("GPU", 1)
                            cust_slots = customer_parts_raw.get("GPU", [None] * max_s)
                            slot_idx = 1  # Second GPU slot
                            cust_data = cust_slots[slot_idx] if slot_idx < len(cust_slots) else None
                            candidates = list(catalog.get("GPU", []))
                            valid = []
                            for part in candidates:
                                p_data = part.data if hasattr(part, "data") else part
                                part_level = _safe_int(p_data.get("Level", 0))
                                part_pct = _safe_float(p_data.get("Level %", 0))
                                if part_level > level:
                                    continue
                                if part_level == level and part_pct > progress:
                                    continue
                                if cust_data and isinstance(cust_data, dict):
                                    if _is_inferior(cust_data, p_data, "GPU"):
                                        continue
                                # Must match first GPU multi-GPU type
                                gpu_multi = p_data.get("Multi-GPU", "").strip()
                                if gpu_multi != first_gpu_multi_type:
                                    continue
                                # Motherboard must support it
                                mobo_part = None
                                for mp in all_chosen_so_far.get("Motherboard", []):
                                    if mp is not None:
                                        mobo_part = mp
                                        break
                                if mobo_part:
                                    if first_gpu_multi_type == "SLI" and mobo_part.get("Support SLI", "").strip().upper() != "Y":
                                        continue
                                    if first_gpu_multi_type == "CrossFire" and mobo_part.get("Support CrossFire", "").strip().upper() != "Y":
                                        continue
                                valid.append(p_data)
                            if brand_list:
                                valid.sort(key=lambda p: (
                                    0 if p.get("Manufacturer", "").strip().lower() in brand_list else 1,
                                    -_safe_float(p.get("Price", 0)),
                                ))
                            else:
                                valid.sort(key=lambda p: _safe_float(p.get("Price", 0)), reverse=True)
                            for v in valid:
                                test_chosen = dict(chosen)
                                test_chosen["GPU"] = list(test_chosen.get("GPU", [None, None]))
                                if len(test_chosen["GPU"]) < 2:
                                    test_chosen["GPU"].append(None)
                                test_chosen["GPU"][slot_idx] = v
                                test_all = {}
                                for tc in JOB_SLOT_ORDER:
                                    test_all[tc] = []
                                    if tc in test_chosen:
                                        for tp in test_chosen[tc]:
                                            if tp is not None:
                                                test_all[tc].append(tp)
                                    if tc in locked_parts:
                                        for lp in locked_parts[tc]:
                                            if lp is not None and isinstance(lp, dict):
                                                test_all[tc].append(lp)
                                t_cpu = test_all.get("CPU", [None])[0] if test_all.get("CPU") else None
                                t_gpu = test_all.get("GPU", [])
                                t_ram = test_all.get("RAM", [])
                                t_score = calculate_3dmark(t_cpu, t_gpu, t_ram)
                                if t_score >= target_score:
                                    chosen["GPU"] = test_chosen["GPU"]
                                    score = t_score
                                    all_chosen_so_far["GPU"] = [p for p in chosen["GPU"] if p is not None]
                                    log.info(f"Added second GPU to meet 3DMark target. Score: {score}")
                                    break
                        
                        # Try adding more RAM if still not meeting target
                        if score < target_score and "RAM" in unlocked:
                            current_ram_count = len([p for p in chosen.get("RAM", []) if p is not None])
                            max_ram = JOB_SLOTS.get("RAM", 1)
                            mobo_part = None
                            for mp in all_chosen_so_far.get("Motherboard", []):
                                if mp is not None:
                                    mobo_part = mp
                                    break
                            max_ram_slots = mobo_part.get("RAM Slots", max_ram) if mobo_part else max_ram
                            
                            for additional_slot in range(current_ram_count, min(max_ram_slots, max_ram)):
                                if score >= target_score:
                                    break
                                max_s = JOB_SLOTS.get("RAM", 1)
                                cust_slots = customer_parts_raw.get("RAM", [None] * max_s)
                                slot_idx = additional_slot
                                cust_data = cust_slots[slot_idx] if slot_idx < len(cust_slots) else None
                                candidates = list(catalog.get("RAM", []))
                                valid = []
                                for part in candidates:
                                    p_data = part.data if hasattr(part, "data") else part
                                    part_level = _safe_int(p_data.get("Level", 0))
                                    part_pct = _safe_float(p_data.get("Level %", 0))
                                    if part_level > level:
                                        continue
                                    if part_level == level and part_pct > progress:
                                        continue
                                    if cust_data and isinstance(cust_data, dict):
                                        if _is_inferior(cust_data, p_data, "RAM"):
                                            continue
                                    # Must match first RAM specs
                                    ram_size = _safe_int(p_data.get("Size (GB)", 0))
                                    ram_freq = _safe_int(p_data.get("Frequency", 0))
                                    if first_ram_size is not None and ram_size != first_ram_size:
                                        continue
                                    if first_ram_freq is not None and ram_freq != first_ram_freq:
                                        continue
                                    valid.append(p_data)
                                if brand_list:
                                    valid.sort(key=lambda p: (
                                        0 if p.get("Manufacturer", "").strip().lower() in brand_list else 1,
                                        -_safe_float(p.get("Price", 0)),
                                    ))
                                else:
                                    valid.sort(key=lambda p: _safe_float(p.get("Price", 0)), reverse=True)
                                for v in valid:
                                    test_chosen = dict(chosen)
                                    test_chosen["RAM"] = list(test_chosen.get("RAM", []))
                                    while len(test_chosen["RAM"]) <= slot_idx:
                                        test_chosen["RAM"].append(None)
                                    test_chosen["RAM"][slot_idx] = v
                                    test_all = {}
                                    for tc in JOB_SLOT_ORDER:
                                        test_all[tc] = []
                                        if tc in test_chosen:
                                            for tp in test_chosen[tc]:
                                                if tp is not None:
                                                    test_all[tc].append(tp)
                                        if tc in locked_parts:
                                            for lp in locked_parts[tc]:
                                                if lp is not None and isinstance(lp, dict):
                                                    test_all[tc].append(lp)
                                    t_cpu = test_all.get("CPU", [None])[0] if test_all.get("CPU") else None
                                    t_gpu = test_all.get("GPU", [])
                                    t_ram = test_all.get("RAM", [])
                                    t_score = calculate_3dmark(t_cpu, t_gpu, t_ram)
                                    if t_score >= target_score:
                                        chosen["RAM"] = test_chosen["RAM"]
                                        score = t_score
                                        all_chosen_so_far["RAM"] = [p for p in chosen["RAM"] if p is not None]
                                        log.info(f"Added additional RAM stick to meet 3DMark target. Score: {score}")
                                        break

        if not is_story:
            total_cost = 0.0
            for cat in JOB_SLOT_ORDER:
                for p in chosen.get(cat, []):
                    if p is not None:
                        total_cost += _safe_float(p.get("Price", 0))

            if total_cost > actual_budget:
                sorted_optional = sorted(
                    optional,
                    key=lambda c: priority_order.index(c) if c in priority_order else 999,
                    reverse=True,
                )
                for opt_cat in sorted_optional:
                    if total_cost <= actual_budget:
                        break
                    cat_parts = chosen.get(opt_cat, [])
                    for idx in range(len(cat_parts) - 1, -1, -1):
                        if cat_parts[idx] is not None:
                            total_cost -= _safe_float(cat_parts[idx].get("Price", 0))
                            cat_parts[idx] = {"original": True}
                            if total_cost <= actual_budget:
                                break
                    chosen[opt_cat] = cat_parts

        new_parts_inv = self._state.new_parts
        used_parts_inv = self._state.used_parts

        for cat in JOB_SLOT_ORDER:
            max_s = JOB_SLOTS.get(cat, 1)
            if cat not in unlocked or cat == "Case":
                cust_slots = customer_parts_raw.get(cat, [None] * max_s)
                for i in range(max_s):
                    cust_data = cust_slots[i] if i < len(cust_slots) else None
                    if cust_data is not None:
                        slot_data = dict(cust_data) if isinstance(cust_data, dict) else {}
                        slot_data["locked"] = True
                        self._state.set_job_player_slot_data(job["id"], cat, i, slot_data)
                    else:
                        self._state.set_job_player_slot_data(job["id"], cat, i, None)
                continue

            cat_chosen = chosen.get(cat, [])
            for i in range(max_s):
                part_data = cat_chosen[i] if i < len(cat_chosen) else None
                if part_data is None:
                    self._state.set_job_player_slot_data(job["id"], cat, i, None)
                elif isinstance(part_data, dict) and part_data.get("original"):
                    self._state.set_job_player_slot_data(job["id"], cat, i, {"original": True})
                elif isinstance(part_data, dict) and part_data.get("locked"):
                    self._state.set_job_player_slot_data(job["id"], cat, i, {"locked": True})
                else:
                    part_name = part_data.get("Full Part Name", "")
                    in_new = False
                    for np in new_parts_inv:
                        if np["data"].get("Full Part Name", "") == part_name and not np.get("used_in_job") and not np.get("used_in_build"):
                            in_new = True
                            break
                    in_used = False
                    for up in used_parts_inv:
                        if up["data"].get("Full Part Name", "") == part_name and not up.get("used_in_build"):
                            in_used = True
                            break

                    slot_data = {"data": dict(part_data)}
                    if in_new:
                        slot_data["inventory"] = True
                    elif in_used:
                        slot_data["inventory"] = True
                    else:
                        slot_data["purchase"] = True

                    self._state.set_job_player_slot_data(job["id"], cat, i, slot_data)

        log.info(f"Auto build completed for job '{job['name']}'")

    # ── Auto Build (New PC) ──────────────────────────────────────────

    def _on_auto_build_new_pc(self, job):
        if not job.get("new_pc_build"):
            self._show_popup("Auto Build", "Auto Build requires New PC Build to be checked under Job Details.")
            return

        level = _safe_int(job.get("level", 1), 1)
        progress = _safe_int(job.get("progress", 0), 0)
        budget = _safe_float(job.get("budget", 0))
        actual_budget = budget * 1.1
        is_story = job.get("story_job", False)
        aio_required = job.get("aio_cooling_required", False)

        catalog = self._state.catalog

        priority_order = self._state.get_setting("part_priority", DEFAULT_PART_PRIORITY)

        brand_pref = job.get("brand_preference", False)
        brand_list = [b.strip().lower() for b in job.get("brand_list", [])] if brand_pref else []

        chosen = {}
        all_chosen_so_far = {}
        first_gpu_multi_type = None
        first_ram_size = None
        first_ram_freq = None

        # For new PC build, fill 1 slot for GPU/RAM/Storage initially, all for others
        initial_slots_to_fill = {}
        for cat in JOB_SLOT_ORDER:
            if cat == "Case":
                initial_slots_to_fill[cat] = JOB_SLOTS.get(cat, 1)
            elif cat in ("GPU", "RAM", "Storage"):
                initial_slots_to_fill[cat] = 1
            else:
                initial_slots_to_fill[cat] = JOB_SLOTS.get(cat, 1)

        for cat in JOB_SLOT_ORDER:
            max_s = JOB_SLOTS.get(cat, 1)
            best_parts = []

            slots_to_fill = initial_slots_to_fill.get(cat, max_s)

            for slot_idx in range(max_s):
                if slot_idx >= slots_to_fill:
                    best_parts.append(None)
                    continue

                candidates = list(catalog.get(cat, []))

                valid = []
                for part in candidates:
                    p_data = part.data if hasattr(part, "data") else part

                    part_level = _safe_int(p_data.get("Level", 0))
                    part_pct = _safe_float(p_data.get("Level %", 0))

                    if part_level > level:
                        continue
                    if part_level == level and part_pct > progress:
                        continue

                    # AIO filter: only pick Liquid Cooler for CPU Cooler when required
                    if cat == "CPU Cooler" and aio_required:
                        cooler_type = str(p_data.get("Type", "")).strip()
                        if cooler_type != "Liquid Cooler":
                            continue

                    # Multi-GPU compatibility check for second GPU slot
                    if cat == "GPU" and slot_idx == 1 and first_gpu_multi_type:
                        gpu_multi = p_data.get("Multi-GPU", "").strip()
                        if gpu_multi != first_gpu_multi_type:
                            continue
                        mobo_part = None
                        for mp in all_chosen_so_far.get("Motherboard", []):
                            if mp is not None:
                                mobo_part = mp
                                break
                        if mobo_part:
                            if first_gpu_multi_type == "SLI":
                                if mobo_part.get("Support SLI", "").strip().upper() != "Y":
                                    continue
                            elif first_gpu_multi_type == "CrossFire":
                                if mobo_part.get("Support CrossFire", "").strip().upper() != "Y":
                                    continue

                    # RAM matching check for additional RAM slots
                    if cat == "RAM" and slot_idx >= 1 and (first_ram_size is not None or first_ram_freq is not None):
                        ram_size = _safe_int(p_data.get("Size (GB)", 0))
                        ram_freq = _safe_int(p_data.get("Frequency", 0))
                        if first_ram_size is not None and ram_size != first_ram_size:
                            continue
                        if first_ram_freq is not None and ram_freq != first_ram_freq:
                            continue

                    valid.append(p_data)

                if not valid:
                    best_parts.append(None)
                    continue

                final_candidates = []
                for v in valid:
                    test_slots = dict(all_chosen_so_far)
                    if cat not in test_slots:
                        test_slots[cat] = []
                    test_entry = list(test_slots[cat])
                    test_entry.append(v)
                    test_slots[cat] = test_entry

                    compat_check = {}
                    for check_cat in JOB_SLOT_ORDER:
                        compat_check[check_cat] = test_slots.get(check_cat, [None])

                    warns = check_compatibility(compat_check)
                    if not warns:
                        final_candidates.append(v)

                if not final_candidates:
                    final_candidates = valid

                if brand_list:
                    final_candidates.sort(key=lambda p: (
                        0 if p.get("Manufacturer", "").strip().lower() in brand_list else 1,
                        _safe_float(p.get("Price", 99999)),
                    ))
                else:
                    final_candidates.sort(key=lambda p: _safe_float(p.get("Price", 99999)))
                best = final_candidates[0] if final_candidates else None
                best_parts.append(best)

                if best:
                    if cat not in all_chosen_so_far:
                        all_chosen_so_far[cat] = []
                    all_chosen_so_far[cat].append(best)
                    if cat == "GPU" and slot_idx == 0:
                        first_gpu_multi_type = best.get("Multi-GPU", "").strip()
                    if cat == "RAM" and slot_idx == 0:
                        first_ram_size = _safe_int(best.get("Size (GB)", 0))
                        first_ram_freq = _safe_int(best.get("Frequency", 0))

            chosen[cat] = best_parts

        # 3DMark target handling
        if job.get("three_dmark_check"):
            target_score = _safe_int(job.get("three_dmark_target", 0))
            if target_score > 0:
                all_parts_for_score = {}
                for cat in JOB_SLOT_ORDER:
                    all_parts_for_score[cat] = []
                    if cat in chosen:
                        for p in chosen[cat]:
                            if p is not None:
                                all_parts_for_score[cat].append(p)

                cpu_data = all_parts_for_score.get("CPU", [None])[0] if all_parts_for_score.get("CPU") else None
                gpu_parts = all_parts_for_score.get("GPU", [])
                ram_parts = all_parts_for_score.get("RAM", [])
                score = calculate_3dmark(cpu_data, gpu_parts, ram_parts)

                if score < target_score:
                    log.warning(f"New PC auto build 3DMark score {score} < target {target_score}. Trying higher-priced parts.")

                    # Try upgrading parts in existing slots
                    for cat in ["GPU", "CPU", "RAM"]:
                        max_s = JOB_SLOTS.get(cat, 1)
                        for slot_idx in range(max_s):
                            if slot_idx >= len(chosen.get(cat, [])) or chosen[cat][slot_idx] is None:
                                continue
                            candidates = list(catalog.get(cat, []))
                            valid = []
                            for part in candidates:
                                p_data = part.data if hasattr(part, "data") else part
                                part_level = _safe_int(p_data.get("Level", 0))
                                part_pct = _safe_float(p_data.get("Level %", 0))
                                if part_level > level:
                                    continue
                                if part_level == level and part_pct > progress:
                                    continue
                                if cat == "GPU" and slot_idx == 1 and first_gpu_multi_type:
                                    gpu_multi = p_data.get("Multi-GPU", "").strip()
                                    if gpu_multi != first_gpu_multi_type:
                                        continue
                                    mobo_part = None
                                    for mp in all_chosen_so_far.get("Motherboard", []):
                                        if mp is not None:
                                            mobo_part = mp
                                            break
                                    if mobo_part:
                                        if first_gpu_multi_type == "SLI" and mobo_part.get("Support SLI", "").strip().upper() != "Y":
                                            continue
                                        if first_gpu_multi_type == "CrossFire" and mobo_part.get("Support CrossFire", "").strip().upper() != "Y":
                                            continue
                                if cat == "RAM" and slot_idx >= 1 and (first_ram_size is not None or first_ram_freq is not None):
                                    ram_size = _safe_int(p_data.get("Size (GB)", 0))
                                    ram_freq = _safe_int(p_data.get("Frequency", 0))
                                    if first_ram_size is not None and ram_size != first_ram_size:
                                        continue
                                    if first_ram_freq is not None and ram_freq != first_ram_freq:
                                        continue
                                valid.append(p_data)
                            if brand_list:
                                valid.sort(key=lambda p: (
                                    0 if p.get("Manufacturer", "").strip().lower() in brand_list else 1,
                                    -_safe_float(p.get("Price", 0)),
                                ))
                            else:
                                valid.sort(key=lambda p: _safe_float(p.get("Price", 0)), reverse=True)
                            for v in valid:
                                test_chosen = dict(chosen)
                                test_chosen[cat] = list(test_chosen.get(cat, []))
                                if slot_idx < len(test_chosen[cat]):
                                    test_chosen[cat][slot_idx] = v
                                test_all = {}
                                for tc in JOB_SLOT_ORDER:
                                    test_all[tc] = []
                                    if tc in test_chosen:
                                        for tp in test_chosen[tc]:
                                            if tp is not None:
                                                test_all[tc].append(tp)
                                t_cpu = test_all.get("CPU", [None])[0] if test_all.get("CPU") else None
                                t_gpu = test_all.get("GPU", [])
                                t_ram = test_all.get("RAM", [])
                                t_score = calculate_3dmark(t_cpu, t_gpu, t_ram)
                                if t_score >= target_score:
                                    chosen[cat] = test_chosen[cat]
                                    score = t_score
                                    if cat == "GPU" and slot_idx == 0:
                                        first_gpu_multi_type = v.get("Multi-GPU", "").strip()
                                    if cat == "RAM" and slot_idx == 0:
                                        first_ram_size = _safe_int(v.get("Size (GB)", 0))
                                        first_ram_freq = _safe_int(v.get("Frequency", 0))
                                    break
                            if score >= target_score:
                                break
                        if score >= target_score:
                            break

                    # Try adding additional GPU/RAM slots
                    if score < target_score:
                        if len(chosen.get("GPU", [])) < 2 and first_gpu_multi_type:
                            max_s = JOB_SLOTS.get("GPU", 1)
                            slot_idx = 1
                            candidates = list(catalog.get("GPU", []))
                            valid = []
                            for part in candidates:
                                p_data = part.data if hasattr(part, "data") else part
                                part_level = _safe_int(p_data.get("Level", 0))
                                part_pct = _safe_float(p_data.get("Level %", 0))
                                if part_level > level:
                                    continue
                                if part_level == level and part_pct > progress:
                                    continue
                                gpu_multi = p_data.get("Multi-GPU", "").strip()
                                if gpu_multi != first_gpu_multi_type:
                                    continue
                                mobo_part = None
                                for mp in all_chosen_so_far.get("Motherboard", []):
                                    if mp is not None:
                                        mobo_part = mp
                                        break
                                if mobo_part:
                                    if first_gpu_multi_type == "SLI" and mobo_part.get("Support SLI", "").strip().upper() != "Y":
                                        continue
                                    if first_gpu_multi_type == "CrossFire" and mobo_part.get("Support CrossFire", "").strip().upper() != "Y":
                                        continue
                                valid.append(p_data)
                            if brand_list:
                                valid.sort(key=lambda p: (
                                    0 if p.get("Manufacturer", "").strip().lower() in brand_list else 1,
                                    -_safe_float(p.get("Price", 0)),
                                ))
                            else:
                                valid.sort(key=lambda p: _safe_float(p.get("Price", 0)), reverse=True)
                            for v in valid:
                                test_chosen = dict(chosen)
                                test_chosen["GPU"] = list(test_chosen.get("GPU", [None, None]))
                                if len(test_chosen["GPU"]) < 2:
                                    test_chosen["GPU"].append(None)
                                test_chosen["GPU"][slot_idx] = v
                                test_all = {}
                                for tc in JOB_SLOT_ORDER:
                                    test_all[tc] = []
                                    if tc in test_chosen:
                                        for tp in test_chosen[tc]:
                                            if tp is not None:
                                                test_all[tc].append(tp)
                                t_cpu = test_all.get("CPU", [None])[0] if test_all.get("CPU") else None
                                t_gpu = test_all.get("GPU", [])
                                t_ram = test_all.get("RAM", [])
                                t_score = calculate_3dmark(t_cpu, t_gpu, t_ram)
                                if t_score >= target_score:
                                    chosen["GPU"] = test_chosen["GPU"]
                                    score = t_score
                                    all_chosen_so_far["GPU"] = [p for p in chosen["GPU"] if p is not None]
                                    log.info(f"Added second GPU to meet 3DMark target. Score: {score}")
                                    break

                        if score < target_score:
                            current_ram_count = len([p for p in chosen.get("RAM", []) if p is not None])
                            max_ram = JOB_SLOTS.get("RAM", 1)
                            mobo_part = None
                            for mp in all_chosen_so_far.get("Motherboard", []):
                                if mp is not None:
                                    mobo_part = mp
                                    break
                            max_ram_slots = mobo_part.get("RAM Slots", max_ram) if mobo_part else max_ram

                            for additional_slot in range(current_ram_count, min(max_ram_slots, max_ram)):
                                if score >= target_score:
                                    break
                                slot_idx = additional_slot
                                candidates = list(catalog.get("RAM", []))
                                valid = []
                                for part in candidates:
                                    p_data = part.data if hasattr(part, "data") else part
                                    part_level = _safe_int(p_data.get("Level", 0))
                                    part_pct = _safe_float(p_data.get("Level %", 0))
                                    if part_level > level:
                                        continue
                                    if part_level == level and part_pct > progress:
                                        continue
                                    ram_size = _safe_int(p_data.get("Size (GB)", 0))
                                    ram_freq = _safe_int(p_data.get("Frequency", 0))
                                    if first_ram_size is not None and ram_size != first_ram_size:
                                        continue
                                    if first_ram_freq is not None and ram_freq != first_ram_freq:
                                        continue
                                    valid.append(p_data)
                                if brand_list:
                                    valid.sort(key=lambda p: (
                                        0 if p.get("Manufacturer", "").strip().lower() in brand_list else 1,
                                        -_safe_float(p.get("Price", 0)),
                                    ))
                                else:
                                    valid.sort(key=lambda p: _safe_float(p.get("Price", 0)), reverse=True)
                                for v in valid:
                                    test_chosen = dict(chosen)
                                    test_chosen["RAM"] = list(test_chosen.get("RAM", []))
                                    while len(test_chosen["RAM"]) <= slot_idx:
                                        test_chosen["RAM"].append(None)
                                    test_chosen["RAM"][slot_idx] = v
                                    test_all = {}
                                    for tc in JOB_SLOT_ORDER:
                                        test_all[tc] = []
                                        if tc in test_chosen:
                                            for tp in test_chosen[tc]:
                                                if tp is not None:
                                                    test_all[tc].append(tp)
                                    t_cpu = test_all.get("CPU", [None])[0] if test_all.get("CPU") else None
                                    t_gpu = test_all.get("GPU", [])
                                    t_ram = test_all.get("RAM", [])
                                    t_score = calculate_3dmark(t_cpu, t_gpu, t_ram)
                                    if t_score >= target_score:
                                        chosen["RAM"] = test_chosen["RAM"]
                                        score = t_score
                                        all_chosen_so_far["RAM"] = [p for p in chosen["RAM"] if p is not None]
                                        log.info(f"Added additional RAM to meet 3DMark target. Score: {score}")
                                        break

        # Budget enforcement (non-story jobs) - no trimming, just check
        if not is_story:
            total_cost = 0.0
            for cat in JOB_SLOT_ORDER:
                for p in chosen.get(cat, []):
                    if p is not None:
                        total_cost += _safe_float(p.get("Price", 0))

            if total_cost > actual_budget:
                self._show_popup("Auto Build", "No valid build found within budget.")
                return

        # Save chosen parts to build_slots
        new_parts_inv = self._state.new_parts
        used_parts_inv = self._state.used_parts

        for cat in JOB_SLOT_ORDER:
            max_s = JOB_SLOTS.get(cat, 1)
            cat_chosen = chosen.get(cat, [])
            for i in range(max_s):
                part_data = cat_chosen[i] if i < len(cat_chosen) else None
                if part_data is None:
                    self._state.set_job_build_slot_data(job["id"], cat, i, None)
                else:
                    part_name = part_data.get("Full Part Name", "")
                    in_new = False
                    for np in new_parts_inv:
                        if np["data"].get("Full Part Name", "") == part_name and not np.get("used_in_job") and not np.get("used_in_build"):
                            in_new = True
                            break
                    in_used = False
                    for up in used_parts_inv:
                        if up["data"].get("Full Part Name", "") == part_name and not up.get("used_in_build"):
                            in_used = True
                            break

                    slot_data = {"data": dict(part_data)}
                    if in_new:
                        slot_data["inventory"] = True
                    elif in_used:
                        slot_data["inventory"] = True
                    else:
                        slot_data["purchase"] = True

                    self._state.set_job_build_slot_data(job["id"], cat, i, slot_data)

        log.info(f"New PC auto build completed for job '{job['name']}'")

    # ── CRUD Callbacks ───────────────────────────────────────────────

    def _on_job_select(self, event):
        selection = self._job_listbox.curselection()
        if not selection:
            return
        idx = selection[0]
        if idx < len(self._state.jobs):
            job = self._state.jobs[idx]
            self._state.set_active_job(job["id"])

    def _on_create(self):
        show_input_dialog(
            self.winfo_toplevel(),
            "Create Job",
            "Enter a name for the new job:",
            self._do_create,
            font_size=self._current_font_size,
        )

    def _do_create(self, name):
        self._state.create_job(name)
        log.info(f"Created job: {name}")

    def _on_rename(self):
        job = self._state.get_active_job()
        if job is None:
            return
        show_input_dialog(
            self.winfo_toplevel(),
            "Rename Job",
            "Enter a new name:",
            lambda name: self._state.rename_job(job["id"], name),
            default_text=job["name"],
            font_size=self._current_font_size,
        )

    def _on_delete(self):
        job = self._state.get_active_job()
        if job is None:
            return
        show_confirmation(
            self.winfo_toplevel(),
            "Delete Job",
            f"Are you sure you want to delete '{job['name']}'? Parts will be returned to inventory.",
            lambda: self._state.delete_job(job["id"]),
            font_size=self._current_font_size,
        )

    def _on_complete(self):
        job = self._state.get_active_job()
        if job is None:
            return
        show_confirmation(
            self.winfo_toplevel(),
            "Complete Job",
            f"Complete '{job['name']}'? This will remove the job and used parts from inventory.",
            lambda: self._state.complete_job(job["id"]),
            font_size=self._current_font_size,
        )

    # ── Field Change Handlers ────────────────────────────────────────

    def _on_story_toggle(self, job, var):
        self._state.update_job(job["id"], story_job=var.get())

    def _on_budget_change(self, job, entry):
        try:
            val = int(entry.get().strip()) if entry.get().strip() else 0
        except ValueError:
            val = job.get("budget", 0)
        self._state.update_job(job["id"], budget=val)

    def _on_level_change(self, job, entry):
        try:
            val = int(entry.get().strip()) if entry.get().strip() else 1
        except ValueError:
            val = job.get("level", 1)
        self._state.update_job(job["id"], level=val)

    def _on_progress_change(self, job, entry):
        try:
            val = int(entry.get().strip()) if entry.get().strip() else 0
        except ValueError:
            val = job.get("progress", 0)
        self._state.update_job(job["id"], progress=val)

    def _on_detail_toggle(self, job, key, var):
        self._state.update_job(job["id"], **{key: var.get()})

    def _on_replace_part_toggle(self, job, category, var):
        checked = dict(job.get("replace_parts_checked", {}))
        checked[category] = var.get()
        self._state.update_job(job["id"], replace_parts_checked=checked)

    def _on_3dmark_target_change(self, job, entry):
        try:
            val = int(entry.get().strip()) if entry.get().strip() else 0
        except ValueError:
            val = job.get("three_dmark_target", 0)
        self._state.update_job(job["id"], three_dmark_target=val)

    # ── Utilities ────────────────────────────────────────────────────

    def _copy_name(self, name):
        try:
            self.clipboard_clear()
            self.clipboard_append(name)
            log.debug(f"Copied to clipboard: {name}")
        except Exception:
            pass

    def _show_popup(self, title, message):
        fs = self._current_font_size
        scale = fs / FONT_SIZE_BASE
        w = int(400 * max(scale, 1.0))
        h = int(150 * max(scale, 1.0))

        popup = tk.Toplevel(self.winfo_toplevel())
        popup.title(title)
        popup.configure(bg=COLORS["bg_popup"])
        popup.transient(self.winfo_toplevel())
        popup.grab_set()
        popup.resizable(False, False)
        popup.geometry(f"{w}x{h}")
        popup.update_idletasks()
        x = self.winfo_toplevel().winfo_rootx() + (self.winfo_toplevel().winfo_width() - w) // 2
        y = self.winfo_toplevel().winfo_rooty() + (self.winfo_toplevel().winfo_height() - h) // 2
        popup.geometry(f"+{x}+{y}")

        frame = tk.Frame(popup, bg=COLORS["bg_popup"], padx=SPACING["lg"], pady=SPACING["lg"])
        frame.pack(fill="both", expand=True)
        tk.Label(
            frame, text=title, bg=COLORS["bg_popup"],
            fg=COLORS["fg_header"], font=(FONT_FAMILY, max(fs + 2, 12), "bold"),
        ).pack(anchor="w", pady=(0, SPACING["sm"]))
        tk.Label(
            frame, text=message, bg=COLORS["bg_popup"],
            fg=COLORS["fg_primary"], font=(FONT_FAMILY, fs),
            wraplength=int(w * 0.9), justify="left",
        ).pack(anchor="w", pady=(0, SPACING["lg"]))
        tk.Button(
            frame, text="OK", command=popup.destroy,
            bg=COLORS["bg_button"], fg=COLORS["fg_button"],
            font=(FONT_FAMILY, fs), relief="flat",
            activebackground=COLORS["bg_button_hover"],
            activeforeground=COLORS["fg_button"],
            padx=15, pady=5, cursor="hand2",
        ).pack(anchor="e")

    def _bind_mousewheel_recursive(self, widget):
        widget.bind("<MouseWheel>", lambda e: self._detail_canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))
        widget.bind("<Shift-MouseWheel>", lambda e: self._detail_canvas.xview_scroll(int(-1 * (e.delta / 120)), "units"))
        for child in widget.winfo_children():
            self._bind_mousewheel_recursive(child)

    def _on_settings_change(self):
        closed = self._state.get_setting("closed_tips", [])
        if "jobs_info" not in closed:
            try:
                exists = self._info_box.winfo_exists()
            except Exception:
                exists = False
            if not exists:
                self._info_box = InfoBox(
                    self,
                    text="This section is designed to help you complete email jobs. It will only take parts from the New Parts inventory.",
                    tip_id="jobs_info",
                    state_manager=self._state,
                )
                children = self.winfo_children()
                if len(children) > 1:
                    self._info_box.pack(fill="x", padx=SPACING["sm"], pady=(SPACING["sm"], 0),
                                        before=children[0])
                else:
                    self._info_box.pack(fill="x", padx=SPACING["sm"], pady=(SPACING["sm"], 0))

    def update_font_size(self, size):
        self._current_font_size = size
        self._job_listbox.configure(font=(FONT_FAMILY, size))
        self._list_label.configure(font=(FONT_FAMILY, size, "bold"))
        # Scale the list width proportionally with font size
        scale = size / FONT_SIZE_BASE
        new_width = int(self._base_list_width * scale)
        self._job_list_frame.configure(width=new_width)
        # Update buttons
        self._create_btn.update_font_size(size)
        self._rename_btn.update_font_size(size)
        self._delete_btn.update_font_size(size)
        self._complete_btn.update_font_size(size)
        # Update info box if it exists
        if hasattr(self, "_info_box") and self._info_box.winfo_exists():
            self._info_box.update_font_size(size)
        self._refresh_detail()
