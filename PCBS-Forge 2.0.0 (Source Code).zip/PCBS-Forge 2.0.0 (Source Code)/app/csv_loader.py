import csv
import os
import threading
import queue
from app.config import VANILLA_DIR, HEM_DIR, VANILLA_CSV_MAP, HEM_CSV_MAP, PART_CATEGORIES
from app.logger import get_logger

log = get_logger("CSVLoader")


class PartData:
    __slots__ = ["category", "data", "columns"]

    def __init__(self, category, data, columns):
        self.category = category
        self.data = data
        self.columns = columns

    def get(self, key, default=""):
        return self.data.get(key, default)

    def __getitem__(self, key):
        return self.data[key]

    def __contains__(self, key):
        return key in self.data

    def keys(self):
        return self.data.keys()


def _parse_csv_file(filepath, category):
    parts = []
    columns = []
    try:
        with open(filepath, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            columns = list(reader.fieldnames) if reader.fieldnames else []
            for row in reader:
                cleaned = {}
                for k, v in row.items():
                    if k is not None:
                        cleaned[k.strip()] = (v or "").strip()
                parts.append(PartData(category, cleaned, columns))
        log.info(f"Loaded {len(parts)} parts from {os.path.basename(filepath)}")
    except FileNotFoundError:
        log.error(f"CSV file not found: {filepath}")
    except Exception as e:
        log.error(f"Error loading CSV {filepath}: {e}")
    return parts, columns


def load_all_csvs(hem_enabled=False, result_queue=None):
    catalog = {}
    column_map = {}

    for category in PART_CATEGORIES:
        vanilla_file = os.path.join(VANILLA_DIR, VANILLA_CSV_MAP.get(category, ""))
        parts, columns = _parse_csv_file(vanilla_file, category)
        catalog[category] = list(parts)
        column_map[category] = list(columns)

        if hem_enabled:
            hem_file = os.path.join(HEM_DIR, HEM_CSV_MAP.get(category, ""))
            if os.path.exists(hem_file):
                hem_parts, hem_columns = _parse_csv_file(hem_file, category)
                existing_names = {p.get("Full Part Name", "") for p in catalog[category]}
                new_parts = [p for p in hem_parts if p.get("Full Part Name", "") not in existing_names]
                catalog[category].extend(new_parts)
                for col in hem_columns:
                    if col not in column_map[category]:
                        column_map[category].append(col)
                log.info(f"HEM: Added {len(new_parts)} new parts to {category}")

        log.info(f"Total {category}: {len(catalog[category])} parts, {len(column_map[category])} columns")

    if result_queue is not None:
        result_queue.put(("catalog_loaded", catalog, column_map))

    return catalog, column_map


def load_csvs_background(hem_enabled=False, result_queue=None):
    thread = threading.Thread(
        target=load_all_csvs,
        args=(hem_enabled, result_queue),
        daemon=True,
    )
    thread.start()
    log.info("Started background CSV loading thread")
    return thread
