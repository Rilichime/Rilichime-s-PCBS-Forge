import json
import os
import threading
from app.config import JSON_FILES
from app.logger import get_logger

log = get_logger("Persistence")


def _load_json(filepath):
    if not os.path.exists(filepath):
        return None
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        log.info(f"Loaded {filepath}")
        return data
    except Exception as e:
        log.error(f"Failed to load {filepath}: {e}")
        return None


def _save_json(filepath, data):
    try:
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        log.debug(f"Saved {filepath}")
    except Exception as e:
        log.error(f"Failed to save {filepath}: {e}")


def load_used_parts():
    return _load_json(JSON_FILES["used_parts"]) or []


def save_used_parts(parts_list):
    data = []
    for p in parts_list:
        data.append({
            "instance_id": p.get("instance_id", ""),
            "category": p.get("category", ""),
            "data": p.get("data", {}),
            "used_in_build": p.get("used_in_build", None),
        })
    _save_json(JSON_FILES["used_parts"], data)


def load_new_parts():
    return _load_json(JSON_FILES["new_parts"]) or []


def save_new_parts(parts_list):
    data = []
    for p in parts_list:
        data.append({
            "instance_id": p.get("instance_id", ""),
            "category": p.get("category", ""),
            "data": p.get("data", {}),
        })
    _save_json(JSON_FILES["new_parts"], data)


def load_builds():
    return _load_json(JSON_FILES["builds"]) or []


def save_builds(builds_list):
    _save_json(JSON_FILES["builds"], builds_list)


def load_jobs():
    return _load_json(JSON_FILES["jobs"]) or []


def save_jobs(jobs_list):
    _save_json(JSON_FILES["jobs"], jobs_list)


def load_settings():
    from app.config import DEFAULT_SETTINGS
    saved = _load_json(JSON_FILES["settings"])
    if saved is None:
        return dict(DEFAULT_SETTINGS)
    merged = dict(DEFAULT_SETTINGS)
    merged.update(saved)
    return merged


def save_settings(settings_dict):
    _save_json(JSON_FILES["settings"], settings_dict)


class DebouncedSaver:
    def __init__(self, delay_ms=1500):
        self._delay = delay_ms / 1000.0
        self._timers = {}
        self._lock = threading.Lock()

    def schedule(self, key, save_fn, *args):
        with self._lock:
            if key in self._timers:
                self._timers[key].cancel()
            timer = threading.Timer(self._delay, self._execute, args=(key, save_fn, args))
            timer.daemon = True
            self._timers[key] = timer
            timer.start()

    def _execute(self, key, save_fn, args):
        try:
            save_fn(*args)
        except Exception as e:
            log.error(f"Debounced save error for {key}: {e}")
        with self._lock:
            self._timers.pop(key, None)

    def flush(self):
        with self._lock:
            for key, timer in self._timers.items():
                timer.cancel()
            self._timers.clear()
