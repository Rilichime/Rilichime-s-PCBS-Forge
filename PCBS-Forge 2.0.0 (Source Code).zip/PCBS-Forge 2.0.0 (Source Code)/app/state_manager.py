import uuid
import threading
from app.config import BUILD_SLOTS, BUILD_SLOT_ORDER, JOB_SLOTS, JOB_SLOT_ORDER, PART_CATEGORIES
from app.persistence import (
    load_used_parts, save_used_parts,
    load_new_parts, save_new_parts,
    load_builds, save_builds,
    load_jobs, save_jobs,
    load_settings, save_settings,
    DebouncedSaver,
)
from app.logger import get_logger

log = get_logger("State")


class StateManager:
    def __init__(self):
        self._lock = threading.Lock()
        self._saver = DebouncedSaver(delay_ms=1500)

        self.catalog = {}
        self.column_map = {}

        self.used_parts = []
        self.new_parts = []
        self.builds = []
        self.jobs = []
        self.settings = {}

        self.active_build_id = None
        self.active_job_id = None

        self._listeners = {
            "used_parts": [],
            "new_parts": [],
            "builds": [],
            "jobs": [],
            "settings": [],
            "catalog": [],
            "active_build": [],
            "active_job": [],
        }

    def initialize(self):
        log.info("Initializing state manager")
        self.settings = load_settings()

        raw_used = load_used_parts()
        self.used_parts = []
        for item in raw_used:
            part = {
                "instance_id": item.get("instance_id", str(uuid.uuid4())),
                "category": item.get("category", ""),
                "data": item.get("data", {}),
                "used_in_build": item.get("used_in_build", None),
            }
            self.used_parts.append(part)
        log.info(f"Loaded {len(self.used_parts)} used parts from save")

        raw_new = load_new_parts()
        self.new_parts = []
        for item in raw_new:
            part = {
                "instance_id": item.get("instance_id", str(uuid.uuid4())),
                "category": item.get("category", ""),
                "data": item.get("data", {}),
            }
            self.new_parts.append(part)
        log.info(f"Loaded {len(self.new_parts)} new parts from save")

        raw_builds = load_builds()
        self.builds = []
        for b in raw_builds:
            build = {
                "id": b.get("id", str(uuid.uuid4())),
                "name": b.get("name", "Unnamed Build"),
                "slots": {},
            }
            raw_slots = b.get("slots", {})
            for cat in BUILD_SLOT_ORDER:
                max_slots = BUILD_SLOTS.get(cat, 1)
                saved_slots = raw_slots.get(cat, [None] * max_slots)
                while len(saved_slots) < max_slots:
                    saved_slots.append(None)
                build["slots"][cat] = saved_slots[:max_slots]
            self.builds.append(build)
        log.info(f"Loaded {len(self.builds)} builds from save")

        if self.builds:
            self.active_build_id = self.builds[0]["id"]

        raw_jobs = load_jobs()
        self.jobs = []
        for j in raw_jobs:
            job = {
                "id": j.get("id", str(uuid.uuid4())),
                "name": j.get("name", "Unnamed Job"),
                "budget": j.get("budget", 0),
                "story_job": j.get("story_job", False),
                "level": j.get("level", 1),
                "progress": j.get("progress", 0),
                "new_pc_build": j.get("new_pc_build", False),
                "replace_upgrade": j.get("replace_upgrade", False),
                "replace_parts_checked": j.get("replace_parts_checked", {}),
                "three_dmark_check": j.get("three_dmark_check", False),
                "three_dmark_target": j.get("three_dmark_target", 0),
                "clean_dust": j.get("clean_dust", False),
                "remove_viruses": j.get("remove_viruses", False),
                "new_cables": j.get("new_cables", False),
                "cables_list": j.get("cables_list", []),
                "brand_preference": j.get("brand_preference", False),
                "brand_list": j.get("brand_list", []),
                "build_slots": j.get("build_slots", {}),
                "customer_slots": j.get("customer_slots", {}),
                "player_slots": j.get("player_slots", {}),
            }
            for cat in JOB_SLOT_ORDER:
                max_s = JOB_SLOTS.get(cat, 1)
                if cat not in job["build_slots"]:
                    job["build_slots"][cat] = [None] * max_s
                if cat not in job["customer_slots"]:
                    job["customer_slots"][cat] = [None] * max_s
                if cat not in job["player_slots"]:
                    job["player_slots"][cat] = [None] * max_s
                while len(job["build_slots"][cat]) < max_s:
                    job["build_slots"][cat].append(None)
                while len(job["customer_slots"][cat]) < max_s:
                    job["customer_slots"][cat].append(None)
                while len(job["player_slots"][cat]) < max_s:
                    job["player_slots"][cat].append(None)
            self.jobs.append(job)
        log.info(f"Loaded {len(self.jobs)} jobs from save")

        if self.jobs:
            self.active_job_id = self.jobs[0]["id"]

    def set_catalog(self, catalog, column_map):
        with self._lock:
            self.catalog = catalog
            self.column_map = column_map
        log.info("Catalog set in state manager")
        self._notify("catalog")

    def subscribe(self, event, callback):
        if event in self._listeners:
            self._listeners[event].append(callback)

    def _notify(self, event):
        for cb in self._listeners.get(event, []):
            try:
                cb()
            except Exception as e:
                log.error(f"Listener error for {event}: {e}")

    def _schedule_save_used(self):
        self._saver.schedule("used_parts", save_used_parts, self.used_parts)

    def _schedule_save_new(self):
        self._saver.schedule("new_parts", save_new_parts, self.new_parts)

    def _schedule_save_builds(self):
        self._saver.schedule("builds", save_builds, self.builds)

    def _schedule_save_settings(self):
        self._saver.schedule("settings", save_settings, self.settings)

    def _schedule_save_jobs(self):
        self._saver.schedule("jobs", save_jobs, self.jobs)

    def add_used_part(self, category, catalog_part_data):
        instance_id = str(uuid.uuid4())
        data_copy = dict(catalog_part_data) if isinstance(catalog_part_data, dict) else dict(catalog_part_data.data)
        part = {
            "instance_id": instance_id,
            "category": category,
            "data": data_copy,
            "used_in_build": None,
        }
        with self._lock:
            self.used_parts.append(part)
        log.info(f"Added used part: {data_copy.get('Full Part Name', '?')} (ID: {instance_id})")
        self._schedule_save_used()
        self._notify("used_parts")
        return instance_id

    def remove_used_part(self, instance_id):
        with self._lock:
            part = None
            for p in self.used_parts:
                if p["instance_id"] == instance_id:
                    part = p
                    break
            if part is None:
                log.warning(f"Part {instance_id} not found for removal")
                return False

            build_id = part.get("used_in_build")
            if build_id:
                self._remove_part_from_build_internal(build_id, instance_id)

            self.used_parts = [p for p in self.used_parts if p["instance_id"] != instance_id]

        part_name = part["data"].get("Full Part Name", "?")
        log.info(f"Removed used part: {part_name} (ID: {instance_id})")
        self._schedule_save_used()
        if build_id:
            self._schedule_save_builds()
            self._notify("builds")
        self._notify("used_parts")
        return True

    def delete_all_used_parts(self):
        with self._lock:
            for part in self.used_parts:
                build_id = part.get("used_in_build")
                if build_id:
                    self._remove_part_from_build_internal(build_id, part["instance_id"])
            self.used_parts = []
        log.info("Deleted all used parts")
        self._schedule_save_used()
        self._schedule_save_builds()
        self._notify("used_parts")
        self._notify("builds")

    def add_new_part(self, category, catalog_part_data):
        instance_id = str(uuid.uuid4())
        data_copy = dict(catalog_part_data) if isinstance(catalog_part_data, dict) else dict(catalog_part_data.data)
        part = {
            "instance_id": instance_id,
            "category": category,
            "data": data_copy,
        }
        with self._lock:
            self.new_parts.append(part)
        log.info(f"Added new part: {data_copy.get('Full Part Name', '?')} (ID: {instance_id})")
        self._schedule_save_new()
        self._notify("new_parts")
        return instance_id

    def remove_new_part(self, instance_id):
        with self._lock:
            found = False
            name = "?"
            for p in self.new_parts:
                if p["instance_id"] == instance_id:
                    name = p["data"].get("Full Part Name", "?")
                    found = True
                    break
            if not found:
                log.warning(f"New part {instance_id} not found for removal")
                return False
            self.new_parts = [p for p in self.new_parts if p["instance_id"] != instance_id]
        log.info(f"Removed new part: {name} (ID: {instance_id})")
        self._schedule_save_new()
        self._notify("new_parts")
        return True

    def delete_all_new_parts(self):
        with self._lock:
            self.new_parts = []
        log.info("Deleted all new parts")
        self._schedule_save_new()
        self._notify("new_parts")

    def create_build(self, name):
        build_id = str(uuid.uuid4())
        build = {
            "id": build_id,
            "name": name,
            "slots": {},
        }
        for cat in BUILD_SLOT_ORDER:
            max_slots = BUILD_SLOTS.get(cat, 1)
            build["slots"][cat] = [None] * max_slots
        with self._lock:
            self.builds.append(build)
            self.active_build_id = build_id
        log.info(f"Created build: {name} (ID: {build_id})")
        self._schedule_save_builds()
        self._notify("builds")
        self._notify("active_build")
        return build_id

    def rename_build(self, build_id, new_name):
        with self._lock:
            for b in self.builds:
                if b["id"] == build_id:
                    old_name = b["name"]
                    b["name"] = new_name
                    log.info(f"Renamed build: {old_name} -> {new_name}")
                    break
        self._schedule_save_builds()
        self._notify("builds")

    def delete_build(self, build_id):
        with self._lock:
            build = None
            for b in self.builds:
                if b["id"] == build_id:
                    build = b
                    break
            if build is None:
                return False

            for cat in BUILD_SLOT_ORDER:
                for i, slot in enumerate(build["slots"].get(cat, [])):
                    if slot is not None:
                        inst_id = slot if isinstance(slot, str) else slot.get("instance_id", "")
                        for p in self.used_parts:
                            if p["instance_id"] == inst_id:
                                p["used_in_build"] = None
                                break

            self.builds = [b for b in self.builds if b["id"] != build_id]

            if self.active_build_id == build_id:
                self.active_build_id = self.builds[0]["id"] if self.builds else None

        log.info(f"Deleted build: {build.get('name', '?')} (ID: {build_id})")
        self._schedule_save_builds()
        self._schedule_save_used()
        self._notify("builds")
        self._notify("active_build")
        self._notify("used_parts")
        return True

    def complete_build(self, build_id):
        with self._lock:
            build = None
            for b in self.builds:
                if b["id"] == build_id:
                    build = b
                    break
            if build is None:
                return False

            parts_to_remove = []
            for cat in BUILD_SLOT_ORDER:
                for slot in build["slots"].get(cat, []):
                    if slot is not None:
                        inst_id = slot if isinstance(slot, str) else slot.get("instance_id", "")
                        parts_to_remove.append(inst_id)

            self.used_parts = [p for p in self.used_parts if p["instance_id"] not in parts_to_remove]
            self.builds = [b for b in self.builds if b["id"] != build_id]

            if self.active_build_id == build_id:
                self.active_build_id = self.builds[0]["id"] if self.builds else None

        log.info(f"Completed build: {build.get('name', '?')} - removed {len(parts_to_remove)} parts")
        self._schedule_save_builds()
        self._schedule_save_used()
        self._notify("builds")
        self._notify("active_build")
        self._notify("used_parts")
        return True

    def set_active_build(self, build_id):
        with self._lock:
            self.active_build_id = build_id
        log.info(f"Active build set to: {build_id}")
        self._notify("active_build")

    def get_active_build(self):
        if self.active_build_id is None:
            return None
        for b in self.builds:
            if b["id"] == self.active_build_id:
                return b
        return None

    def assign_part_to_build(self, instance_id, build_id):
        with self._lock:
            part = None
            for p in self.used_parts:
                if p["instance_id"] == instance_id:
                    part = p
                    break
            if part is None:
                log.warning(f"Part {instance_id} not found for build assignment")
                return False

            if part.get("used_in_build"):
                log.warning(f"Part {instance_id} already assigned to build {part['used_in_build']}")
                return False

            build = None
            for b in self.builds:
                if b["id"] == build_id:
                    build = b
                    break
            if build is None:
                log.warning(f"Build {build_id} not found")
                return False

            category = part["category"]
            slots = build["slots"].get(category, [])
            slot_index = -1
            for i, s in enumerate(slots):
                if s is None:
                    slot_index = i
                    break

            if slot_index == -1:
                log.warning(f"No empty slot in {category} for build {build['name']}")
                return False

            build["slots"][category][slot_index] = instance_id
            part["used_in_build"] = build_id

        part_name = part["data"].get("Full Part Name", "?")
        log.info(f"Assigned '{part_name}' to build '{build['name']}' slot {category}[{slot_index}]")
        self._schedule_save_builds()
        self._schedule_save_used()
        self._notify("builds")
        self._notify("used_parts")
        return True

    def remove_part_from_build(self, build_id, instance_id):
        with self._lock:
            self._remove_part_from_build_internal(build_id, instance_id)
        self._schedule_save_builds()
        self._schedule_save_used()
        self._notify("builds")
        self._notify("used_parts")

    def _remove_part_from_build_internal(self, build_id, instance_id):
        build = None
        for b in self.builds:
            if b["id"] == build_id:
                build = b
                break
        if build is None:
            return

        for cat in BUILD_SLOT_ORDER:
            slots = build["slots"].get(cat, [])
            for i, s in enumerate(slots):
                if s == instance_id:
                    build["slots"][cat][i] = None
                    break

        for p in self.used_parts:
            if p["instance_id"] == instance_id:
                p["used_in_build"] = None
                part_name = p["data"].get("Full Part Name", "?")
                log.info(f"Removed '{part_name}' from build '{build['name']}'")
                break

    def get_build_parts(self, build_id):
        build = None
        for b in self.builds:
            if b["id"] == build_id:
                build = b
                break
        if build is None:
            return {}

        result = {}
        for cat in BUILD_SLOT_ORDER:
            slots = build["slots"].get(cat, [])
            resolved = []
            for s in slots:
                if s is None:
                    resolved.append(None)
                else:
                    part_data = None
                    for p in self.used_parts:
                        if p["instance_id"] == s:
                            part_data = p
                            break
                    resolved.append(part_data)
            result[cat] = resolved
        return result

    def get_used_part_by_id(self, instance_id):
        for p in self.used_parts:
            if p["instance_id"] == instance_id:
                return p
        return None

    def get_parts_for_category(self, category, inventory_type="used"):
        if inventory_type == "used":
            return [p for p in self.used_parts if p["category"] == category]
        else:
            return [p for p in self.new_parts if p["category"] == category]

    def update_setting(self, key, value):
        self.settings[key] = value
        log.info(f"Setting updated: {key} = {value}")
        self._schedule_save_settings()
        self._notify("settings")

    def get_setting(self, key, default=None):
        return self.settings.get(key, default)

    def reset_tips(self):
        self.settings["closed_tips"] = []
        log.info("Tips reset")
        self._schedule_save_settings()
        self._notify("settings")

    # ── Job operations ──────────────────────────────────────────────

    def create_job(self, name):
        job_id = str(uuid.uuid4())
        job = {
            "id": job_id,
            "name": name,
            "budget": 0,
            "story_job": False,
            "level": 1,
            "progress": 0,
            "new_pc_build": False,
            "replace_upgrade": False,
            "replace_parts_checked": {},
            "three_dmark_check": False,
            "three_dmark_target": 0,
            "clean_dust": False,
            "remove_viruses": False,
            "new_cables": False,
            "cables_list": [],
            "brand_preference": False,
            "brand_list": [],
            "build_slots": {},
            "customer_slots": {},
            "player_slots": {},
        }
        for cat in JOB_SLOT_ORDER:
            max_s = JOB_SLOTS.get(cat, 1)
            job["build_slots"][cat] = [None] * max_s
            job["customer_slots"][cat] = [None] * max_s
            job["player_slots"][cat] = [None] * max_s
        with self._lock:
            self.jobs.append(job)
            self.active_job_id = job_id
        log.info(f"Created job: {name} (ID: {job_id})")
        self._schedule_save_jobs()
        self._notify("jobs")
        self._notify("active_job")
        return job_id

    def rename_job(self, job_id, new_name):
        with self._lock:
            for j in self.jobs:
                if j["id"] == job_id:
                    old_name = j["name"]
                    j["name"] = new_name
                    log.info(f"Renamed job: {old_name} -> {new_name}")
                    break
        self._schedule_save_jobs()
        self._notify("jobs")

    def delete_job(self, job_id):
        with self._lock:
            job = None
            for j in self.jobs:
                if j["id"] == job_id:
                    job = j
                    break
            if job is None:
                return False

            parts_to_free = []
            for cat in JOB_SLOT_ORDER:
                for slot_val in job.get("build_slots", {}).get(cat, []):
                    if slot_val is not None:
                        inst_id = slot_val if isinstance(slot_val, str) else slot_val.get("instance_id", "")
                        if inst_id:
                            parts_to_free.append(inst_id)
                for slot_val in job.get("player_slots", {}).get(cat, []):
                    if slot_val is not None:
                        inst_id = slot_val if isinstance(slot_val, str) else slot_val.get("instance_id", "")
                        if inst_id:
                            parts_to_free.append(inst_id)

            for p in self.new_parts:
                if p["instance_id"] in parts_to_free:
                    p.pop("used_in_job", None)

            self.jobs = [j for j in self.jobs if j["id"] != job_id]
            if self.active_job_id == job_id:
                self.active_job_id = self.jobs[0]["id"] if self.jobs else None

        log.info(f"Deleted job: {job.get('name', '?')} (ID: {job_id})")
        self._schedule_save_jobs()
        self._schedule_save_new()
        self._notify("jobs")
        self._notify("active_job")
        self._notify("new_parts")
        return True

    def complete_job(self, job_id):
        with self._lock:
            job = None
            for j in self.jobs:
                if j["id"] == job_id:
                    job = j
                    break
            if job is None:
                return False

            parts_to_remove = []
            if job.get("new_pc_build"):
                for cat in JOB_SLOT_ORDER:
                    for slot_val in job.get("build_slots", {}).get(cat, []):
                        if slot_val is not None:
                            inst_id = slot_val if isinstance(slot_val, str) else slot_val.get("instance_id", "")
                            if inst_id:
                                parts_to_remove.append(inst_id)
            elif job.get("replace_upgrade"):
                for cat in JOB_SLOT_ORDER:
                    for slot_val in job.get("player_slots", {}).get(cat, []):
                        if slot_val is not None:
                            inst_id = slot_val if isinstance(slot_val, str) else slot_val.get("instance_id", "")
                            if inst_id:
                                meta = slot_val if isinstance(slot_val, dict) else {}
                                if not meta.get("locked") and not meta.get("original"):
                                    parts_to_remove.append(inst_id)

            self.new_parts = [p for p in self.new_parts if p["instance_id"] not in parts_to_remove]
            self.jobs = [j for j in self.jobs if j["id"] != job_id]

            if self.active_job_id == job_id:
                self.active_job_id = self.jobs[0]["id"] if self.jobs else None

        log.info(f"Completed job: {job.get('name', '?')} - removed {len(parts_to_remove)} parts")
        self._schedule_save_jobs()
        self._schedule_save_new()
        self._notify("jobs")
        self._notify("active_job")
        self._notify("new_parts")
        return True

    def set_active_job(self, job_id):
        with self._lock:
            self.active_job_id = job_id
        log.info(f"Active job set to: {job_id}")
        self._notify("active_job")

    def get_active_job(self):
        if self.active_job_id is None:
            return None
        for j in self.jobs:
            if j["id"] == self.active_job_id:
                return j
        return None

    def update_job(self, job_id, **kwargs):
        with self._lock:
            for j in self.jobs:
                if j["id"] == job_id:
                    for k, v in kwargs.items():
                        j[k] = v
                    break
        self._schedule_save_jobs()
        self._notify("jobs")

    def assign_new_part_to_job(self, instance_id, job_id, slot_type="build_slots"):
        with self._lock:
            part = None
            for p in self.new_parts:
                if p["instance_id"] == instance_id:
                    part = p
                    break
            if part is None:
                log.warning(f"New part {instance_id} not found for job assignment")
                return False

            if part.get("used_in_job"):
                log.warning(f"New part {instance_id} already assigned to job {part['used_in_job']}")
                return False

            job = None
            for j in self.jobs:
                if j["id"] == job_id:
                    job = j
                    break
            if job is None:
                log.warning(f"Job {job_id} not found")
                return False

            category = part["category"]
            slots = job[slot_type].get(category, [])
            slot_index = -1
            for i, s in enumerate(slots):
                if s is None:
                    slot_index = i
                    break

            if slot_index == -1:
                log.warning(f"No empty slot in {category} for job {job['name']}")
                return False

            job[slot_type][category][slot_index] = instance_id
            part["used_in_job"] = job_id

        part_name = part["data"].get("Full Part Name", "?")
        log.info(f"Assigned '{part_name}' to job '{job['name']}' {slot_type} {category}[{slot_index}]")
        self._schedule_save_jobs()
        self._schedule_save_new()
        self._notify("jobs")
        self._notify("new_parts")
        return True

    def remove_part_from_job(self, job_id, instance_id, slot_type="build_slots"):
        with self._lock:
            job = None
            for j in self.jobs:
                if j["id"] == job_id:
                    job = j
                    break
            if job is None:
                return

            for cat in JOB_SLOT_ORDER:
                slots = job[slot_type].get(cat, [])
                for i, s in enumerate(slots):
                    sid = s if isinstance(s, str) else (s.get("instance_id", "") if isinstance(s, dict) else "")
                    if sid == instance_id:
                        job[slot_type][cat][i] = None
                        break

            for p in self.new_parts:
                if p["instance_id"] == instance_id:
                    p.pop("used_in_job", None)
                    part_name = p["data"].get("Full Part Name", "?")
                    log.info(f"Removed '{part_name}' from job '{job['name']}'")
                    break

        self._schedule_save_jobs()
        self._schedule_save_new()
        self._notify("jobs")
        self._notify("new_parts")

    def set_job_customer_slot(self, job_id, category, slot_index, part_data):
        with self._lock:
            for j in self.jobs:
                if j["id"] == job_id:
                    if category not in j["customer_slots"]:
                        j["customer_slots"][category] = [None] * JOB_SLOTS.get(category, 1)
                    if slot_index < len(j["customer_slots"][category]):
                        j["customer_slots"][category][slot_index] = part_data
                    break
        self._schedule_save_jobs()
        self._notify("jobs")

    def clear_job_customer_slot(self, job_id, category, slot_index):
        with self._lock:
            for j in self.jobs:
                if j["id"] == job_id:
                    if category in j["customer_slots"]:
                        if slot_index < len(j["customer_slots"][category]):
                            j["customer_slots"][category][slot_index] = None
                    break
        self._schedule_save_jobs()
        self._notify("jobs")

    def set_job_player_slot_data(self, job_id, category, slot_index, slot_data):
        with self._lock:
            for j in self.jobs:
                if j["id"] == job_id:
                    if category not in j["player_slots"]:
                        j["player_slots"][category] = [None] * JOB_SLOTS.get(category, 1)
                    if slot_index < len(j["player_slots"][category]):
                        j["player_slots"][category][slot_index] = slot_data
                    break
        self._schedule_save_jobs()
        self._notify("jobs")

    def set_job_build_slot_data(self, job_id, category, slot_index, slot_data):
        with self._lock:
            for j in self.jobs:
                if j["id"] == job_id:
                    if category not in j["build_slots"]:
                        j["build_slots"][category] = [None] * JOB_SLOTS.get(category, 1)
                    if slot_index < len(j["build_slots"][category]):
                        j["build_slots"][category][slot_index] = slot_data
                    break
        self._schedule_save_jobs()
        self._notify("jobs")

    def get_job_build_parts(self, job_id, slot_type="build_slots"):
        job = None
        for j in self.jobs:
            if j["id"] == job_id:
                job = j
                break
        if job is None:
            return {}

        result = {}
        for cat in JOB_SLOT_ORDER:
            slots = job[slot_type].get(cat, [])
            resolved = []
            for s in slots:
                if s is None:
                    resolved.append(None)
                elif isinstance(s, str):
                    part_data = None
                    for p in self.new_parts:
                        if p["instance_id"] == s:
                            part_data = p
                            break
                    resolved.append(part_data)
                elif isinstance(s, dict):
                    resolved.append(s)
                else:
                    resolved.append(None)
            result[cat] = resolved
        return result

    def flush_saves(self):
        self._saver.flush()
        save_used_parts(self.used_parts)
        save_new_parts(self.new_parts)
        save_builds(self.builds)
        save_jobs(self.jobs)
        save_settings(self.settings)
        log.info("All data flushed to disk")
