import logging
import os
from datetime import datetime
from app.config import LOGS_DIR


class SystemFilter(logging.Filter):
    def __init__(self, system_name="General"):
        super().__init__()
        self.system_name = system_name

    def filter(self, record):
        if not hasattr(record, "system"):
            record.system = self.system_name
        return True


class AppFormatter(logging.Formatter):
    def format(self, record):
        system = getattr(record, "system", "General")
        timestamp = datetime.fromtimestamp(record.created).strftime("%Y-%m-%d %H:%M:%S")
        return f"[{timestamp}] [{record.levelname}] [{system}] {record.getMessage()}"


def setup_logger():
    logger = logging.getLogger("pcbs_forge")
    logger.setLevel(logging.DEBUG)

    if logger.handlers:
        return logger

    log_filename = datetime.now().strftime("pcbs_forge_%Y%m%d_%H%M%S.log")
    log_path = os.path.join(LOGS_DIR, log_filename)

    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(AppFormatter())
    file_handler.addFilter(SystemFilter())

    logger.addHandler(file_handler)

    return logger


def get_logger(system_name="General"):
    logger = logging.getLogger("pcbs_forge")

    class SystemLogger:
        def __init__(self, base_logger, system):
            self._logger = base_logger
            self._system = system

        def _log(self, level, msg, *args, **kwargs):
            extra = kwargs.pop("extra", {})
            extra["system"] = self._system
            kwargs["extra"] = extra
            getattr(self._logger, level)(msg, *args, **kwargs)

        def debug(self, msg, *args, **kwargs):
            self._log("debug", msg, *args, **kwargs)

        def info(self, msg, *args, **kwargs):
            self._log("info", msg, *args, **kwargs)

        def warning(self, msg, *args, **kwargs):
            self._log("warning", msg, *args, **kwargs)

        def error(self, msg, *args, **kwargs):
            self._log("error", msg, *args, **kwargs)

    return SystemLogger(logger, system_name)
