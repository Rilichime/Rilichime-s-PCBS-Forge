import math
from app.logger import get_logger

log = get_logger("3DMark")


def _safe_float(value, default=0.0):
    try:
        return float(value)
    except (ValueError, TypeError):
        return default


def _safe_int(value, default=0):
    try:
        return int(float(value))
    except (ValueError, TypeError):
        return default


def calculate_cpu_score(cpu_data, ram_parts):
    if cpu_data is None:
        log.warning("No CPU in build, returning score 0")
        return 0

    core_clock_multiplier = _safe_float(cpu_data.get("CoreClockMultiplier", 0))
    frequency = _safe_float(cpu_data.get("Frequency", 0))
    mem_channels_multiplier = _safe_float(cpu_data.get("MemChannelsMultiplier", 0))
    mem_clock_multiplier = _safe_float(cpu_data.get("MemClockMultiplier", 0))
    final_adjustment = _safe_float(cpu_data.get("FinalAdjustment", 0))

    ram_count = len(ram_parts) if ram_parts else 0
    actual_memory_channels = 2 if ram_count >= 2 else (1 if ram_count == 1 else 0)

    actual_ram_speed = 0
    if ram_parts:
        speeds = [_safe_float(r.get("Frequency", 0)) for r in ram_parts]
        actual_ram_speed = min(speeds) if speeds else 0

    if actual_memory_channels == 0 or actual_ram_speed == 0:
        log.warning("No RAM installed, CPU score will be reduced")

    raw = (
        (core_clock_multiplier * frequency)
        + (mem_channels_multiplier * actual_memory_channels)
        + (mem_clock_multiplier * actual_ram_speed)
        + final_adjustment
    )
    cpu_score = math.floor(raw * 298)

    log.debug(
        f"CPU Score components: CCM={core_clock_multiplier}, Freq={frequency}, "
        f"MCM={mem_channels_multiplier}, Channels={actual_memory_channels}, "
        f"MKM={mem_clock_multiplier}, RAMSpeed={actual_ram_speed}, "
        f"FA={final_adjustment}, Raw={raw}, Score={cpu_score}"
    )

    return max(cpu_score, 0)


def calculate_gpu_score(gpu_parts):
    if not gpu_parts:
        log.warning("No GPU in build, returning score 0")
        return 0

    scores = []
    for gpu in gpu_parts:
        score = _safe_float(gpu.get("Single GPU Graphics Score", 0))
        scores.append(score)
        log.debug(f"GPU '{gpu.get('Full Part Name', '?')}' score: {score}")

    if len(scores) == 1:
        gpu_score = scores[0]
    elif len(scores) == 2:
        gpu_score = (scores[0] + scores[1]) // 2
        log.debug(f"Dual GPU average score: {gpu_score}")
    else:
        gpu_score = scores[0]

    return max(int(gpu_score), 0)


def calculate_3dmark(cpu_data, gpu_parts, ram_parts):
    cpu_score = calculate_cpu_score(cpu_data, ram_parts)
    gpu_score = calculate_gpu_score(gpu_parts)

    if cpu_score == 0 or gpu_score == 0:
        log.warning(f"Cannot calculate 3DMark: CPU={cpu_score}, GPU={gpu_score}")
        return 0

    total = 1.0 / ((0.85 / gpu_score) + (0.15 / cpu_score))
    total_score = math.floor(total)

    log.info(f"3DMark Score: CPU={cpu_score}, GPU={gpu_score}, Total={total_score}")

    return total_score


def calculate_build_value(build_parts, three_d_mark_score):
    total_sell = 0.0
    for part in build_parts:
        sell_price = _safe_float(part.get("Sell Price", 0))
        total_sell += sell_price

    if three_d_mark_score > 9999:
        value = (total_sell * 3) + 100
    else:
        value = total_sell + 100

    log.debug(f"Build value: sell_total={total_sell}, 3DMark={three_d_mark_score}, value={value}")

    return int(value)
